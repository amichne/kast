declare const tools: {
  /** Add one declaration at an exact top-level Kotlin target. A class or object target inserts into its existing body. A function, property, or type alias target inserts after that declaration. Kast plans and applies the change, examines the resulting source, and reports a verified receipt or finite failure with recovery evidence. Preserve the returned result. A cancelled or missing response does not prove that no write occurred. */
  mcp__kast__add_declaration(args: {
  // Kotlin declaration text to add at the exact target.
  // @minLength 1 @maxLength 1048576
  declaration: string;
  // Opaque exact-symbol reference to a top-level Kotlin declaration. Member and local targets reject. Copy the issued reference unchanged.
  // @minLength 1 @maxLength 1048576
  exactTarget: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { application: { [key: string]: unknown; }; plan?: { [key: string]: unknown; } | null; planIdentity: string; status: "complete"; } | { error: { application?: { [key: string]: unknown; } | null; code: "PLANNING_REJECTED" | "AUTHORIZATION_UNAVAILABLE" | "APPLY_REJECTED" | "APPLY_UNVERIFIED" | "RECOVERY_UNAVAILABLE"; plan?: { [key: string]: unknown; } | null; planIdentity?: string | null; recovery?: { [key: string]: unknown; } | null; }; status: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; }; [key: string]: unknown; }>;
  /** Check compiler diagnostics for a file or recursively beneath a directory in the session workspace. Use '.' explicitly for the workspace root. This is not symbol search and does not build the project. Results retain incomplete-coverage evidence; an incomplete empty result does not establish that the scope is clean. Requires the saved, indexed IntelliJ state. */
  mcp__kast__check_diagnostics(args: {
  // Opaque same-basis diagnostic continuation. Omit or use null to start. Resume the same relative_path; increase execution_budget if a grant cannot cross the enumeration prefix.
  // @minLength 1 @maxLength 1048576
  continuation?: string | null;
  executionBudget?: {
    // Explicit timeout in milliseconds for RUNNER_CONTROLLED execution, including model capture. Omission adds no timeout. Legacy BOUNDED mode uses KAST_READ_SEMANTIC_MILLIS and host clamps.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxElapsedMs?: number | null;
    // In BOUNDED mode, this caps results. In RUNNER_CONTROLLED mode, this caps each output page.
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Encoded response allowance in bytes. Omission uses KAST_READ_SEMANTIC_RETURNED_BYTES.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
    // Accounted work allowance. Query omission uses KAST_READ_SEMANTIC_WORK. Time and response size do not change this allowance.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxWorkUnits?: number | null;
  } | null | null;
  // Maximum diagnostic entries to return. Omission or null selects 100. This limits results, not module admission, indexing, or compiler work; incomplete coverage remains explicit.
  // @integer @minimum 1 @maximum 1000 @default 100
  maxDiagnostics?: number | null;
  // File or directory path relative to the session workspace root, such as src/main/kotlin/orders/OrderService.kt or services/orders. Use '.' for the root. Not a package name, glob, absolute path, or parent traversal.
  // @minLength 1 @maxLength 1048576
  relativePath: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: unknown; [key: string]: unknown; }>;
  /** Observe exact workspace binding and saved/indexed readiness. This passive check does not validate semantic answers. */
  mcp__kast__health_check(args: { verbose?: boolean; }): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { data: { contentView: "SAVED_PSI_COMMITTED" | null; host?: string | null; hostState: "INDEXED" | "UNAVAILABLE"; readiness: "READY" | "UNAVAILABLE"; readinessEvidence: unknown; workspaceBinding: string; }; status?: "complete"; } | { error: { code: "INVALID_REQUEST" | "HOST_UNAVAILABLE" | "OUT_OF_SCOPE" | "INTERNAL_ERROR"; message: string; }; status?: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; }; [key: string]: unknown; }>;
  /** Run, resume, and read compiler-grounded Kotlin queries in the bound workspace. For RUN, provide a source, zero or more nonterminal steps, and exactly one terminalStep object tagged EMIT or TRACE. Put output in terminalStep.output. EMIT accepts all output choices. TRACE accepts only symbols and owns expansionScope directly. Never put TRACE in steps or output on RUN. Apply known name, kind, scope, and source-set constraints before discovery. Start with request {"type":"RUN","source":{"type":"SEARCH_DECLARATIONS","declarationName":"Order","declarationKinds":["CLASS"],"scope":{"type":"DIRECTORY","relativeDirectoryPath":"orders","sourceSetNames":["main"]}},"terminalStep":{"type":"EMIT"}}. Select the exact owner, receiver, signature, and location, never the first overload. Pass its unchanged issued ref in source {"type":"SYMBOL_REFS","symbolRefs":["<issued ref>"]}. Use EXPAND_RELATION for direct references or callers. Use TRACE for references, implementations or overrides, direct callers, and one further caller layer. Discovery scope selects seeds. Expansion scope selects destinations. SOURCE_DOMAIN applies source-set, production/test, and generated-source constraints before enumeration. If the host supports tool composition, chain discovery, exact selection, and expansion inside code. Keep successful intermediate results inside that call. Return task findings with scope, completion, omissions, and recovery facts. Do not omit requested matches or hide failures to reduce tokens. Apply path exclusions before read batches. Remove duplicate paths. Reuse unchanged source reads until a source change or freshness rejection. Inspect unresolved imports, companion qualifiers, and unmatched source sites before a complete source-use answer. Every RUN uses COMPLETE_ONLY within COMPILER_RESOLVED_STATIC_V1. Preserve typed rejection and recovery evidence when completion is unproven. Use RESUME only with an issued output continuation, READ_RESULT with an issued result reference and cursor, and READ_SOURCE with an issued candidateSelector as candidateRef. Keep these capabilities distinct. Set retention RETAIN for later presentation. Budgets share one admitted grant under host ceilings. The schema also defines graph walk with WALK, predicates, retained composition, joins, and value IMPACT. Use known request shapes directly. Read only the needed schema section or named example for unfamiliar shapes. Stop when evidence answers the task. */
  mcp__kast__query_symbols(args: {
  // Exactly one closed action: run, resume, read_result, or read_source.
  request: unknown;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: unknown; [key: string]: unknown; }>;
  /** Replace only the block body of one existing, non-inline named Kotlin function selected by an exact Kast symbol reference. Kast plans, applies, verifies, and reports a verified receipt or finite failure with recovery evidence. The signature and surrounding source are preserved. */
  mcp__kast__replace_body(args: {
  // One complete Kotlin block body, including braces. Syntax errors and trailing input are rejected.
  // @minLength 1 @maxLength 1048576
  body: string;
  // Opaque exact-symbol reference returned by Kast. Copy it unchanged.
  // @minLength 1 @maxLength 1048576
  exactTarget: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { application: { [key: string]: unknown; }; plan?: { [key: string]: unknown; } | null; planIdentity: string; status: "complete"; } | { error: { application?: { [key: string]: unknown; } | null; code: "PLANNING_REJECTED" | "AUTHORIZATION_UNAVAILABLE" | "APPLY_REJECTED" | "APPLY_UNVERIFIED" | "RECOVERY_UNAVAILABLE"; plan?: { [key: string]: unknown; } | null; planIdentity?: string | null; recovery?: { [key: string]: unknown; } | null; }; status: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; }; [key: string]: unknown; }>;
};