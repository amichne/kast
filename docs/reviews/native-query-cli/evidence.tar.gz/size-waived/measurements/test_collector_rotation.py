# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Real filesystem/process capture checks; no Kast, IDEA, host, or sleeps."""

from __future__ import annotations

import importlib
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
c = importlib.import_module("collector")


class RotationCaptureTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="kast-log-capture-test-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.log = self.root / "idea.log"
        self.log.write_bytes(b"before\n")

    def capture(self, action: str) -> Any:
        code = (
            "from pathlib import Path\nimport sys\np=Path(sys.argv[1])\n"
            + action
            + "\nprint('{}')\n"
        )
        return c.capture(
            self.root / "capture",
            [sys.executable, "-c", code, str(self.log)],
            {"PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1"},
            str(self.root),
            b"",
            self.log,
            30,
            {"cohort": "metadata", "route": "synthetic-python-child-not-product"},
        )

    def assert_rejection(self, action: str, detail: str) -> None:
        record = self.capture(action)
        self.assertEqual(record["state"], "RECORDED")
        self.assertEqual(record["exitCode"], 0)
        self.assertTrue(record["reapedBeforeNextInvocation"])
        self.assertIn(detail, record["logFailure"])
        self.assertNotIn("receipts", record)
        with self.assertRaisesRegex(ValueError, "host log capture failed:"):
            c.validate_sample(self.root / "capture", record, {})

    def test_append_retains_only_interval(self) -> None:
        record = self.capture("with p.open('ab') as f: f.write(b'tail\\n')")
        self.assertNotIn("logFailure", record)
        self.assertEqual((self.root / "capture/host.log").read_bytes(), b"tail\n")
        self.assertEqual([(s["start"], s["end"]) for s in record["hostLogSpans"]], [(7, 12)])

    def test_rename_tail_plus_successor_prefix(self) -> None:
        record = self.capture(
            "with p.open('ab') as f: f.write(b'tail\\n')\np.rename(p.with_name('idea.1.log'))\np.write_bytes(b'head\\n')"
        )
        self.assertNotIn("logFailure", record)
        self.assertEqual((self.root / "capture/host.log").read_bytes(), b"tail\nhead\n")
        self.assertEqual(
            [(s["start"], s["end"]) for s in record["hostLogSpans"]], [(7, 12), (0, 5)]
        )
        self.assertNotEqual(
            record["hostLogSpans"][0]["identity"], record["hostLogSpans"][1]["identity"]
        )
        self.assertEqual(record["hostLogMechanism"], "append-or-one-verified-rename")

    def test_rename_shifts_preexisting_archive(self) -> None:
        (self.root / "idea.1.log").write_bytes(b"older\n")
        record = self.capture(
            "p.with_name('idea.1.log').rename(p.with_name('idea.2.log'))\np.rename(p.with_name('idea.1.log'))\np.write_bytes(b'head\\n')"
        )
        self.assertNotIn("logFailure", record)
        self.assertEqual((self.root / "capture/host.log").read_bytes(), b"head\n")

    def test_missing_initial_generation_rejected(self) -> None:
        self.assert_rejection(
            "p.rename(p.with_name('idea.1.log'))\np.with_name('idea.1.log').unlink()\np.write_bytes(b'head\\n')",
            "missing initial log generation",
        )

    def test_missing_intermediate_generation_rejected(self) -> None:
        self.assert_rejection(
            "p.rename(p.with_name('idea.2.log'))\np.write_bytes(b'head\\n')",
            "unsupported or missing log generation",
        )

    def test_multiple_rotations_rejected(self) -> None:
        self.assert_rejection(
            "p.rename(p.with_name('idea.2.log'))\np.with_name('idea.1.log').write_bytes(b'middle\\n')\np.write_bytes(b'head\\n')",
            "unsupported or missing log generation",
        )

    def test_truncation_rejected(self) -> None:
        self.assert_rejection("p.write_bytes(b'x\\n')", "initial log truncated")

    def test_truncate_and_regrow_rejected(self) -> None:
        self.assert_rejection(
            "p.write_bytes(b'changed-and-longer\\n')", "initial log prefix changed"
        )

    def test_ambiguous_inode_alias_rejected(self) -> None:
        self.assert_rejection(
            "p.rename(p.with_name('idea.1.log'))\np.with_name('idea.2.log').hardlink_to(p.with_name('idea.1.log'))\np.write_bytes(b'head\\n')",
            "ambiguous initial log generation",
        )

    def test_copy_rotation_rejected(self) -> None:
        self.assert_rejection(
            "p.with_name('idea.1.log').write_bytes(p.read_bytes())",
            "archive namespace changed without rename",
        )

    def test_unexplained_archive_generation_rejected(self) -> None:
        self.assert_rejection(
            "p.rename(p.with_name('idea.1.log'))\np.with_name('idea.2.log').write_bytes(b'unexplained\\n')\np.write_bytes(b'head\\n')",
            "unexplained archive generation",
        )

    def test_schedule_and_existing_independent_oracles_unchanged(self) -> None:
        self.assertEqual(len(c.schedule()), 310)
        c.self_test()


if __name__ == "__main__":
    unittest.main(verbosity=2)
