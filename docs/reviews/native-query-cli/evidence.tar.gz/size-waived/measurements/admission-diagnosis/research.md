# macOS arm64 SHA-256 investigation

Date: 2026-10-30. Scope: read-only source, toolchain, build-report, disassembly, and existing-profile research. No production edits, builds, installations, or fixture calls were performed. This file is the only added workspace artifact for this research.

## Decision supported by the sources

Adding `-H:CPUFeatures=SHA2` only for the declared **macOS Apple-silicon target** preserves its existing hardware support scope. Apple kernel source, OpenJDK, and Go treat SHA-256 instructions as part of that platform baseline. This conclusion excludes Linux arm64, generic Armv8.1-A hardware, Intel macOS, and environments that conceal required Apple CPU features. It is not a claim that SHA2 is mandatory in the generic Armv8.1-A architecture.

The repository selects `macos-aarch64` for macOS with `aarch64` or `arm64`; its error describes the supported platforms as macOS Apple silicon or Linux x86_64 (`build.gradle.kts:169–176`). Both native macOS argument files set `-mmacosx-version-min=15.0`. Their conditional owners are `cli/build.gradle.kts:37–47` and `distribution/cli/build.gradle.kts:67–77`.

This is a source-supported compatibility recommendation, not an implemented change or a measured performance improvement. The previous failed cohort remains failed. Diagnostic process timings and sampling do not establish a stage duration or a causal improvement.

## Apple, OpenJDK, and Go support evidence

### Apple XNU

Inspected tag `xnu-11215.1.10`, commit `8d741a5de7ff4191bf97d57b9f54c2f6d4a15585`.

- The shared Apple arm64 header defines `__ARM_V8_CRYPTO_EXTENSIONS__` as `1`: [apple_arm64_common.h:29–46](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/apple_arm64_common.h#L29-L46).
- Apple core headers H13, H14, H15, and H16 include that shared header. The VMAPPLE configuration does too: [H13.h:87](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/H13.h#L87), [H14.h:104](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/H14.h#L104), [H15.h:110](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/H15.h#L110), [H16.h:106](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/H16.h#L106), [VMAPPLE.h:52](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/pexpert/pexpert/arm64/VMAPPLE.h#L52).
- With that board-level feature enabled, the kernel sets `gARM_FEAT_SHA256 = 1` along with AES, PMULL, and SHA1. It deliberately uses board configuration rather than the hardware feature register because of a historical reporting defect: [commpage.c:475–487](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/osfmk/arm/commpage/commpage.c#L475-L487).
- The kernel exposes that flag as `hw.optional.arm.FEAT_SHA256`: [kern_mib.c:1182–1190](https://github.com/apple-oss-distributions/xnu/blob/8d741a5de7ff4191bf97d57b9f54c2f6d4a15585/bsd/kern/kern_mib.c#L1182-L1190).

Apple's developer documentation page could not be retrieved with the available web tool. The Apple findings above come directly from its version-pinned kernel source, not an inferred host capability.

### OpenJDK 25.0.2

Inspected tag `jdk-25.0.2+10`, commit `405a5699ebd097464ed3fc9345414b0774a2edc9`.

The BSD/macOS AArch64 CPU initialization says: “All Apple-darwin Arm processors have AES, PMULL, SHA1 and SHA2.” It unconditionally adds `CPU_SHA2`, citing Apple XNU. It checks SHA512 and SHA3 separately: [vm_version_bsd_aarch64.cpp:52–94](https://github.com/openjdk/jdk25u/blob/405a5699ebd097464ed3fc9345414b0774a2edc9/src/hotspot/os_cpu/bsd_aarch64/vm_version_bsd_aarch64.cpp#L52-L94).

The AArch64 VM enables SHA-256 intrinsics when SHA is enabled and `supports_sha256()` is true: [vm_version_aarch64.cpp:345–371](https://github.com/openjdk/jdk25u/blob/405a5699ebd097464ed3fc9345414b0774a2edc9/src/hotspot/cpu/aarch64/vm_version_aarch64.cpp#L345-L371).

### Go 1.25.2

Inspected tag `go1.25.2`, commit `bed6c81c2dceeb19c7f9e46fc173671abcda7cfd`.

The file is explicitly scoped by `//go:build arm64 && darwin && !ios`. It sets `ARM64.HasSHA2 = true`, together with AES, PMULL, and SHA1. Its comment states that it assumes the features supported by Apple Silicon M1 remain available in future iterations. SHA512 and SHA3 remain dynamically checked: [cpu_arm64_darwin.go:5–30](https://github.com/golang/go/blob/bed6c81c2dceeb19c7f9e46fc173671abcda7cfd/src/internal/cpu/cpu_arm64_darwin.go#L5-L30).

These are existing runtime platform contracts, not a deduction from this development machine's `sysctl` response. They support the macOS-specific static addition without extending that conclusion to all Arm64 operating systems.

## Existing executables and toolchain

Inspected Oracle GraalVM `25.0.2+10.1`, Native Image `25.0.2`, from `/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2`.

The digests below identify the inspected artifacts. At the final evidence-file recheck, the query digest still matched; the management producer path was absent, so its digest could not be reverified then. This research did not remove or rebuild it.

| Artifact | SHA-256 |
| --- | --- |
| `cli/build/native/nativeCompile/kast-query` | `7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0` |
| `distribution/cli/build/native/nativeCompile/kast` | `f5c86b3c1ec27d676c4c19392213e7455d3b34d4e1a8ef3457a04b80a910ae01` |

The query build report records optimization level `s` and target `armv8.1-a`. Its `SHA2.implCompress0(byte[], int)` entry has 924 bytes of compiled machine code. The report contains no `sha256ImplCompress` entry. The management argument file contains no `-Os` after the earlier restoration. Neither executable contains any disassembled `sha256h`, `sha256h2`, `sha256su0`, or `sha256su1` instruction.

Graal source tag `vm-25.0.2`, commit `981ecb6e1be6bf4591a6dd24b48ea053221209f5`, establishes:

- `armv8-a` includes FP and ASIMD; `armv8.1-a` adds CRC32 and LSE, not SHA2: [CPUTypeAArch64.java:60–66](https://github.com/oracle/graal/blob/981ecb6e1be6bf4591a6dd24b48ea053221209f5/substratevm/src/com.oracle.svm.hosted/src/com/oracle/svm/hosted/util/CPUTypeAArch64.java#L60-L66).
- The SHA-256 intrinsic requires `AArch64.CPUFeature.SHA2`: [MessageDigestNode.java:136–165](https://github.com/oracle/graal/blob/981ecb6e1be6bf4591a6dd24b48ea053221209f5/compiler/src/jdk.graal.compiler/src/jdk/graal/compiler/replacements/nodes/MessageDigestNode.java#L136-L165).
- `-H:CPUFeatures=SHA2` adds a static target feature. `CPUFeatures` is a stable option and warns that unsupported target features can cause crashes: [NativeImageOptions.java:60–66](https://github.com/oracle/graal/blob/981ecb6e1be6bf4591a6dd24b48ea053221209f5/substratevm/src/com.oracle.svm.hosted/src/com/oracle/svm/hosted/NativeImageOptions.java#L60-L66).
- `-H:RuntimeCheckedCPUFeatures=SHA2` is not an AArch64 solution in this version. The AArch64 target builder clones only the static feature set: [NativeImageGenerator.java:472–478](https://github.com/oracle/graal/blob/981ecb6e1be6bf4591a6dd24b48ea053221209f5/substratevm/src/com.oracle.svm.hosted/src/com/oracle/svm/hosted/NativeImageGenerator.java#L472-L478). The runtime-check support list is AMD64-only: [RuntimeCPUFeatureCheck.java:66–71](https://github.com/oracle/graal/blob/981ecb6e1be6bf4591a6dd24b48ea053221209f5/substratevm/src/com.oracle.svm.core/src/com/oracle/svm/core/cpufeature/RuntimeCPUFeatureCheck.java#L66-L71).

The last finding was also verified in the installed Oracle toolchain's `lib/svm/builder/svm.src.zip` and `svm.jar` bytecode. The missing target feature explains intrinsic ineligibility; this is not evidence that `-Os` independently disables SHA acceleration.

## Existing profile mapped to scalar SHA-256

Input: `dispatcher.sample.txt` in this directory. The sample's executable UUID is `149EB5CF-C9B0-3B0A-A80D-3563E00C55A1`, matching the current management executable's `LC_UUID`.

The sample loaded the image at `0x102350000`. The file's preferred `__TEXT` address is `0x100000000`. Therefore sample offset `0xeeaa50` maps to disassembly address `0x100eeaa50`.

Of 308 main-thread samples, 277 have direct top frames in offsets `0xeeaa50–0xeead04`. The disassembly contains these scalar SHA-256 operations:

| Image offsets | Observed operations |
| --- | --- |
| `0xeeaa50–0xeeab0c` | Schedule indices `t-2`, `t-15`, `t-7`, `t-16`; rotates 7/18 and 17/19; shifts 3/10; loop bound 64 |
| `0xeeac50–0xeead04` | Scalar rounds; rotates 2/13/22 and 6/11/25; Boolean choice/majority operations; loop bound 64 |

These match [OpenJDK SHA2.java:153–218](https://github.com/openjdk/jdk25u/blob/405a5699ebd097464ed3fc9345414b0774a2edc9/src/java.base/share/classes/sun/security/provider/SHA2.java#L153-L218), also inspected in the installed JDK's `lib/src.zip`.

This identifies sampled code as scalar SHA-256. It does not convert the sample count into a duration, attribute every end-to-end difference to hashing, or repair the failed cohort.

The existing integrity owners are `PublicQueryDispatch.kt:42–48`, `InstallationLifecycle.kt:238–245`, and `ManagementInstallation.kt:148–158` for management; and `InstalledClientContext.kt:125–147` for the query client. Management checks both the wrapper and native payload. The client hashes its admitted payload. No recommendation removes either integrity check.

## Read-only commands and results

Commands ran from `/Users/amichne/code/kast.feature-native-query-cli` unless noted.

```sh
mise exec -- native-image --version
mise exec -- native-image -march=list
mise exec -- native-image --expert-options-all 2>&1 | grep -A 7 -- '-H:RuntimeCheckedCPUFeatures'
shasum -a 256 cli/build/native/nativeCompile/kast-query distribution/cli/build/native/nativeCompile/kast
/usr/bin/otool -l distribution/cli/build/native/nativeCompile/kast | grep -A 2 LC_UUID
/usr/bin/otool -tvV distribution/cli/build/native/nativeCompile/kast |
  awk '$1 >= "0000000100eeaa30" && $1 <= "0000000100eead20" {print}'
/usr/bin/otool -tvV cli/build/native/nativeCompile/kast-query |
  awk '/[[:space:]]sha256(h|h2|su0|su1)[[:space:]]/ {count++} END {print count+0}'
/usr/bin/otool -tvV distribution/cli/build/native/nativeCompile/kast |
  awk '/[[:space:]]sha256(h|h2|su0|su1)[[:space:]]/ {count++} END {print count+0}'
mise exec -- javap \
  -classpath /Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm.jar \
  -c com.oracle.svm.hosted.NativeImageGenerator |
  grep -A 28 -B 4 'CPUTypeAArch64.getSelectedFeatures'
```

Both instruction-count commands returned `0`. `-march=list` reported default-compatible architecture sets without SHA2 and native-host features including SHA2. Generic expert help reports no default AArch64 runtime-checked features. A separate `native-image --list-cpu-features` attempt failed because no main class was supplied; it did not build anything and is not evidence of feature availability.

The report was inspected as text at `cli/build/native/nativeCompile/kast-query-build-report.html`, searching for `armv8`, `"label":"SHA2"`, and `sha256ImplCompress`. Python `zipfile.ZipFile` reads inspected the installed `svm.src.zip` classes above and `src.zip!/java.base/sun/security/provider/SHA2.java`. No source files were extracted into the workspace.

## Smallest proposed follow-up, not performed

Add only `-H:CPUFeatures=SHA2` to `cli/native-image-macos.args` and `distribution/cli/native-image-macos.args`. Keep the existing `armv8.1-a` default, macOS minimum, optimization choices, and integrity checks. Do not add the option to portable/Linux arguments or use `-march=native`.

Build separately identified candidates. Confirm SHA instructions appear, verify known digest vectors and unchanged payload admission/rejection behavior, and rerun the same complete cohort. Preserve the current artifacts and failed cohort. Compatibility evidence supports this experiment; no throughput or end-to-end improvement has yet been measured for it.

## Local source clones

| Repository | Tag and commit | Directory |
| --- | --- | --- |
| `oracle/graal` | `vm-25.0.2`, `981ecb6e1be6bf4591a6dd24b48ea053221209f5` | `/tmp/amp-librarian/oracle__graal` |
| `golang/go` | `go1.25.2`, `bed6c81c2dceeb19c7f9e46fc173671abcda7cfd` | `/tmp/amp-librarian/golang__go` |
| `openjdk/jdk25u` | `jdk-25.0.2+10`, `405a5699ebd097464ed3fc9345414b0774a2edc9` | `/tmp/amp-librarian/openjdk__jdk25u` |
| `apple-oss-distributions/xnu` | `xnu-11215.1.10`, `8d741a5de7ff4191bf97d57b9f54c2f6d4a15585` | `/tmp/amp-librarian/apple-oss-distributions__xnu` |

All clones used `git clone --depth 1 --filter=blob:none --no-tags --sparse --branch <tag> https://github.com/<repository>.git <directory>`, followed by scoped `git sparse-checkout add` for the cited source directories. No source builds or tests ran. The evidence text was checked against these sources; automated prose assessment was not run during this bounded research.
