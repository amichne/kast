# Final installed correctness — PASS after preserved fixture/harness failures

The final installed baseline/native comparison and packaged stdio/RPC call passed against the same real IDEA host. No latency pilot or cohort ran. The temporary waiver applies only to product size.

## Exact identity and readiness

- Host PID22176, start `Fri Oct 30 08:23:49 2026`, UUID `2cd3f767-77b0-448c-b166-d9c526738a37`; workspace `/private/tmp/knq-lifecycle-5VGhDa/workspace`; shared HOME `/private/tmp/knq-lifecycle-5VGhDa/h`.
- Two sequential installed probes, baseline then native, independently passed the frozen OrderService declaration oracle and exact epoch2 basis. Endpoint, PID/start/command, source digest, and all pinned installation identities were checked before and after each probe. Receipt: `ready-epoch2-20261030T122938.550199Z/ready-host-receipt.json`, SHA-256 `f9bcf8430a7dc9b253023b08bec41134f9d25085cf8634fa71895bea95389e89`.
- Native query SHA-256 `7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0`; public management `f5c86b3c1ec27d676c4c19392213e7455d3b34d4e1a8ef3457a04b80a910ae01`; candidate manifest `45e892d90fa932beb305019512cca82d369965866971754308c18d902f9140f9`.
- Baseline public command SHA-256 `54386c967c713a4288e529fed654bd5436ff163c3912caf2ca81dfd275d8724c`; query launcher `d900861b69aa77c80dce1c2bfba3d40340ca40f370fb8a297729cb43244708c2`; manifest `1f92df822cc8fd972251da5dacb602ee1f79eb4378fad3972536a6ef2fd67fe9`.
- Source SHA-256 `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`. Final read-only preflight passed and host process start remained unchanged.

## Preserved failures and observed epoch evidence

`run-001` remains FAIL after five starts: actual epoch2 differed from authorized epoch1. Neither its config nor the original readiness receipt was rewritten.

`ready-epoch2-20261030T122938.550199Z/host-before.log` preserves preceding log bytes. For this host it contains `kast_project_read_epoch` BASELINE at08:24:16.827, MOVED with `["VFS"]` at08:24:17.166, and MOVED with `["PSI","INDEXING"]` at08:26:56.527. A separate08:24:20.462 VFS observation reports CREATE/REFRESH/OUTSIDE_ROOT. These are observed signals, not an inferred cause or a causal join to the epoch change. `prior-semantic-bases.json` separately records the epoch1 and epoch2 semantic read correlations.

`run-002` remains FAIL after60 starts because the harness mistakenly required transport COMPLETED for the deliberate unissued-token rejection. The product returned the independently expected exit10/document and transport REJECTED. Both archived unissued-token and explicit1ms logs already contain REJECTED. The harness now requires exactly one REJECTED terminal for these expected failures, and exactly one COMPLETED terminal for successful calls. It rejects a mutated successful terminal in the negative control. No expected product document, exit, basis, or no-replay assertion changed. The original harness is preserved at `run-002/acceptance-before-rejection-join-fix.py`; the explicit amendment is in `ready-epoch2-rejection-join-fixed.json`.

## Final observed coverage

`run-002-corrected/summary.json` is PASS:65 captured outer starts,94 completed assertion entries, all65 outer children reaped. These counts exclude descendant executions and are not JVM-launch counts.

- PASS: independent declarations, known caller edge/signatures/ranges, three referenced symbols, absent-name and wrong-target controls, with full fresh-document parity across baseline, native, and policy-native.
- PASS:30 retained reads across exited producer/reader processes, preserving exact issued token strings and result facts. Each has the transport-to-read join and exact zero producer/search/discovery/relation work assertions. Baseline-issued results additionally match exactly across baseline/native/policy-native readers; no retained document normalization.
- PASS:10 source reads, including issued-selector follow-ups; exact source text, UTF16 offsets, lines, location, basis and selection assertions. Three row pages and two independent evidence pages per follow-up group preserve cursors, coverage and evidence.
- PASS:23 native invocations under the exact installed execution allowlist, covering query, result read, source read, unissued RESUME rejection, and explicit1ms timeout. Direct and shell-descendant absolute copied-JBR Java execute under the positive policy and receive EPERM under the query policy. This is enforced execution-policy evidence, not event counting.
- PASS: baseline and policy-native explicit unissued `query-output:v1:00000000-0000-0000-0000-000000000099` both exit10; stdout bytes identical; joined rejection/no-producer-replay assertions pass. This is not successful issued-token RESUME.
- PASS: actual explicit1ms baseline exits6 and policy-native exits124; stdout bytes identical; joined transport rejection and unbound pre-admission correlation match the independent archived expectation.
- PASS: real final packaged stdio service initialize/list-tools/find(OrderService), using packaged JVM RPC. Evidence: `mcp/run-002-corrected/`. All15,525 manifest payload digests verified before launch. Exact class range17–94, qualified identity, fields, coverage/completion, basis, text/structured equality, and joined host receipt passed; SDK contexts closed. This JVM route is excluded from native-query policy and timing claims.
- PASS: fresh baseline declaration producer ran after MCP, exited and was reaped, issuing `result:v1:0b518dfd-4671-4df0-ba84-7d7ded915b40` for the separately authorized pilot.

All59 bound semantic receipts in the final run use the exact authorized epoch2 host basis; only the two expected pre-admission timeout receipts are unbound. No later basis drift was observed.

## Commands and handoff

Final successful command:

```sh
S=.amp/in/artifacts/native-query/size-waived/semantic
uv run --no-project --offline --locked --script "$S/acceptance.py" \
  --run "$S/ready-epoch2-rejection-join-fixed.json" \
  --authorize-ready-host --output "$S/run-002-corrected"
```

Pilot configuration: `run-002-corrected/pilot-ready.json`, SHA-256 `8069d889ad397652213f3a35f0b20467c1eec109f7ba126d6ee7f356c95aad53`. It pins the new readiness receipt, successful correctness summary, MCP summary/package verification, both policies, and exact issued producer stdout/exit receipt. Read-only collector preflight passed. The original generated `measurement-ready.json` is preserved separately.

Only after main separately authorizes a pilot:

```sh
M=.amp/in/artifacts/native-query/size-waived/measurements
uv run --no-project --offline --locked --script "$M/collector.py" \
  --pilot "$S/run-002-corrected/pilot-ready.json" \
  --authorize-ready-host --output "$M/pilot-001"
```

No pilot or cohort was run. Successful issued-token RESUME remains NOT RUN. This evidence does not establish complete AC06, size qualification, total descendant launch counts, or latency improvements. No host stop, installation/source mutation, build, or personal IDEA interaction occurred. The frozen collection decision and collector bytes remain unchanged.
