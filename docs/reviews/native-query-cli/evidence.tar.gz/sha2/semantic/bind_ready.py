# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Bind the main-authorized corrected receipt without making product calls."""

from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c


def main() -> None:
    receipt = HERE.parent / "lifecycle/route-corrected-001/ready-host-receipt.json"
    c.require(
        c.digest(receipt) == "84a93f58eab790f1a030b735b61a1f09452479389962a372275f591b4ecb0e5a",
        "authorized receipt digest",
    )
    c.require(not (HERE / "ready.json").exists(), "preserve previous ready configuration")
    ready = c.load(receipt)
    config = c.load(HERE / "pending.json")
    c.require(ready["hostLaunch"]["pid"] == 35613, "only authorized IDEA")
    process = subprocess.run(
        ["/bin/ps", "-p", "35613", "-o", "pid=,lstart=,command="], capture_output=True, check=True
    )
    (HERE / "host-before.ps").write_bytes(process.stdout)
    c.require(ready["hostLaunch"]["start"] in process.stdout.decode(), "exact IDEA start")
    c.require(
        " ".join(ready["hostLaunch"]["command"]) in process.stdout.decode(),
        "exact copied IDEA command",
    )
    for key in ("live", "endpoint", "endpointExpected", "hostLog"):
        config[key] = ready[key]
    config["source"] = str(Path(ready["live"]["root"]) / "src/main/kotlin/example/OrderService.kt")
    config["readyHostReceipt"] = str(receipt)
    config["status"] = "READY_MAIN_AUTHORIZED"
    config["authorizationScope"] = (
        "Main authorized complete 65-start correctness/MCP on copied IDEA35613; no measurements or restart."
    )
    config["externalLoadNotes"] = (
        "Correctness only; no builds or measurement workload started by this collector."
    )
    config.pop("pendingRequirements")
    config["identities"].update(ready["additionalHashes"])
    verified: dict[str, int] = {}
    for route, identity_key, home_key in (
        ("baseline", "baselineInstallationIdentities", "baselineHome"),
        ("native", "installationIdentities", "home"),
    ):
        selected = config["routes"][route]
        home = ready[home_key]
        installed = ready[identity_key]
        c.require(selected["environment"]["HOME"] == home, "exact route HOME")
        c.require(selected["command"] == home + "/.local/bin/kast", "strict route command/HOME")
        c.require(
            home.endswith("/baseline-home" if route == "baseline" else "/m"),
            "distinct route selection",
        )
        probe = next(p for p in ready["probeOrder"] if p["name"] == route)
        c.require(probe["command"]["command"][0] == selected["command"], "probe route command")
        c.require(
            probe["command"]["environment"] == selected["environment"],
            "probe exact route environment",
        )
        c.require(
            probe["live"] == config["live"]
            and probe["result"]["exitCode"] == 0
            and probe["result"]["childReaped"],
            "stable reaped readiness probe",
        )
        installation = Path(installed["installation"])
        c.require(str(installation / "installation.json") == selected["manifest"], "manifest route")
        for path, sha in (
            (selected["manifest"], installed["manifestSha256"]),
            (selected["command"], installed["commandSha256"]),
            (selected["payload"], installed["querySha256"]),
            (str(installation.parent / "management.json"), installed["receiptSha256"]),
        ):
            c.require(c.digest(Path(path)) == sha, "installed identity " + path)
            config["identities"][path] = sha
        manifest = c.load(Path(selected["manifest"]))
        c.require(
            manifest["payloadIdentity"] == installed["payloadIdentity"],
            "manifest artifact identity",
        )
        for entry in manifest["payloadFiles"]:
            path = installation / entry["path"]
            c.require(
                not path.is_symlink()
                and path.resolve(strict=True).is_relative_to(installation.resolve()),
                "owned regular payload",
            )
            c.require(
                "sha256:" + c.digest(path) == entry["sha256"], "manifest payload " + entry["path"]
            )
        verified[route] = len(manifest["payloadFiles"])
        for relative in (
            "bin/kast-query-complete",
            "bin/kast-tool-rpc",
            "bin/kast-tool-rpc-complete",
            "config/environment",
            "config/selected-ide.json",
            "share/kast/libexec/kast-management",
            "share/kast/agent-tools/plugins/kast/skills/kast/scripts/server.py",
        ):
            path = installation / relative
            config["identities"][str(path)] = c.digest(path)
        prior = receipt.parent / route
        c.declaration(c.load(prior / "stdout"), config)
        observations = c.load(prior / "host-receipts.json")
        c.check_receipts(observations, config, "discovery")
        a.host_identity({"receipts": observations}, config)
        for filename in ("command.json", "result.json", "stdout", "host-receipts.json"):
            path = prior / filename
            config["identities"][str(path)] = c.digest(path)
    c.require(
        config["routes"]["baseline"]["environment"]["JAVA_TOOL_OPTIONS"]
        == "-Duser.home=" + ready["home"],
        "baseline JVM shared home",
    )
    java = Path(config["controlJava"])
    for path in (
        receipt,
        java,
        java.parent.parent / "release",
        Path(ready["baselineJavaRouteProof"]),
        Path(ready["freshLifetimeAccounting"]),
        Path(__file__),
    ):
        config["identities"][str(path)] = c.digest(path)
    config["toolchains"]["status"] = "BOUND_TO_COPIED_IDEA_JBR_AND_SHA2_SOURCE_RECEIPTS"
    a.preflight(config)
    c.save(HERE / "ready.json", config)
    (HERE / "host-before.log").write_bytes(Path(config["hostLog"]).read_bytes())
    c.save(
        HERE / "binding-verification.json",
        {
            "state": "PASS",
            "hostPid": 35613,
            "live": config["live"],
            "verifiedPayloadFiles": verified,
            "setupPreparations": ready["freshLifetimeCompletedPreparations"],
            "productCalls": 0,
        },
    )
    print("PASS authoritative route/manifest/source/probe/host binding; no new product calls")


if __name__ == "__main__":
    main()
