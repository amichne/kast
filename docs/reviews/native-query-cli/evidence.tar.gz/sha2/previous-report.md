# Native query CLI evidence

The native client passes local checks and final installed IDEA semantic comparisons. The first paired cohort failed; diagnosis and live lifecycle acceptance remain in progress.
This report follows the October 30, 2026 specification, AC01–AC17. Every criterion began as NOT RUN.
No release, push, merge, or personal installation replacement occurred. The changes remain uncommitted.

The user temporarily waived compressed and installed byte-size checks. No other acceptance requirement was waived.
Repository size limits remain unchanged. A local Gradle init script overrides only those two limits for this run.
Entry count, executable format, exact producer identity, resources, and installation checks remain enabled.

## Source and executable identities

- Examined specification baseline: `96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a`.
- Refreshed baseline and candidate HEAD: `1e3a654d3ea4f160d603a37e5c574d5470c9a543`.
- Candidate: `/Users/amichne/code/kast.feature-native-query-cli`, branch `feature/native-query-cli`, with uncommitted changes.
- Pristine comparator: `/Users/amichne/code/kast.feature-native-query-baseline`.
- Existing work in `/Users/amichne/code/kast` was preserved.
- Tested tracked-diff SHA-256: `e3b99d1b54180e61a760a8366acba20e7396ea1f4930b55c7b6bb3dc711765f6`.
- `size-waived/source-identity.json` records the exact bytes of 40 changed source files, including untracked implementation files.

Evidence paths below are relative to `.amp/in/artifacts/native-query/`.
The portable [evidence archive](native-query-cli/evidence.tar.gz) contains raw results, collectors, source snapshots, and a per-file SHA-256 inventory.
`size-waived/previous-evidence-report.md` preserves the earlier report; its older artifact results do not qualify the final bytes.

| Final artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `kast-control-v0.0.0-macos-aarch64.tar.gz` | 78,170,952 | `e60ff3a754fd58adde0f22020274543ac33564aa88383e42a15a3d68e9848c0d` |
| Native `bin/kast-query` | 63,354,520 | `7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0` |
| Management executable | 37,193,480 | `f5c86b3c1ec27d676c4c19392213e7455d3b34d4e1a8ef3457a04b80a910ae01` |
| Baseline JVM query launcher | See installation inventory | `d900861b69aa77c80dce1c2bfba3d40340ca40f370fb8a297729cb43244708c2` |
| Baseline management executable | See installation inventory | `54386c967c713a4288e529fed654bd5436ff163c3912caf2ca81dfd275d8724c` |

The archive's management executable is `share/kast/libexec/kast-management`.
Its `bin/kast` is the private JVM installer script; installation creates the public native dispatcher.
The archive contains 15,520 regular files, 15,658 entries, and 156,074,460 regular-file payload bytes.
Both byte limits are SKIP under the waiver: 67,108,864 compressed and 134,217,728 installed bytes.
The 16,384-entry limit remains enabled and passes.

Oracle GraalVM 25.0.2+10.1, Java 25, `--no-fallback`, exact reachability metadata, and `-Os` produced the macOS arm64 query image.
The build also sets `fallback=false`. No wrapper supplies JVM fallback.
The query image took 70 seconds to generate, with 3.76 GB builder peak RSS.
The complete query build command took 90 seconds. The management image took 50.3 seconds, with 2.96 GB builder peak RSS.
These are build costs, not query execution measurements.
Linux native and IDEA acceptance remain NOT RUN; this report qualifies only the exercised macOS arm64 target.

## Acceptance record

PASS requires executed assertions at the stated scope. FAIL records an observed contradiction.
NOT RUN means complete evidence is missing. SKIP records an explicit waiver or disabled suite, not a behavioral pass.

| Criterion | Result | Evidence and remaining scope |
| --- | --- | --- |
| AC01 | PASS | Final archive query matches its native producer. Format and no-fallback checks pass. Substitution tests reject changed bytes and a matching shell-script producer. |
| AC02 | NOT RUN | Final installed execution policy proves zero client JVM launches for 23 exercised calls, with direct/descendant absolute-JBR controls. Successful issued-token RESUME remains unverified, so complete command coverage is not passed. |
| AC03 | PASS | Parser, encoded-contract, catalog, flags, file/stdin plans, defaults, and native rejection checks pass. COMMON restrictions remain distinct. |
| AC04 | PASS | The final native matrix passes all 158 cases, including both recursive plan descriptors. Network and writes are denied; HOME is empty, PATH lacks Java, and stdin stays open. |
| AC05 | PASS | Shared-context tests and native peer installations cover markers, fences, spaces, unrelated directories, foreign/detached installations, and replaced payloads. Installed live invocation evidence remains part of AC12. |
| AC06 | PASS | Actual native peers reject wrong roots/hosts, incompatible platforms, replaced socket incarnations, malformed JSON, duplicate keys, and trailing documents. Exact failure categories and record cleanup pass. |
| AC07 | PASS | Typed output/exit fixtures, native output tests, and actual pagination pass. Real explicit 1 ms timeout selects native 124 versus baseline 6 with identical rejection bytes. |
| AC08 | PASS | Final installed bytes pass independent real IDEA declaration/caller/range/coverage checks, full-document parity, absent-name/wrong-target controls, and comparator mutation checks. |
| AC09 | NOT RUN | Final bytes pass 30 retained reads and ten source reads in separate processes, including exact baseline-issued capabilities and no producer replay. Successful issued-token RESUME remains unverified. |
| AC10 | PASS | Final native process tests pass both signals at proven incomplete-input and active-socket states, with socket closure, exact child reaping, and no replay. |
| AC11 | PASS | Native sampled blocked writes stop without consumer drain. Broken stdout selects exit 5. Output-prefix and terminal-order checks pass. |
| AC12 | NOT RUN | Exact native/JVM ownership and PID-reuse controls pass. Final live shutdown and mixed-version rollback await fixture release after semantic collection. |
| AC13 | PASS | Queue, connection, executor, backpressure, and read-accounting tests preserve active ownership until analysis drains. Client exit supplies no host-settlement claim. |
| AC14 | PASS | Shared JVM contracts, 43 task-service/transport tests, and the actual final packaged stdio service with its JVM RPC child pass. The live call preserves the exact source, host, basis, and expected declaration. |
| AC15 | PASS | Final archive identity/layout and disposable installation pass; only the two byte checks are SKIP by user instruction. Processed resources and manifest-owned selection pass. No other platform is qualified. |
| AC16 | FAIL | Ten-process pilot passes. The 310-start cohort preserves 58 failures: one log-rotation gap and 57 lifecycle capacity rejections. Native metadata and retained-read observations are slower; no replacement or speedup claim is admitted. |
| AC17 | NOT RUN | Product and underlying source Gradle gates pass with the byte-only waiver. The source wrapper rejects the uncommitted tree before running; clean-source admission remains pending. Disabled suites are listed below. |

## Native resources and local effects

`size-waived/metadata-native/` contains all 158 named commands, inputs, outputs, environments, and results for the final digest.
Each process used `-XX:MissingRegistrationReportingMode=Exit`.
A macOS execution sandbox denied all network operations and filesystem writes. HOME remained empty and its entries unchanged.
All stderr files were empty; no missing-registration failure occurred.

The matrix covers both catalogs, metadata sections, help, 37 authored examples through files/stdin, 19 invalid examples, malformed input, and catalog restrictions.
Both `describe query.plan --section output` schemas contain 35 definitions and 316 locally resolved references.
NetworkNT Draft 2020-12 admission passed 99 checks: 95 valid replies and four invalid controls for basis and nested request-name constraints.
Without a stdin request, stdin remains unread; local metadata and plans do not compose a host session.

The inventory verifies 37 owned resources against the final 263-entry embedded-resource report.
Names, origin JAR digests, and sizes match. The report does not expose hashes of the embedded bytes themselves.
Processed properties contain `ideBuild=262.10315.125` and `kotlinPluginBuild=262.10315.125-IJ`, not template placeholders.
IDEA/K2 semantic implementation remains outside the client image.

## Acceptance fixes and their checks

The baseline's recursive plan-output descriptor overflowed its stack in both catalogs.
The schema owner now supplies canonical output references and their transitive local definitions.
Two real-entry tests failed with `StackOverflowError` before the change and passed afterward.
The expanded metadata suite passed 38 tests; final native qualification passed both formerly failing cases.
Evidence: `size-waived/metadata/` and `size-waived/metadata-native/`.

The host can reject an explicit elapsed allowance before an operation document exists.
Its `BUDGET_EXCEEDED / detail.cause CALLER_TIMEOUT` document previously selected protocol exit 6.
The narrow typed projection now selects 124 with an explicit grant, or semantic exit 10 without one.
Unknown failure/cause combinations still reject as protocol failures. The regression failed with actual 6 versus expected 124, then passed.
This is an intentional repair to an inherited classification defect, not byte-for-byte baseline exit parity.
The actual installed 1 ms comparison passes: baseline exit 6, native exit 124, and byte-identical rejection documents.

The lifecycle service selects JVM `user.home`, which the copied JBR does not derive from HOME.
The lifecycle environment now supplies exactly one quoted, generated `-Duser.home` property after filtering inherited options.
Controlled JBR execution confirmed HOME alone selected `/Users/amichne`; the generated property selected the disposable home.
Three tests passed, including quotes, newline, and option-looking text without property injection.
The private service entry and its Java-selection policy remain unchanged.

## Semantic fixture and independent oracle

The current fixture root is `/private/tmp/knq-lifecycle-5VGhDa`.
Candidate HOME is `h`; baseline HOME is `baseline-home`; the shared workspace is `workspace`.
The owned IDEA copy is `Owned IDEA.app/Contents`, with a distinct executable inode from personal IDEA.
Its project, configuration, system, logs, Gradle cache, and temporary files are disposable.
The first HOME path was shortened to fit the existing Unix-socket path limit.
Trust was configured only for this fixture. Personal IDEA PID 12733 was not stopped or modified.

The ready host is PID 22176, started October 30, 2026 at 08:23:49 local time.
Its project identity is `2cd3f767-77b0-448c-b166-d9c526738a37`, with final accepted epoch 2, `SAVED_PSI_COMMITTED`, version 1.
The endpoint is `h/.kast/ide-hosted/a60116eb29f516005321b15d8a2a7edd/endpoint.json` beneath the fixture root.
An IDE-owned import produced one imported project and three selected IDEA modules.
The copied IDEA's phased Gradle import was disabled through its existing registry setting after the first import produced zero modules.
Both clients use that same imported model. No production import policy changed.

The runner is macOS 26.5.2, build 25F84, arm64. The actual IDEA build is `IU-262.10968.63`.
Its selected JBR is `25.0.4+1-b508.27`, `JBR-25.0.4+1-508.27-nomod`.
These runtime versions are distinct from the processed compatibility properties and the GraalVM build toolchain above.

The candidate manifest SHA-256 is `45e892d90fa932beb305019512cca82d369965866971754308c18d902f9140f9`.
The management receipt SHA-256 is `33a18b28d068c9555b85acc07dbddacfae8d234b832a242b310862a1f2b112eb`.
Both candidate and baseline passed independent verification of 15,525 manifest entries, with zero rejections.
`size-waived/lifecycle/ready-host-receipt.json` binds launch, endpoint, basis, installation, and setup corrections.
Its SHA-256 is `7f5259a0da2bd0a7f29fab02b6c1f5217fae404781cd2325597eeab32abda541`.
That first receipt records epoch 1. The first correctness attempt rejected the later epoch 2 instead of normalizing it away.
Two new sequential baseline/native probes agreed on epoch 2 while all other identities stayed unchanged.
The new receipt is `size-waived/semantic/ready-epoch2-20261030T122938.550199Z/ready-host-receipt.json`.
Its SHA-256 is `f9bcf8430a7dc9b253023b08bec41134f9d25085cf8634fa71895bea95389e89`.
Earlier logs contain VFS and PSI/INDEXING epoch signals; no specific cause of the advance is inferred.

The saved [OrderService source](public-cli-v1/OrderService.fixture.txt) has SHA-256 `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`.
The copied source must keep those bytes.

| Independent expected declaration or occurrence | UTF-16 range, end-exclusive |
| --- | --- |
| `example.OrderService` | [17,94) |
| `example.OrderService.submitOrder` | [42,92) |
| `example.placeOrder` | [96,174) |
| `submitOrder` call in `placeOrder` | [152,163) |

The caller edge is exactly `example.placeOrder → example.OrderService.submitOrder`.
Direction is `SOURCE_TO_TARGET`, provenance `k2-authored-source`, and coverage `exact-compiler-confirmed`.
Absent-name and wrong-target controls must reject broader answers.
Fresh comparisons normalize only row IDs and consistently linked result references.
They keep host, workspace, basis, source, selected fields, completion, and coverage.
Retained reads use issued token bytes without normalization and must not replay the producer.

The earlier report incorrectly said transport/read joins were absent.
Raw logs contain `kast_transport_read`; the current collector requires exact connection-ID/read-ID joins.
Retained receipts must show RETENTION and zero producer/search/discovery/relation entries.
This is stronger than assigning one receipt to an arbitrary time interval.

Successful issued-token RESUME remains NOT RUN.
Source investigation found a consumer but no established supported public producer for this fixture.
Public automatic RUN uses retained result/cursor presentation; reducing output grants did not produce an output continuation.
The literal token in `HostedQueryRetainedPresentationTest` is not live authority.
No capability was fabricated or issued through a private owner to claim public acceptance.
Exact source paths, line ranges, and earlier attempted inputs are in `size-waived/measurements/resume-findings.md`.

## Complete client execution policy

The final correctness run applied a macOS sandbox policy to the installed public command and every descendant.
The policy denied process execution except for exact installed dispatcher, query-wrapper, and native-payload paths, plus `/bin/sh`, `/bin/bash`, and `/usr/bin/dirname`.
It contained no Java executable or directory allowance. Both installations and the copied JBR were digest-checked before execution.
The existing IDEA JVM was outside the client process tree and remained the semantic host.

Four controls tested the absolute copied-JBR path with the same policy mechanism.
Direct Java and shell-descendant Java succeeded when that exact executable was added to the allowance.
Without that allowance, direct execution exited 71 and shell-descendant execution exited 126, both with `Operation not permitted`.
The 23 installed native invocations then passed their document, exit, host/basis, and transport-to-read assertions under the Java-denying policy.
This proves zero client JVM launches for those invocations; it does not count native launches or qualify an unexercised successful RESUME.
Raw policies, controls, commands, and receipts are in `size-waived/semantic/run-002-corrected/`.

## Paired collection contract

`collection-decision.md` remains frozen. `size-waived/measurements/collection-amendment.md` records only the user-authorized size waiver.
The protocol requires a passing ten-process pilot, excluded from measurements.
Each workload receives one warm-up per route and 30 alternating baseline/native fresh-process pairs.
The order is retained read, metadata, request-only plan, discovery, then callers: 300 measured starts plus ten warm-ups.
Retained reads use one pre-existing issued result; producer execution stays outside every timed read.
The baseline and candidate use the same ready host, workspace, source, basis, scope, fields, catalog, and grants.
Builds and other fixture clients must stay idle during the cohort.

The collector records each start before assertions, exact argv/environment/input, exit, stdout/stderr, output EOF, and monotonic duration.
It preserves log slices, decoded receipts, load averages, and `wait4` CPU/RSS accounting for the waited public child.
That accounting is not full descendant telemetry or summed concurrent process-tree RSS.
Missing execution counts remain UNAVAILABLE, not zero.
Complete execution-policy proof is separate from latency collection.

The report keeps every started sample, including failures, with count, median, empirical p95, range, and paired differences.
Percentiles describe this cohort; they are not a statistical power claim.
Process time minus hosted time is not JVM startup time.
Until the final valid cohort completes, no speedup claim is made.

The first complete cohort, `size-waived/measurements/cohort-001/`, is FAIL: 310 starts and 58 failed sample assertions.
Discovery sample 191 exited 0 but lost its receipt when the host log rotated at offset 9,948,695.
Caller samples 253–309 exited 4 with `daemon-operation-lifecycle-capacity` before semantic execution.
The collector preserved all samples and marked every population ineligible for a latency claim.
Its summary contains the raw descriptive statistics, including the slower native metadata and retained-read observations.
No failed sample was removed or converted into a successful comparison.

## Focused checks and repository gates

| Check | Cases | Result |
| --- | ---: | --- |
| Final CLI JVM suite | 557 | PASS; zero failures/skips |
| Final management JVM suite | 284 | PASS; zero failures/skips |
| Final actual-native process suite | 7 | PASS; zero failures/skips |
| Final JVM Unix-socket suite, `:cli:udsTest` | 4 | PASS; zero failures/skips |
| Hosted queue/connection/retention owners | 21 | PASS |
| Hosted executor/backpressure/read accounting | 19 | PASS |
| Retained-row admission | 10 | PASS |
| Python task-service/transport | 43 | PASS |
| Source-gate consumer tests | 13 | PASS |
| Native artifact substitution | 1 | PASS; altered bytes and script producer both reject |

Final XML and counts are in `size-waived/gate-tests/`.
`verifyJsonContracts`, architecture, verification graph, knowledge, formatting, and `Detekt` checks passed in the product gate.
Generated graph and provenance files changed through their owners.
The GraalVM plugin reserves `nativeTest`; the existing JVM socket suite was renamed `udsTest` with its CI consumers.

The native tests use actual candidate bytes, not the former JVM fixture launcher.
Blocked-output tests require an exact native worker stack and kernel write frame, rather than a delay or a live PID.
They interrupt without draining the consumer and preserve the terminal-event and single-document rules.
Real Unix peers prove transport/admission behavior only, not compiler semantics.
Host queue/executor tests separately prove that cancellation does not retire active analysis before it drains.

The full product gate completed in 6m 16s: 645 actionable tasks, 164 executed, four from cache, and 477 up-to-date.
Its `sourceValidationGate` passed. The clean-source wrapper separately rejected uncommitted changes before tests.
Semantic fixture suites were SKIP because `KAST_SEMANTIC_FIXTURES` was unset.
Three opt-in Codex suites were SKIP: `CodexProtocolQualifierTest`, `ManagedCodexUpstreamTest`, and `NativeCatalogAdmissionTest`.
These omissions supply no semantic or adapter pass. Live IDEA and packaged stdio checks supply only their exercised assertions.
The standalone documentation verification command also passed; its complete output is `size-waived/documentation-check.log`.

## Exact commands and source owners

Commands ran from the candidate checkout unless stated otherwise. Raw logs keep all failed attempts.

```sh
# Baseline checkout; numeric, immutable comparison product.
mise exec -- ./gradlew -Pversion=0.0.0 assembleKastControlDist generateHostReleaseRecord \
  -PhostedIdeaHome='/Users/amichne/Applications/IntelliJ IDEA.app/Contents' --console=plain

# Recursive descriptor RED and GREEN, using the same selector.
mise exec -- ./gradlew -Pversion=0.0.0 :cli:test \
  --tests '*PublicCliProcessTest.real plan output descriptor*' --console=plain

# Final product/source gate; only byte limits overridden by this local init script.
mise exec -- ./gradlew -Pversion=0.0.0 -I .amp/in/size-waiver.init.gradle \
  -Dorg.gradle.unsafe.isolated-projects=false --no-configuration-cache --max-workers=2 \
  -Dorg.gradle.jvmargs=-Xmx5g productBuildGate --console=plain

# Separate clean-source admission: rejected before tests because changes are uncommitted.
mise exec -- python3 .github/scripts/ci/source_validation.py
```

`size-waived/size-waiver.init.gradle` preserves the exact waiver script.
`size-waived/metadata-native/commands.txt` records every local native argv and sandbox setting.
Lifecycle records preserve exact installer and IDEA launch environments, ownership identities, and manifest checks.
Semantic and measurement scripts use locked, dependency-free uv execution; their readiness checks reject incomplete configurations before product execution.

| Invariant | Source owner |
| --- | --- |
| One admitted runtime installation | [InstalledClientContext](../../cli/src/main/kotlin/io/github/amichne/kast/cli/direct/InstalledClientContext.kt) |
| Shared session/record context | [KastDirectToolSession](../../cli/src/main/kotlin/io/github/amichne/kast/cli/direct/KastDirectToolSession.kt), [OneShotInvocationRecord](../../cli/src/main/kotlin/io/github/amichne/kast/cli/rpc/OneShotInvocationRecord.kt) |
| Query-only Java removal | [InstallationWorkflow](../../cli/src/main/kotlin/io/github/amichne/kast/cli/installation/InstallationWorkflow.kt) |
| Exact native/JVM ownership | [LifecycleProcesses](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/LifecycleProcesses.kt) |
| Shared status/retirement admission | [OneShotObservation](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/OneShotObservation.kt), [InstallationRequestRetirement](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/InstallationRequestRetirement.kt) |
| Selected lifecycle home | [InstallationLifecycle](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/InstallationLifecycle.kt) |
| Recursive output schema | [InstalledServerProjectionDocuments](../../cli/src/main/kotlin/io/github/amichne/kast/cli/bootstrap/InstalledServerProjectionDocuments.kt) |
| Public timeout classification | [PublicShellExit](../../cli/src/main/kotlin/io/github/amichne/kast/cli/publicshell/PublicShellExit.kt) |
| Sole producer and assembly | [CLI build](../../cli/build.gradle.kts), [root build](../../build.gradle.kts) |
| Payload identity and limits | [VerifyDistributionTasks](../../build-logic/src/main/kotlin/support/tasks/verification/VerifyDistributionTasks.kt) |

The evidence archive excludes product binaries, HTML compiler reports, and bytecode caches.
It retains raw commands/results, source identity, execution policies, manifests, resource inventories, failed attempts, and collection code.
An archived source snapshot proves which bytes were tested; it does not turn an uncommitted tree into admitted release source.
