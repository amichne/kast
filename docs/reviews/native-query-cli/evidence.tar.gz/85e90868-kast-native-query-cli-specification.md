# Kast native query CLI specification

**Status:** Proposed implementation specification. Implementation and acceptance runs: **NOT RUN**.  
**Date:** October 30, 2026.  
**Source baseline:** [amichne/kast main at 96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a][s00].  
**Product outcome:** Public query commands use a GraalVM native client and reuse the existing IDEA host.

## 1. Outcome and validation contract

Replace the JVM query client with a GraalVM Native Image executable built from the existing Kotlin/JVM implementation.

A public query against a ready IDEA project must start **zero client JVMs**. The query must preserve the current request, result, failure, cancellation, and installation contracts.

The native client remains disposable. IDEA keeps compiler analysis, project state, semantic authority, and retained output. Native compilation must not introduce another daemon.

The first implementation keeps the current public dispatcher and selected launcher. The installed route remains:

| Entry | Responsibility | Execution form |
| --- | --- | --- |
| Public kast | Admit the selected query launcher, forward argv and signals, and reap its child. | Existing native executable. |
| installation/bin/kast-query-complete | Select configuration and apply installation guards. | Existing shell wrapper, adapted for native execution. |
| installation/bin/kast-query | Parse, admit, send, receive, project, and publish the request. | New GraalVM native executable. |
| IDEA project services | Execute semantic operations and own retained state. | Existing persistent IDEA process. |

The wrapper must use exec for the native payload. It must not select Java or start a JVM.

Two native processes are acceptable for this increment. Combining the dispatcher and query entry is outside this increment.

### 1.1 Decisive acceptance

The installed public command must return a known compiler-grounded result through the native query payload. Its entire client execution must contain no JVM launch.

The same process test must preserve the established host identity and workspace basis. A later native process must read an issued retained result.

A native build alone does not establish this outcome. A management command, substituted JVM fixture, or scripted semantic response also does not establish it.

### 1.2 Preserved invariants

- IDEA remains the sole source of live compiler authority.
- Existing typed admission owns the public grammar and canonical request.
- Existing response admission owns result shape, compatibility, and finite failures.
- The public default remains COMPLETE. Explicit COMMON restrictions remain intact.
- Installation admission precedes semantic effects.
- Local metadata and request-only plans remain independent of host composition.
- Retained handles remain bound to their original host, workspace, basis, and result owner.
- Cancellation requests, client exit, and host settlement remain distinct facts.
- Expected failures preserve their current public categories and exit codes.
- The selected native payload must have one build producer and one manifest identity.

### 1.3 Scope

Include all commands currently dispatched through the public query namespaces: query, result, source, and describe. Preserve their current help and request-only planning behavior.

Include the native build, resources, installation context, wrapper, lifecycle ownership, product assembly, and acceptance evidence.

Keep the existing JVM MCP, tool RPC, and private service entries. Shared code changes must preserve those entries.

Exclude a Kotlin/Native port, compiler migration, new transport, pooled sockets, new daemon, and MCP task-service redesign.

Exclude new query semantics, changed budgets, new default timeouts, and a broader hot-reload policy. Preserve the host's current reload and retirement rules.

The implementation must support each release target it claims. A Linux control archive does not prove Linux IDEA acceptance.

This specification defines implementation work. It does not publish a release, merge a change, or replace a personal installation.

## 2. Baseline, scope, and evidence

### 2.1 Source facts

The author inspected the following owners at the pinned revision. These facts describe source behavior, not a new runtime experiment.

| Fact | Source owner | Consequence |
| --- | --- | --- |
| The public management executable already uses GraalVM, Java 25, and no JVM fallback. | [distribution/cli/build.gradle.kts][s01] | Reuse the existing native toolchain. |
| The public query dispatcher starts kast-query-complete as an owned child. | [PublicQueryDispatch.kt][s02] | Preserve the public process contract. |
| publicQueryStartScripts produces the JVM query launcher. | [cli/build.gradle.kts][s03] | Replace that producer for the shipped query payload. |
| The query wrapper always adds installationJavaRuntimeEnvironment. | [InstallationWorkflow.kt][s04] | Remove Java selection from the query wrapper only. |
| Direct session composition discovers a JAR beneath lib. | [KastDirectToolSession.kt][s05] | Supply an admitted installation explicitly. |
| Invocation recording independently assumes the same JAR layout. | [OneShotInvocationRecord.kt][s06] | Adapt both consumers of installation identity. |
| Ordinary lifecycle admission accepts query workers only as Java processes. | [LifecycleProcesses.kt][s07] | Add exact native process ownership. |
| Force reset already recognizes scoped kast-query paths. | [ForceDaemonRuntime.kt][s08] | Preserve that behavior without another reset mechanism. |
| The client uses contracts and transport code, without an IDEA implementation dependency. | [CLI dependencies][s03] and [app-server dependencies][s09] | Keep compiler code outside the image. |
| Public schemas and examples load through resource names. | [PublicToolContract.kt][s10] | Include every resource reached by the supported commands. |
| Response admission uses packaged schemas, NetworkNT, and Jackson. | [ExistingIdeDocuments.kt][s11] | Qualify those dependencies in the actual native executable. |
| Compatibility admission reads processed kast-hosted-platform.properties. | [HostedServicesObservation.kt][s12] and [resource processing][s13] | Package expanded platform identities, not the source template. |
| Semantic exchanges use short Unix-socket connections. | [ExistingIdeSocketClient.kt][s14] | Keep the current transport and live compatibility checks. |
| Retained query state belongs to an IDEA project service. | [HostedQueryContinuations.kt][s15] | Client exit must not retire retained output. |

The current control archive gate permits at most 64 MiB compressed and 128 MiB installed. It also limits file entries to 16,384. [Product assembly and limits][s16]

### 2.2 Inherited measurements

The existing public CLI report records three public samples with a 2,217.835 ms median process duration. Their recorded hosted-read median is 11.677 ms.

The report attributes the residual to startup, admission, preparation, transport, and output together. It does not isolate JVM startup. [Prior evidence][s17]

Treat these values as historical context. Establish a fresh baseline before comparing the native candidate.

No native-query build, native-query behavior, or native-query latency result exists in this specification.

### 2.3 Unresolved qualification

Native compatibility of the complete selected client graph remains unproven. NetworkNT, Jackson, resources, and native process behavior need actual execution evidence.

Source inspection establishes two JAR-layout assumptions and Java-only lifecycle ownership. These are concrete adaptation tasks.

A missing native registration is a diagnosed build or runtime issue after reproduction. Do not assume compatibility or incompatibility from a library name.

### 2.4 Refresh before implementation

Fetch current main before changing source. Preserve existing work and use a separate checkout when necessary.

Record the selected full SHA and compare the named owners with this baseline. Inspect the scoped AGENTS.md files.

If main changes the same client or installation contract, revise the affected sections first. Do not transplant obsolete launcher logic.

Keep source facts, inherited results, new execution, and proposed choices separate in the evidence report.

## 3. Acceptance criteria

Every criterion starts as **NOT RUN**. PASS needs every assertion at its stated scope.

Pure tests establish deterministic rules. Process tests establish executable behavior. Real IDEA runs establish compiler-backed integration.

| ID | Behavior and independent oracle | Smallest evidence scope and negative control |
| --- | --- | --- |
| AC01 | The packaged kast-query payload is a native executable for its declared platform. Its build disables JVM fallback. | Inspect the exact archive artifact, executable format, build identity, and digest. A shell or JVM launcher substituted at that path must fail artifact admission. |
| AC02 | Every supported semantic command against a ready host starts zero client JVMs. | Run the exact installed public route with complete execution evidence. A baseline or deliberate JVM control must prove that the collector detects JVM launches. |
| AC03 | Flags, file input, and stdin preserve canonical meaning, field selection, order, defaults, and catalog restrictions. | Reuse independent parser and encoded-contract fixtures. Unsupported COMMON grammar must reject without promotion. |
| AC04 | Metadata, examples, schemas, help, plans, and invalid-input rejection avoid host effects. | Use forbidden lifecycle/socket capabilities and native processes outside a workspace. Unrequested stdin remains unread. Remove client Java availability. |
| AC05 | One admitted installation context supports native session composition and invocation recording. | Exercise real installation paths, marker/fence failures, paths with spaces, and unrelated working directories. A foreign or detached installation must reject. |
| AC06 | Endpoint and response admission preserve exact ownership, compatibility, framing, and finite failures. | Exercise a controlled Unix peer and filesystem identity. Wrong roots, replaced socket incarnations, malformed responses, duplicate response keys, and trailing response data must preserve existing rejections. |
| AC07 | JSON delivery and public exit policy preserve the existing contract. | Use independent typed fixtures and the native executable. Cover complete output, ordinary pagination, semantic qualification, retained policy rejection, delivery failure, and malformed replies. |
| AC08 | The native client preserves actual IDEA semantic results. | Run baseline and candidate against one ready fixture host and saved source. Compare independent known declarations, caller edges, source ranges, coverage, completion, and fields. Include absent-name and wrong-target controls. |
| AC09 | Retained results, source reads, pagination, and supported resume behavior survive client exit. | Native process A issues handles and exits. Process B uses their exact bytes. Preserve row/evidence cursors and outcomes. Prove READ_RESULT does not rerun its producer. Existing owner tests cover expiry and retired authority. |
| AC10 | Signals settle the owned native invocation with the existing terminal-event policy. | At proven incomplete-input and active-socket states, send SIGINT and SIGTERM. Confirm existing exits, connection closure, child reaping, and no automatic replay. |
| AC11 | Blocked and broken stdout cannot strand the invocation or trigger a second document. | Establish native-compatible backpressure evidence. Interrupt without a consumer drain. Exercise the broken-consumer case and both terminal-event orders. |
| AC12 | Status, stop, replacement, rollback, and reset recognize the native worker through exact ownership. | Exercise live native records plus pure identity cases. A foreign same-named process, changed start time, or replaced executable must not gain retirement authority. Qualify rollback with a live native query before restoring a Java-only owner, as specified in section 6.3. Preserve JVM MCP/RPC admission. |
| AC13 | Host cancellation keeps its existing settlement rules. | Reuse hosted queue, cancellation, and executor oracles. Queued cancellation prevents dispatch. Active ownership persists until compiler analysis drains. Client exit alone cannot prove settlement. |
| AC14 | Shared changes preserve the installed MCP/RPC contracts and adapters. | Run existing encoded-contract tests and a real stdio task-service session with its actual packaged RPC child. Malformed child replies reject without retries. JVM launches on those unchanged routes remain in scope only as compatibility facts. |
| AC15 | The assembled product selects exactly the qualified payload and resources. | Install a candidate archive in an owned temporary root. Confirm manifest digests, launcher selection, processed compatibility metadata, artifact limits, and supported-platform behavior. |
| AC16 | The performance report measures the removed work and end-to-end behavior separately. | Use the frozen paired protocol in section 5.3. Keep all samples and semantic comparisons. A faster but narrower query must fail equivalence. |
| AC17 | The implementation passes its focused checks and the repository's source and product gates. | Record exact source identity, commands, results, disabled suites, and omissions. A zero-test run or missing native environment does not pass a required criterion. |

### 3.1 Public output and exit contract

Use PublicShellExit and its classification owners as the source of truth. [PublicShellExit.kt][s18]

| Exit | Meaning |
| --- | --- |
| 0 | Complete under the existing semantic and delivery policy. |
| 1 | Local defect. |
| 2 | Invalid input. |
| 3 | Workspace rejection. |
| 4 | Runtime or installation rejection. |
| 5 | Input/output failure. |
| 6 | Protocol rejection. |
| 9 | Bootstrap rejection. |
| 10 | Semantic qualification or rejection under the existing policy. |
| 11 | Delivery failure under the existing policy. |
| 124 | Explicit elapsed allowance exhausted under the existing policy. |
| 130 | SIGINT wins the terminal-event policy. |
| 143 | SIGTERM wins the terminal-event policy. |

Preserve classification, not just the numeric set. Ordinary pagination remains successful when semantic completion and delivery permit it.

Retained policy rejection stays nonzero on later pages. Smaller output must not erase evidence or promote an incomplete result.

Successful delivery emits one JSON document and one newline. Interrupted partial output must not receive a second error document.

### 3.2 Proof of zero client JVMs

Start with an already-ready IDEA host. Record its process identity, project identity, source basis, and platform versions.

Invoke the installed public command. Do not invoke an adjacent test binary and infer installed behavior.

Inspect the packaged payload's native format and no-fallback build. Correlate that payload with the executable selected by the launcher.

Capture client execution for the full invocation. Use complete descendant execution events or an equivalent enforced execution policy.

The proof must cover absolute executable paths. Missing Java on PATH does not cover the current absolute JBR launch.

Use a positive JVM control with the same collector. Report incomplete collection as NOT RUN.

Before/after process snapshots and missing startup messages do not prove absence. Neither does successful execution of kast status.

A particular tracing utility is not mandatory. The execution evidence must establish the same property with available supported mechanisms.

IDEA's existing JVM is expected. A separate cold-host case can start IDEA through its current lifecycle owner.

## 4. Deliverable segments

### Segment A — Installation identity and worker ownership

**Outcome:** Native and JVM clients use explicit installation evidence, and lifecycle operations distinguish their exact process owners.

**Validation first:** Characterize existing installation admission and process matching. Add native ownership cases before changing lifecycle dispatch.

Use fixed process snapshots for PID reuse, foreign paths, and missing identity. Use a private filesystem for executable identity and manifest cases.

**Change scope:**

1. Supply admitted installation context to direct session composition.
2. Supply the same context to OneShotInvocationRecord.
3. Preserve one-shot markers, shutdown fences, process start identity, and exact-file cleanup.
4. Keep context creation lazy until a semantic command needs it.
5. Add a closed native-query process variant to the existing lifecycle owner.
6. Preserve the existing JVM variant for MCP and tool RPC.

Reuse an existing admitted installation type when it expresses these facts. Otherwise introduce one narrow type with a private construction path.

The context must identify the canonical installation, admitted payload, and existing configuration source. A raw path alone cannot grant ownership.

Resolve current process and filesystem facts at runtime. Do not capture HOME, workspace paths, process identifiers, or installation state during image construction.

Native ownership must combine the recorded PID/start time with the exact selected executable and its admitted installation evidence.

Do not accept a process because its basename is kast-query. Do not weaken the existing PID-reuse behavior.

Keep ordinary shutdown and force reset distinct. Reuse each operation's established authority rules.

**Acceptance:** AC04, AC05, and AC12 pass at their stated scopes.

**Dependencies:** Source refresh and baseline characterization. Segment B can develop pure native configuration in parallel.

### Segment B — Native query payload

**Outcome:** The current Kotlin/JVM query implementation runs as a native executable.

**Validation first:** Define the native process entry and resource inventory. Run existing parser, output, and failure oracles before native compilation.

**Change scope:**

- Add a Native Image entry for the public query client.
- Reuse the pinned Java 25 native toolchain and no-fallback policy.
- Keep parsing, canonical admission, lifecycle transport, response admission, and shell policy in their current owners.
- Adapt installation composition through Segment A.
- Compile only the client path. Keep IDEA/K2 implementation code in the host.
- Register the resources and dynamic features reached by supported commands.
- Keep MCP framing and private RPC entry behavior unchanged.

A native entry in the existing client module is the initial implementation choice. A broad module extraction is not a prerequisite.

If coupling blocks compilation or materially expands the reachable graph, move the smallest shared client owner. Do not copy the grammar or result projection.

Shared public response code currently crosses MCP/RPC names. Move ownership only when the native composition needs that separation.

Preserve the existing strict JSON and schema rules. A native build must not succeed by bypassing admission or swallowing metadata failures.

Use exact reachability diagnostics during native qualification. Missing registration failures must remain visible in the test process. [GraalVM metadata guidance][g02]

#### Resource obligations

Derive the final list from actual resource access and generated outputs.

The inventory includes:

- Public parameter schemas, examples, and selected catalog variants.
- Endpoint, response, and owner schemas under the current resource paths.
- Processed kast-hosted-platform.properties.
- Generated contract resources reached by discovery, plans, and semantic execution.
- Third-party metadata needed by the selected schema and serialization implementations.

The platform properties must contain expanded pinned identities. A raw template cannot establish compatibility.

Package immutable contract data at build time where sound. Read installation, workspace, and host facts at runtime.

Native compilation alone does not prove every resource path. Exercise discovery, query, result, source, and rejection branches in the native executable.

**Acceptance:** AC01, AC03–AC07, AC10, and AC11 pass for the native payload. AC08 and AC09 await real IDEA acceptance.

**Dependencies:** Segment A supplies installation composition. Native resource work can proceed independently of archive assembly.

### Segment C — Product assembly and launcher selection

**Outcome:** The installed public command selects the qualified native client through the current paths.

**Validation first:** Record baseline launcher bytes, manifest ownership, and archive inventory. Add a fixture that rejects an unqualified replacement payload.

**Change scope:**

1. Replace publicQueryStartScripts as the producer of the shipped bin/kast-query payload.
2. Connect one explicit native artifact producer to stageKastControlProduct.
3. Remove or exclude the old query start-script output at its owner.
4. Preserve the selected bin/kast-query-complete wrapper.
5. Omit installationJavaRuntimeEnvironment for that query wrapper.
6. Regenerate manifests, digests, component records, and generated provenance through their owners.

Do not let copy order choose between native and JVM producers.

The query wrapper must preserve configuration selection, regular-file rules, KAST_SESSION_ROOT removal, detached-installation rejection, and exact argv forwarding.

Private MCP, RPC, and service wrappers keep their existing Java setup. Their JVM requirements must not leak into the query wrapper.

Keep the public native dispatcher thin. It continues to admit the manifest-owned launcher, forward signals, and reap its child.

Test the installed route from an unrelated working directory and a path with spaces.

Measure complete archive and installed sizes. Keep the existing 64 MiB, 128 MiB, and entry-count gates.

If the candidate exceeds a gate, first remove duplicate producers or unnecessary reachable content. Report the measured limit if it still blocks completion.

Do not silently raise archive limits or remove JVM resources still used by MCP/RPC.

A missing native payload must reject through the existing public startup failure policy. It must not trigger a JVM fallback.

**Acceptance:** AC01, AC02, AC05, AC12, and AC15 pass for the assembled product.

**Dependencies:** Segments A and B. Manifest generation must use the final candidate bytes.

### Segment D — Behavioral parity and measured execution

**Outcome:** The installed native route preserves behavior and supplies reproducible performance evidence.

**Validation first:** Freeze independent fixtures, comparison rules, process evidence, and the measurement protocol before collecting candidate results.

**Change scope:** Adapt existing test launchers and add the smallest missing native process coverage.

Two existing tests need specific treatment:

- PublicLauncherCompositionTest substitutes a shell launcher that starts a JVM.
- PublicOutputCancellationTest starts Java and identifies backpressure through jcmd and Java stack frames.

Their behavioral oracles remain useful. Their current execution mechanisms do not prove native behavior. [Launcher test][s19] [Blocked-output test][s20]

Keep deterministic parser, failure, and terminal-event tests at their current scope. Native process tests must invoke the actual candidate executable.

For blocked output, use a native-compatible precondition. Establish a full pipe and the writer's blocked state through supported evidence or deterministic I/O synchronization.

A sleep or a still-running process does not establish backpressure. Test-only synchronization must not add a production bypass.

For transport, use a real local Unix peer. A scripted response proves framing and admission, not compiler semantics.

For semantic acceptance, reuse the existing disposable IDEA fixture. Preserve exact source, host, workspace, and contract identities.

For host cancellation, reuse the existing queue/executor tests. Do not equate a reaped native client with drained compiler work.

**Acceptance:** AC02–AC17 pass at their stated scopes. The evidence report identifies limits on every performance claim.

**Dependencies:** The final installed native candidate from Segment C.

## 5. Execution and integration

### 5.1 Sequence and ownership

One integration owner controls installation types, public contracts, artifact selection, and the final evidence report.

Independent work can cover native resource qualification, pure ownership tests, and acceptance fixtures. Shared contracts must not diverge across those tasks.

Use this sequence:

1. Refresh main and record the source baseline.
2. Read the scoped repository instructions.
3. Establish existing behavior and the acceptance oracles.
4. Adapt installation context and native worker ownership.
5. Build the actual native query payload.
6. Exercise native input, output, socket, and lifecycle behavior.
7. Assemble and install the candidate in a private fixture.
8. Run real IDEA parity and retained-result acceptance.
9. Collect matched measurements from the qualified artifacts.
10. Run the repository gates and produce the final report.

Do not start a broad client rewrite to avoid a concrete native failure. Diagnose the smallest failing dependency or resource first.

### 5.2 Existing checks and evidence owners

Use existing owners before adding a parallel test harness.

| Obligation | Existing owners |
| --- | --- |
| Input, budgets, discovery | PublicCliArgumentsTest, PublicCliBudgetTest, PublicCliDiscoveryTest, PublicCliProcessTest, PublicCliMissingMetadataTest. |
| Public outcomes | PublicShellExitTest, PublicSourceExitTest, PublicRuntimeFailureTest, PublicFailureRegressionTest. |
| Terminal-event precedence | PublicInvocationOwnerTest and the public invocation owner. |
| Process and output behavior | PublicLauncherCompositionTest and PublicOutputCancellationTest, adapted as described in Segment D. |
| Retained state | QueryRetainedRowAdmissionTest, HostedQueryRetainedPresentationTest, HostedContinuationOwnerRetentionTest, HostedCompletionRejectionPublicationTest. |
| Host cancellation | HostedQueuedConnectionCancellationTest, HostedConnectionAdmissionTest, HostedQueryExecutorTest, HostedQueryBackpressureTest, HostedReadActionAccountingTest. |
| MCP task compatibility | packaging/task-access/test_service.py, test_transport.py, and Kotlin MCP/RPC contract suites. |
| Product assembly | verifyKastControlDistLayout, installedProductTest, and the current product gate. |

Resolve exact selectors against the refreshed checkout. Do not report a renamed or zero-test selector as a pass.

The current repository entry points include:

~~~sh
mise exec -- ./gradlew :cli:test --tests 'io.github.amichne.kast.cli.publicshell.*'
mise exec -- ./gradlew :publicLauncherTest
mise exec -- ./gradlew verifyJsonContracts
mise exec -- ./gradlew verifyKastControlDistLayout
mise exec -- python3 .github/scripts/ci/source_validation.py
mise exec -- python3 distribution/release/run_product_gate.py
~~~

These are baseline entry points, not a complete fixed command list. Use the current scoped instructions for changed modules and generated files.

Add the native query target to the product composition. Do not invent a task path before its owner exists.

The source and product gates have environment and tree-state prerequisites. Report setup failures separately from behavioral failures.

Compiler fixture suites are disabled by default at the examined revision. Enable them when their assertions supply claimed compiler evidence.

A skipped compiler suite supplies no semantic pass. A disposable IDEA case supplies only the behavior it actually exercises.

### 5.3 Measurement protocol

**Purpose:** Separate the elimination of client JVM launches from changes in end-to-end latency.

First record baseline and candidate source SHAs, executable digests, toolchain versions, platform, and installation manifests.

Freeze requests, workspace source, IDEA version, selected host, catalog, fields, scope, and result/byte grants.

Use one ready host for paired runs when compatibility permits. Otherwise disclose the host difference and narrow the comparison claim.

Keep initial host startup outside the ready-host cohort. Record cold lifecycle behavior separately.

#### Workloads

Use these populations separately:

1. Local metadata and request-only planning.
2. A small semantic discovery query.
3. A supported relation query with known independent results.
4. A retained-result read from a pre-existing producer result.

The semantic pair must ask the same question. Narrower scope, fewer fields, or different limits create a separate experiment.

READ_RESULT measurements must exclude producer execution. Reuse the exact issued result where supported.

Exclude the Python task-MCP route from this comparison. Its catalog-plus-call sequence is a different workload.

#### Collection

Run a pilot to establish fixture readiness and collection coverage. Exclude pilot samples from the reported cohort.

Use 30 paired fresh-process samples per semantic workload and retained-read workload. Alternate baseline-first and candidate-first pairs.

This is a proposed bounded collection design, not an existing latency threshold or a statistical power claim.

Freeze warm-up counts and the metadata/planning sample count before collection. Do not change them after inspecting candidate timings.

Keep every started sample. Mark failures, interruptions, and unavailable fields explicitly.

Record external workload and host/basis changes. If a change invalidates pairing, record the invalid cohort before repeating it.

#### Measurements

| Measurement | Unit and interpretation |
| --- | --- |
| Client JVM launches | Count across the complete client execution. Target: zero for candidate ready-host calls. |
| Native client launches | Count and executable identities. This increment permits the dispatcher and one native query payload. |
| Public process duration | Monotonic elapsed milliseconds through process exit and output completion. |
| Lifecycle work | Preparation count and duration when available. |
| Hosted exchanges | Count by lifecycle, status, and operation. Do not collapse different interfaces. |
| Semantic work | Invocation count and available unchanged host counters. |
| Output | Exact stdout bytes and admitted document comparison. Bytes are not tokens. |
| Resource use | Client peak RSS and CPU time when available. Missing data is unavailable, not zero. |
| Build and artifact cost | Native build duration, executable bytes, archive bytes, and installed bytes. |

Report sample count, median, empirical p95, range, and paired duration differences. Label percentiles as descriptive for this cohort.

Do not rename process duration minus hosted time as JVM startup. Attribute time only when an instrumented stage establishes that attribution.

The native capability passes through exact behavior and process evidence. A latency improvement claim also needs a favorable matched result.

A repeatable end-to-end regression blocks candidate replacement until the report explains and resolves it. Inconclusive timings permit no speedup claim.

Do not add a daemon or change host admission to improve the first result. First inspect the remaining measured client work.

### 5.4 Comparison rules

Use independent expected declarations and relations for the real fixture. Use fixed encoded responses for transport and shell policy cases.

For a fixed response, preserve the exact public document and output framing.

Fresh semantic runs can issue different tokens. Before collection, declare the exact fields that represent fresh allocation.

Compare token relationships and result structure after that narrow normalization. Never remove host, workspace, basis, source, coverage, completion, or qualification to obtain equality.

A retained read must preserve its producer's token bytes exactly. A native client must also read a baseline-issued result under the same live authority.

Include comparator controls with a changed target, source range, coverage, host identity, and selected field. Each control must fail equivalence.

A successful resume has different work semantics from READ_RESULT. Compare its existing contract separately without imposing a no-work rule.

### 5.5 Specific blockers

| Condition | Continue independently | Claim that remains blocked |
| --- | --- | --- |
| Native toolchain or target runner unavailable | Pure contracts, installation context, and ownership tests. | Native build and native process acceptance. |
| Missing metadata or resource registration | Diagnose the exact failure and preserve shared JVM coverage. | Native command coverage for the failing path. |
| No disposable compatible IDEA | Native process, local peer, and packaging tests. | Real semantic parity and retained-state integration. |
| Incomplete client execution evidence | Artifact inspection and other behavior tests. | Zero-client-JVM claim. |
| Archive size gate exceeded | Remove duplicate or unnecessary content and measure again. | Product qualification. |
| Reproducible client behavior regression | Fix the responsible owner and rerun its narrow checks. | Native replacement. |

Record the exact unmet criterion and supporting evidence. Do not convert a blocked criterion into a waiver or a weaker claim.

Do not use JVM fallback to pass a native criterion. Keep the existing implementation available for comparison until replacement passes.

## 6. Completion and evidence handoff

### 6.1 Completion

The change is complete when all acceptance criteria pass at their stated scopes.

The public product must select the qualified native client. Correct code or a standalone native binary is insufficient if installation still selects Java.

Preserve current public and private contracts. Remove the obsolete shipped query JVM launcher after native product acceptance.

Keep JVM entries still used by MCP, RPC, and service operations.

A broad module cleanup, one-binary consolidation, MCP startup optimization, and new release platforms remain separate work.

### 6.2 Evidence report

Create a source-bound report beside the existing CLI evidence, using the repository's current documentation conventions.

The report must contain:

- The refreshed baseline, candidate SHA, tree state, and tested executable digests.
- The selected toolchain, platform, installation identity, and host identity.
- Exact commands and necessary fixture configuration.
- One result for each AC01–AC17 criterion.
- Expected versus actual outputs and failure categories.
- Native artifact and full client execution evidence.
- Resource inventory and native registration diagnostics.
- Lifecycle ownership, cancellation, output, and retained-read evidence.
- Raw measurement records, collection decisions, and comparison results.
- Source/product gate results, skips, NOT RUN cases, and unresolved blockers.

A PASS needs executed evidence. Keep inherited evidence clearly labeled.

Native process exit does not establish host settlement. Resource availability does not establish compiler correctness.

Do not claim latency improvement from fewer JVM launches alone. Report the exact removed work even when timings remain inconclusive.

### 6.3 Recovery and release

Keep the existing installation transaction, fences, and recovery owners. Regenerate replacement manifests through the current packaging path.

Use the previous verified product artifact for an explicit rollback. Do not introduce runtime fallback from native queries to Java.

Qualify rollback across the worker ownership change. The examined lifecycle owner admits Java workers. That source fact requires a mixed-version rollback case; it does not establish an existing transaction defect. [LifecycleProcesses.kt][s07]

Start an owned native query and record its PID/start identity. Request rollback through the existing transaction and fences.

The current owner must settle that exact client identity and satisfy the existing transaction's quiescence contract before restoring the previous payload and management owner. Do not delegate a live native worker's retirement to the older Java-only owner.

If quiescence cannot be established, rollback must stop under the existing failure policy. Preserve the transaction's recovery guarantees.

After restoration, verify manifest digests, launcher selection, and ordinary JVM worker admission. Keep client retirement distinct from host settlement as required by AC13.

Release publication remains a separate action. The implementation handoff must include the complete candidate and evidence for review.

## 7. Source map

All repository links point to the examined SHA. External references describe the compilation model and qualification tools.

- [S00 — Examined main revision][s00]
- [S01 — Existing GraalVM management build][s01]
- [S02 — Public query dispatch and child ownership][s02]
- [S03 — Client dependencies and JVM launcher producers][s03]
- [S04 — Installed launcher generation][s04]
- [S05 — Shared direct session composition][s05]
- [S06 — Invocation records and JAR discovery][s06]
- [S07 — Ordinary lifecycle process ownership][s07]
- [S08 — Force reset process scope][s08]
- [S09 — Client infrastructure dependencies][s09]
- [S10 — Public contract admission and resources][s10]
- [S11 — Endpoint response admission][s11]
- [S12 — Hosted compatibility resource consumption][s12]
- [S13 — Processed platform properties][s13]
- [S14 — Existing Unix-socket transport][s14]
- [S15 — Project-owned retained query state][s15]
- [S16 — Product assembly and archive limits][s16]
- [S17 — Inherited public CLI evidence][s17]
- [S18 — Public shell exit policy][s18]
- [S19 — Existing launcher composition test][s19]
- [S20 — Existing blocked-output test][s20]
- [S21 — Public CLI execution and lazy composition][s21]
- [S22 — Repository execution and evidence rules][s22]
- [G01 — GraalVM Native Image model][g01]
- [G02 — GraalVM reachability metadata][g02]

[s00]: https://github.com/amichne/kast/commit/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a
[s01]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/distribution/cli/build.gradle.kts
[s02]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/PublicQueryDispatch.kt
[s03]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/build.gradle.kts
[s04]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/main/kotlin/io/github/amichne/kast/cli/installation/InstallationWorkflow.kt
[s05]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/main/kotlin/io/github/amichne/kast/cli/direct/KastDirectToolSession.kt
[s06]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/main/kotlin/io/github/amichne/kast/cli/rpc/OneShotInvocationRecord.kt
[s07]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/LifecycleProcesses.kt
[s08]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/ForceDaemonRuntime.kt
[s09]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/app-server/build.gradle.kts
[s10]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/app-server/src/main/kotlin/io/github/amichne/kast/appserver/query/PublicToolContract.kt
[s11]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/app-server/src/main/kotlin/io/github/amichne/kast/appserver/ide/ExistingIdeDocuments.kt
[s12]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/app-server/src/main/kotlin/io/github/amichne/kast/appserver/ide/HostedServicesObservation.kt
[s13]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/protocol/contract/build.gradle.kts
[s14]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/app-server/src/main/kotlin/io/github/amichne/kast/appserver/ide/ExistingIdeSocketClient.kt
[s15]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/HostedQueryContinuations.kt
[s16]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/build.gradle.kts#L121-L199
[s17]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/docs/reviews/public-cli-v1-evidence.md
[s18]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/main/kotlin/io/github/amichne/kast/cli/publicshell/PublicShellExit.kt
[s19]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/test/kotlin/io/github/amichne/kast/cli/publicshell/PublicLauncherCompositionTest.kt
[s20]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/test/kotlin/io/github/amichne/kast/cli/publicshell/PublicOutputCancellationTest.kt
[s21]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/cli/src/main/kotlin/io/github/amichne/kast/cli/publicshell/KastPublicCliMain.kt
[s22]: https://github.com/amichne/kast/blob/96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a/AGENTS.md
[g01]: https://www.graalvm.org/jdk25/reference-manual/native-image/
[g02]: https://www.graalvm.org/jdk25/reference-manual/native-image/metadata/

