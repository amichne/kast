"""Exercise issued row cursors, independent evidence cursors, and discover supported resume."""
import json
from acceptance import OUT, FIELDS, command, invoke

def load(name):
    return json.loads((OUT / (name + '.stdout')).read_text())['document']

for route in ['baseline', 'native']:
    full = load(route + '-three-symbols')
    for reader in (['baseline', 'native'] if route == 'baseline' else ['native']):
        previous = load(route + '-issued-' + reader + '-row-page0')
        for index in [1, 2]:
            cursor = previous['next_cursor']
            result, record = invoke(route + '-issued-' + reader + '-row-page' + str(index), reader, command(['result', 'read'], '--ref', full['retention']['reference'], '--cursor', str(cursor), '--evidence-cursor', '0', *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152'))
            assert record['exitCode'] == 0
            previous = result['document']
        evidence = load(route + '-issued-' + reader + '-evidence-page0')
        invoke(route + '-issued-' + reader + '-evidence-page1', reader, command(['result', 'read'], '--ref', evidence['retention']['reference'], '--cursor', str(evidence['row_window']['end']), '--evidence-cursor', str(evidence['evidence_window']['end']), *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152', '--verbose'))
    args = command(['query'], *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152', '--retain')
    for item in full['items']:
        args += ['--ref', item['ref']]
    invoke(route + '-resume-producer', route, args)
