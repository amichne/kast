package io.github.amichne.kast.cli.rpc

import io.github.amichne.kast.appserver.BrokerOperationalLimits
import io.github.amichne.kast.appserver.ide.CanonicalRootDiscovery
import io.github.amichne.kast.appserver.query.AdmittedPublicTool
import io.github.amichne.kast.appserver.query.PublicToolContract
import io.github.amichne.kast.appserver.query.PublicToolInputFailure
import io.github.amichne.kast.cli.CliExit
import io.github.amichne.kast.cli.MAXIMUM_PROTOCOL_TEXT_LENGTH
import io.github.amichne.kast.cli.direct.DirectCatalogArguments
import io.github.amichne.kast.cli.direct.DirectToolStage
import io.github.amichne.kast.cli.direct.InstalledToolAdmission
import io.github.amichne.kast.cli.direct.KastDirectToolSession
import io.github.amichne.kast.cli.direct.observeDirectToolStage
import io.github.amichne.kast.cli.direct.selectDirectCatalog
import io.github.amichne.kast.cli.mcp.McpChangePhase
import io.github.amichne.kast.cli.mcp.McpStructuredResults
import io.github.amichne.kast.kernel.Refinement
import io.github.amichne.kast.protocol.registry.OperationExecutionBudget
import io.github.amichne.kast.protocol.registry.PUBLIC_TOOL_CONTRACT_VERSION
import io.github.amichne.kast.protocol.registry.PublicToolIdentity
import java.nio.charset.CharacterCodingException
import java.nio.file.Path
import kotlinx.serialization.Required
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/** Harness-neutral one-shot calls and bounded invocation-scoped query sessions. */
object KastToolRpcMain {
    @JvmStatic
    fun main(args: Array<String>) =
        observeDirectToolStage(DirectToolStage.MAIN) {
            when (val selection = selectDirectCatalog(args.toList())) {
                is Refinement.Rejected -> printReply(ToolRpcReply.Rejected(ToolRpcFailure.INVALID_COMMAND))
                is Refinement.Refined -> {
                    val selected = selection.value
                    if (selected.command == listOf("plan-query")) {
                        val bytes = System.`in`.readNBytes(MAXIMUM_PROTOCOL_TEXT_LENGTH + 1)
                        println(toolRpcJson.encodeToString<QueryCostPlanReply>(planToolQuery(bytes, selected.catalog)))
                        System.out.flush()
                    } else runInstalled(selected)
                }
            }
        }

    private fun runInstalled(selected: DirectCatalogArguments) {
        val command = selected.command
        val directory = Path.of("").toAbsolutePath()
        val home = Path.of(System.getProperty("user.home"))
        val session =
            observeDirectToolStage(DirectToolStage.SESSION_COMPOSITION) {
                KastDirectToolSession.installed(directory, home, System.getenv(), selected.catalog)
            }
        val bridge =
            observeDirectToolStage(DirectToolStage.BRIDGE_COMPOSITION) {
                session?.let(::KastToolRpcBridge)
            }
        if (command == listOf("query-session")) {
            runQuerySession(session, bridge)
            return
        }
        val response =
            when {
                session == null || bridge == null -> ToolRpcReply.Rejected(ToolRpcFailure.CATALOG_UNAVAILABLE)
                command == listOf("catalog") -> bridge.catalog()
                command.size == 2 && command[0] == "call" -> {
                    val bytes = System.`in`.readNBytes(MAXIMUM_PROTOCOL_TEXT_LENGTH + 1)
                    if (bytes.size > MAXIMUM_PROTOCOL_TEXT_LENGTH)
                        ToolRpcReply.Rejected(ToolRpcFailure.REQUEST_TOO_LARGE)
                    else if (session.admission() != InstalledToolAdmission.AVAILABLE)
                        ToolRpcReply.Rejected(ToolRpcFailure.INSTALLATION_STOPPED)
                    else invokeObserved(session, bridge, command[1], bytes)
                }
                else -> ToolRpcReply.Rejected(ToolRpcFailure.INVALID_COMMAND)
            }
        printReply(response)
    }

    private fun runQuerySession(session: KastDirectToolSession?, bridge: KastToolRpcBridge?) {
        when {
            session == null || bridge == null -> printReply(ToolRpcReply.Rejected(ToolRpcFailure.CATALOG_UNAVAILABLE))
            session.admission() != InstalledToolAdmission.AVAILABLE ->
                printReply(ToolRpcReply.Rejected(ToolRpcFailure.INSTALLATION_STOPPED))
            else ->
                session.beginInvocation(InvocationRecordKind.RPC)?.use {
                    KastToolRpcQuerySession(session.queryCatalog, bridge::callAdmitted).run(System.`in`, ::printReply)
                } ?: printReply(ToolRpcReply.Rejected(ToolRpcFailure.OBSERVATION_UNAVAILABLE))
        }
    }

    private fun printReply(response: ToolRpcReply) {
        val document =
            observeDirectToolStage(DirectToolStage.OUTPUT_SERIALIZATION) {
                toolRpcJson.encodeToString<ToolRpcReply>(response)
            }
        println(document)
        System.out.flush()
    }

    private fun invokeObserved(
        session: KastDirectToolSession,
        bridge: KastToolRpcBridge,
        name: String,
        bytes: ByteArray,
    ): ToolRpcReply =
        when (val input = decodeToolRpcInput(bytes)) {
            is Refinement.Refined ->
                session.beginInvocation(InvocationRecordKind.RPC)?.use { bridge.call(name, input.value) }
                    ?: ToolRpcReply.Rejected(ToolRpcFailure.OBSERVATION_UNAVAILABLE)
            is Refinement.Rejected -> ToolRpcReply.Rejected(input.failure)
        }
}

internal class KastToolRpcBridge(private val session: KastDirectToolSession) {
    private val tools by lazy {
        session.catalog.map { tool ->
            ToolRpcTool(
                tool.name,
                tool.description,
                if (tool.readOnly) ToolRpcToolEffect.READ else ToolRpcToolEffect.WRITE,
                tool.inputSchema,
            )
        }
    }

    fun catalog(): ToolRpcReply = ToolRpcReply.Catalog(ToolRpcCatalog(tools.sortedBy(ToolRpcTool::name)))

    fun call(name: String, input: String): ToolRpcReply {
        if (session.admission() != InstalledToolAdmission.AVAILABLE)
            return ToolRpcReply.Rejected(ToolRpcFailure.INSTALLATION_STOPPED)
        if (!session.supports(name)) return ToolRpcReply.Rejected(ToolRpcFailure.UNKNOWN_TOOL)
        val arguments =
            try {
                toolRpcJson.decodeFromString<JsonObject>(input)
            } catch (_: SerializationException) {
                return ToolRpcReply.Rejected(ToolRpcFailure.INVALID_ARGUMENTS)
            }
        val identity = PublicToolIdentity.entries.singleOrNull { it.toolName == name }
        val admitted =
            if (identity == null) null
            else
                when (
                    val admission =
                        observeDirectToolStage(DirectToolStage.REQUEST_ADMISSION) {
                            PublicToolContract.admit(identity, arguments, session.queryCatalog)
                        }
                ) {
                    is Refinement.Refined -> admission.value
                    is Refinement.Rejected -> return ToolRpcReply.Rejected.publicInput(admission.failure)
                }
        return invoke(name) {
            if (admitted == null) session.invoke(name, arguments) else session.invokeAdmitted(admitted)
        }
    }

    fun callAdmitted(request: AdmittedPublicTool): ToolRpcReply {
        if (session.admission() != InstalledToolAdmission.AVAILABLE)
            return ToolRpcReply.Rejected(ToolRpcFailure.INSTALLATION_STOPPED)
        if (request.catalog != session.queryCatalog)
            return ToolRpcReply.Rejected.publicInput(PublicToolInputFailure.SchemaMismatch)
        if (!session.supports(request.identity.toolName)) return ToolRpcReply.Rejected(ToolRpcFailure.UNKNOWN_TOOL)
        return invoke(request.identity.toolName) { session.invokeAdmitted(request) }
    }

    private fun invoke(name: String, execute: () -> CliExit): ToolRpcReply {
        val root =
            observeDirectToolStage(DirectToolStage.WORKSPACE_DISCOVERY) { session.root() }
                as? CanonicalRootDiscovery.Discovered ?: return ToolRpcReply.Rejected(ToolRpcFailure.OUT_OF_SCOPE)
        // A rejected eager preparation does not erase the precise failure from the operation demand.
        observeDirectToolStage(DirectToolStage.PREPARATION_START) { session.start(root.root) }
        val exit =
            try {
                observeDirectToolStage(DirectToolStage.INVOCATION) {
                    execute()
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: RuntimeException) {
                return ToolRpcReply.Rejected(ToolRpcFailure.INVOCATION_FAILED)
            }
        return observeDirectToolStage(DirectToolStage.RESULT_PROJECTION) { presentToolRpcExit(name, exit) }
    }
}

internal fun presentToolRpcExit(name: String, exit: CliExit): ToolRpcReply {
    val document =
        try {
            toolRpcJson.parseToJsonElement(exit.document.value) as? JsonObject
                ?: return ToolRpcReply.Rejected(ToolRpcFailure.INVALID_RESULT)
        } catch (_: SerializationException) {
            return ToolRpcReply.Rejected(ToolRpcFailure.INVALID_RESULT)
        }
    val admitted =
        when (exit) {
            // Legacy CLI boundary documents have their own closed serializers, outside semantic schemas.
            is CliExit.BoundaryRejected,
            is CliExit.PublicInputRejected -> true
            is CliExit.Complete,
            is CliExit.Qualified,
            is CliExit.OperationRejected ->
                McpStructuredResults.validatesSemantic(name, document) &&
                    McpStructuredResults.matchesExit(exit, document)
            is CliExit.Delegated -> false
        }
    if (!admitted) return ToolRpcReply.Rejected(ToolRpcFailure.INVALID_RESULT)
    return when (exit) {
        is CliExit.Complete -> ToolRpcReply.Complete(document)
        is CliExit.Qualified -> ToolRpcReply.Qualified(document)
        is CliExit.OperationRejected,
        is CliExit.BoundaryRejected -> ToolRpcReply.RejectedDocument(document)
        is CliExit.PublicInputRejected -> ToolRpcReply.Rejected.publicInput(exit.failure)
        is CliExit.Delegated -> ToolRpcReply.Rejected(ToolRpcFailure.INVALID_RESULT)
    }
}

internal fun decodeToolRpcInput(bytes: ByteArray): Refinement<String, ToolRpcFailure> =
    try {
        Refinement.Refined(bytes.decodeToString(throwOnInvalidSequence = true))
    } catch (_: CharacterCodingException) {
        Refinement.Rejected(ToolRpcFailure.INVALID_ARGUMENTS)
    }

@Serializable
internal sealed interface ToolRpcReply {
    @Serializable @SerialName("catalog") data class Catalog(val catalog: ToolRpcCatalog) : ToolRpcReply

    @Serializable @SerialName("complete") data class Complete(val document: JsonObject) : ToolRpcReply

    @Serializable @SerialName("qualified") data class Qualified(val document: JsonObject) : ToolRpcReply

    @Serializable @SerialName("rejected_document") data class RejectedDocument(val document: JsonObject) : ToolRpcReply

    @Serializable
    @SerialName("rejected")
    data class Rejected
    private constructor(
        val failure: ToolRpcFailure,
        @kotlinx.serialization.EncodeDefault(kotlinx.serialization.EncodeDefault.Mode.NEVER)
        val detail: QuerySessionRejectionDetail? = null,
    ) : ToolRpcReply {
        constructor(failure: ToolRpcFailure) : this(failure, null)

        companion object {
            fun publicInput(failure: PublicToolInputFailure): Rejected =
                Rejected(ToolRpcFailure.INVALID_ARGUMENTS, publicToolInputRejectionDetail(failure))

            fun querySession(detail: QuerySessionRejectionDetail): Rejected =
                Rejected(
                    when (detail) {
                        is QuerySessionRejectionDetail.RequestConstraint,
                        is QuerySessionRejectionDetail.OutputAllowance,
                        is QuerySessionRejectionDetail.DetailSelector,
                        is QuerySessionRejectionDetail.SourceAnchor -> ToolRpcFailure.INVALID_ARGUMENTS
                        is QuerySessionRejectionDetail.NewRun,
                        is QuerySessionRejectionDetail.SourceRead,
                        is QuerySessionRejectionDetail.ResultNotIssued,
                        is QuerySessionRejectionDetail.ContinuationNotIssued ->
                            ToolRpcFailure.QUERY_SESSION_TRANSITION_REJECTED
                    },
                    detail,
                )
        }
    }
}

@Serializable
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
internal data class ToolRpcCatalog(
    val tools: List<ToolRpcTool>,
    @Required val schemaVersion: Int = PUBLIC_TOOL_CONTRACT_VERSION,
    @Required
    val callTimeoutMillis: Long =
        OperationExecutionBudget.WORKSPACE_READINESS.value +
            McpChangePhase.entries.size * OperationExecutionBudget.SEMANTIC_READ.operation.value,
    @Required val maxResponseBytes: Int = BrokerOperationalLimits.maximumToolRpcResponseBytes,
    /** Optional transport capability; absence in an older catalog selects one-shot calls. */
    @kotlinx.serialization.EncodeDefault(kotlinx.serialization.EncodeDefault.Mode.ALWAYS)
    val querySession: Boolean = true,
)

@Serializable
internal data class ToolRpcTool(
    val name: String,
    val description: String,
    val effect: ToolRpcToolEffect,
    /** Generated canonical request schema, retained unchanged until the ToolRpc projection. */
    val inputSchema: JsonObject,
)

@Serializable
internal enum class ToolRpcToolEffect {
    READ,
    WRITE,
}

@Serializable
internal enum class ToolRpcFailure {
    INSTALLATION_STOPPED,
    OBSERVATION_UNAVAILABLE,
    CATALOG_UNAVAILABLE,
    INVALID_COMMAND,
    REQUEST_TOO_LARGE,
    UNKNOWN_TOOL,
    INVALID_ARGUMENTS,
    OUT_OF_SCOPE,
    INVOCATION_FAILED,
    INVALID_RESULT,
    QUERY_SESSION_TRANSITION_REJECTED,
}

private val toolRpcJson = Json { encodeDefaults = true }
