#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Final installed acceptance. Explicit ready-host authorization is mandatory."""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE.parent / "measurements"))
c = importlib.import_module("collector")

FINAL = HERE.parent / "final-artifact.json"
PAYLOAD_SHA = "7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0"
UNISSUED_CONTROL = "query-output:v1:00000000-0000-0000-0000-000000000099"


def preflight(config: Any) -> None:
    c.require(config["status"] == "READY_MAIN_AUTHORIZED", "main ready identity not supplied")
    c.preflight(config, artifacts=False)
    final = c.load(FINAL)
    c.require(final["members"]["bin/kast-query"] == PAYLOAD_SHA, "final payload receipt changed")
    for path, expected in config["identities"].items():
        c.require(c.digest(Path(path)) == expected, f"changed identity: {path}")
    for route in c.ROUTES:
        selected = config["routes"][route]
        for key in ("command", "payload", "manifest"):
            c.require(selected[key] in config["identities"], f"pin {route} {key}")
        c.require(
            selected["command"] == str(Path(selected["environment"]["HOME"]) / ".local/bin/kast"),
            "installed public route",
        )
    c.require(
        c.digest(Path(config["routes"]["native"]["payload"])) == PAYLOAD_SHA,
        "not the final native payload",
    )
    for key in ("readyHostReceipt", "qualificationReceipt"):
        c.require(config[key] in config["identities"], f"pin {key}")
    for path in (config["mcpPython"], str(HERE / "mcp_check.py"), str(HERE / "mcp_check.py.lock")):
        c.require(path in config["identities"], "pin MCP runtime/script/lock: " + path)
    java = Path(config["controlJava"])
    c.require(
        java.is_absolute() and str(java) in config["identities"], "pin exact copied IDEA JBR java"
    )
    c.require(
        not (
            {"JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "JAVA_OPTS", "KAST_OPTS"}
            & set(config["routes"]["native"]["environment"])
        ),
        "native environment has Java options",
    )


def command(config: Any, words: list[str], *args: str) -> list[str]:
    return [*words, "--catalog", "complete", "--workspace", config["live"]["root"], *args]


def host_identity(record: Any, config: Any, *, timeout: bool = False) -> None:
    observations = record["receipts"]
    reads = observations["semantic_read"]
    c.require(len(reads) == 1, "one semantic read receipt")
    read = reads[0]
    c.require(read["pid"] == config["endpointExpected"]["hostPid"], "exact host PID")
    expected = (
        {"type": "unbound"}
        if timeout
        else {"type": "bound", "host": config["live"]["host"], "epoch": config["live"]["epoch"]}
    )
    c.require(read["correlation"] == expected, "receipt host/basis")
    links = [link for link in observations["transport_read"] if link["readId"] == read["readId"]]
    c.require(len(links) == 1, "connection/read join")
    events = [
        event
        for event in observations["transport"]
        if event["connectionId"] == links[0]["connectionId"]
    ]
    c.require(
        any(event["stage"] == "EXECUTION" and event["outcome"] == "COMPLETED" for event in events),
        "joined execution completion",
    )


def unissued_resume_oracle(result: Any, observed: Any) -> None:
    """Negative authority control only; no successful token issuance is claimed."""
    c.require(
        result == c.load(c.PRIOR / "resume-unissued-native.stdout"),
        "exact unissued-token rejection document",
    )
    reads = observed["semantic_read"]
    c.require(len(reads) == 1, "unissued resume has one read receipt")
    read = reads[0]
    c.require(
        read["outcome"] == {"type": "evaluated", "outcome": "REJECTED"},
        "unissued resume rejected outcome",
    )
    calls = read["nativeCalls"]
    c.require(
        any(call["call"] == "K2_ANALYSIS" for call in calls),
        "unissued resume K2 observation present",
    )
    c.require(
        all(call["entered"] == 0 and call["qualification"] == "EXACT" for call in calls),
        "unissued resume must not enter producers",
    )
    searches = read["nativeSearches"]
    c.require(
        bool(searches)
        and all(
            search["entered"] == 0 and search["qualification"] == "EXACT" for search in searches
        ),
        "unissued resume must not enter searches",
    )
    counters = {counter["counter"]: counter["count"] for counter in read["counters"]}
    for counter in (
        "DECLARATION_PSI_NODES_VISITED",
        "NATIVE_DISCOVERY_PAGES",
        "NATIVE_RELATION_PAGES",
    ):
        c.require(counters[counter] == 0, "unissued resume " + counter)
    c.require(
        read["discoveryPages"]["qualification"] == "EXACT"
        and read["discoveryPages"]["published"] == 0,
        "unissued resume published no discovery",
    )


def source_oracle(result: Any, config: Any) -> None:
    c.require(result["type"] == "complete", "source complete")
    d = result["document"]
    text = Path(config["source"]).read_text()
    c.require(d["operation"] == "source.read", "source operation")
    c.require(d["live"] == d["snapshot"]["live"] == config["live"], "source live basis")
    c.require(d["snapshot"]["file"] == config["source"], "source exact file")
    c.require(d["snapshot"]["canonicalRoot"] == config["live"]["root"], "source root")
    c.require(
        d["snapshot"]["length"] == 175 and d["snapshot"]["coordinateUnit"] == "utf16-code-unit",
        "source length/units",
    )
    c.require(
        d["snapshot"]["textIdentity"]
        == "intellij-document-utf16be-sha256-v1|"
        + hashlib.sha256(text.encode("utf-16-be")).hexdigest(),
        "source UTF16 digest",
    )
    c.require(
        d["region"]["selection"]["range"] == {"startInclusive": 17, "endExclusive": 94},
        "source range",
    )
    c.require(d["text"]["selection"] == d["region"]["selection"], "source selection linkage")
    c.require(d["text"]["text"] == text[17:94], "source exact text")
    c.require(d["text"]["lines"] == {"startInclusive": 3, "endInclusive": 5}, "source line range")


def three_symbols(result: Any, config: Any) -> None:
    c.require(result["type"] == "complete", "three-symbol result complete")
    d = result["document"]
    c.require(
        d["coverage"] == {"exhaustive": True} and d["live"] == config["live"],
        "three-symbol basis/coverage",
    )
    expected = {
        "OrderService": ("example.OrderService", 17, 94),
        "submitOrder": ("example.OrderService.submitOrder", 42, 92),
        "placeOrder": ("example.placeOrder", 96, 174),
    }
    c.require(
        len(d["items"]) == 3 and {row["name"] for row in d["items"]} == set(expected),
        "three distinct known declarations",
    )
    for row in d["items"]:
        name, start, end = expected[row["name"]]
        c.require(row["signature"]["qualifiedIdentity"] == name, "known qualified declaration")
        c.require(
            row["location"]
            == {"file": config["source"], "range": {"startInclusive": start, "endExclusive": end}},
            "known declaration range",
        )


def evidence_oracle(first: Any, last: Any, original: Any) -> None:
    c.require(len(first["items"]) == 1 and last["items"] == [], "evidence-only successor")
    row, compact = first["items"][0], original["items"][0]
    for field in ("row_id", "name", "kind", "signature", "location"):
        c.require(row[field] == compact[field], f"evidence row {field}")
    nodes = {node["id"]: node["symbol"] for node in original["relation_graph"]["nodes"]}
    c.require(row["ref"] == nodes[compact["node"]]["selector"], "verbose row selector")
    c.require(len(row["connections"]) == 1, "one verbose caller connection")
    edge = row["connections"][0]
    witness = original["relation_graph"]["connection_witnesses"][0]
    c.require(
        edge["source"]["selector"] == nodes[witness["source"]]["selector"], "verbose source linkage"
    )
    c.require(
        edge["target"]["selector"] == nodes[witness["target"]]["selector"], "verbose target linkage"
    )
    c.require(
        edge["source"]["qualifiedIdentity"] == "example.placeOrder"
        and edge["target"]["qualifiedIdentity"] == "example.OrderService.submitOrder",
        "verbose known edge",
    )
    c.require(edge["occurrence"] == witness["occurrence"], "verbose exact occurrence")
    c.require(
        edge["meaning"] == "callers"
        and edge["coverage"] == "exact-compiler-confirmed"
        and edge["provenance"] == "k2-authored-source",
        "verbose evidence qualification",
    )
    c.require(
        first["evidence_window"] == {"type": "MORE", "start": 0, "end": 1, "total": 2},
        "evidence first cursor",
    )
    c.require(
        last["evidence_window"] == {"type": "FINAL", "start": 1, "end": 2, "total": 2},
        "evidence final cursor",
    )
    c.require(
        last["row_window"] == {"type": "FINAL", "start": 1, "end": 1, "total": 1},
        "evidence-only row cursor",
    )
    c.require(
        first["page_progress"]["relation_evidence"] == 0
        and last["page_progress"]["relation_evidence"] == 1,
        "independent evidence progress",
    )
    c.require(
        first["relation_observations"] == []
        and last["relation_observations"] == original["relation_observations"],
        "relation observations preserved",
    )
    c.require(
        len(first["discovery_observations"]) == 1 and last["discovery_observations"] == [],
        "discovery evidence pages",
    )
    c.require(
        first["discovery_observations"][0]["universe"]
        == original["discovery_observations"][0]["universe"],
        "discovery scope preserved",
    )
    c.require(
        first["discovery_observations"][0]["progress"] == {"kind": "exhausted"},
        "discovery completion",
    )
    for page in (first, last):
        c.require(
            page["retention"] == original["retention"]
            and page["original_evidence_summary"] == original["original_evidence_summary"],
            "original retained evidence",
        )


def profile(config: Any, output: Path, *, allow_java: bool = False) -> Path:
    selected = config["routes"]["native"]
    paths = [
        selected["command"],
        str(Path(selected["payload"]).parent / "kast-query-complete"),
        selected["payload"],
        "/bin/sh",
        "/bin/bash",
        "/usr/bin/dirname",
    ]
    if allow_java:
        paths.append(config["controlJava"])
    path = output / ("java-positive.sb" if allow_java else "native-exec.sb")
    path.write_text(
        "(version 1)\n(allow default)\n(deny process-exec)\n(allow process-exec\n"
        + "\n".join("  (literal " + json.dumps(value) + ")" for value in paths)
        + ")\n"
    )
    return path


def run(config: Any, output: Path) -> int:
    preflight(config)
    c.require(
        output.is_relative_to(HERE) and not output.exists(),
        "new semantic output directory required",
    )
    output.mkdir()
    c.save(output / "config.json", config)
    strict = profile(config, output)
    positive = profile(config, output, allow_java=True)
    summary: dict[str, Any] = {
        "state": "INCOMPLETE",
        "host": config["endpointExpected"],
        "live": config["live"],
        "nativePayloadSha256": PAYLOAD_SHA,
        "successfulIssuedResume": "NOT RUN: no supported public producer established",
        "latency": "NOT A COHORT",
        "executionMechanism": "enforced allowlist, not execution-event counting",
    }
    outputs: dict[str, Any] = {}
    records: dict[str, Any] = {}
    completed_assertions: list[str] = []

    def invoke(
        name: str,
        route: str,
        args: list[str],
        request: bytes = b"",
        *,
        policy: bool = False,
        expected_exit: int = 0,
        retained: bool = False,
        timeout: bool = False,
    ) -> Any:
        c.preflight(config, artifacts=False)
        selected = config["routes"][route]
        argv = [selected["command"], *args]
        if policy:
            argv = ["/usr/bin/sandbox-exec", "-f", str(strict), *argv]
        directory = output / name
        record = c.capture(
            directory,
            argv,
            selected["environment"],
            config["live"]["root"],
            request,
            Path(config["hostLog"]),
            config["watchdogSeconds"],
            {"name": name, "route": route, "notLatencySample": True, "policy": policy},
        )
        records[name] = record
        c.require(
            record["state"] == "RECORDED"
            and record["outputEof"]
            and not record.get("interruption"),
            "normal complete capture",
        )
        c.require(
            record["exitCode"] == expected_exit,
            f"{name}: expected exit {expected_exit}, got {record['exitCode']}",
        )
        raw = (directory / "stdout").read_bytes()
        c.require(raw.endswith(b"\n") and raw.count(b"\n") == 1, "exact JSON framing")
        result = c.load(directory / "stdout")
        outputs[name] = result
        host_identity(record, config, timeout=timeout)
        if retained:
            c.check_receipts(record["receipts"], config, "retained")
        completed_assertions.append(
            name
            + ": exit/framing/host/connection-read-join"
            + ("/no-producer-replay" if retained else "")
        )
        return result

    def followups(
        prefix: str, route: str, declared: Any, related: Any, full: Any, *, policy: bool
    ) -> None:
        d, graph, three = (value["document"] for value in (declared, related, full))
        read = invoke(
            prefix + "-read",
            route,
            command(
                config,
                ["result", "read"],
                "--ref",
                d["retention"]["reference"],
                *c.FIELDS,
                *c.GRANTS,
            ),
            policy=policy,
            retained=True,
        )
        c.declaration(read, config)
        for key in (
            "items",
            "retention",
            "live",
            "coverage",
            "question",
            "original_evidence_summary",
        ):
            c.require(read["document"][key] == d[key], f"exact issued retained {key}")
        source = invoke(
            prefix + "-source",
            route,
            command(config, ["source", "read"], "--ref", d["items"][0]["ref"]),
            policy=policy,
        )
        source_oracle(source, config)
        selector = source["document"]["region"]["selection"]["selector"]
        selected = invoke(
            prefix + "-source-selector",
            route,
            command(config, ["source", "read"], "--ref", selector),
            policy=policy,
        )
        source_oracle(selected, config)
        c.require(selected == source, "exact issued source selector document")
        pages: list[Any] = []
        cursor = 0
        for index in range(3):
            page = invoke(
                prefix + f"-row-page{index}",
                route,
                command(
                    config,
                    ["result", "read"],
                    "--ref",
                    three["retention"]["reference"],
                    "--cursor",
                    str(cursor),
                    "--evidence-cursor",
                    "0",
                    *c.FIELDS,
                    "--max-results",
                    "1",
                    "--max-returned-bytes",
                    "49152",
                ),
                policy=policy,
                retained=True,
            )["document"]
            c.require(
                page["retention"] == three["retention"] and page["live"] == config["live"],
                "row token/basis unchanged",
            )
            c.require(
                page["coverage"] == {"exhaustive": True} and page["question"] == three["question"],
                "row completion question/coverage",
            )
            c.require(
                page["row_window"]
                == {
                    "type": "MORE" if index < 2 else "FINAL",
                    "start": index,
                    "end": index + 1,
                    "total": 3,
                },
                "row cursor window",
            )
            c.require(
                page["evidence_window"] == {"type": "FINAL", "start": 0, "end": 0, "total": 0},
                "row evidence cursor",
            )
            c.require(
                page["page_progress"]["rows"] == 1
                and page.get("next_cursor") == (index + 1 if index < 2 else None),
                "row progress",
            )
            pages.extend(page["items"])
            if index < 2:
                cursor = page["next_cursor"]
        c.require(pages == three["items"], "all exact rows once across exited processes")
        first = invoke(
            prefix + "-evidence-page0",
            route,
            command(
                config,
                ["result", "read"],
                "--ref",
                graph["retention"]["reference"],
                *c.FIELDS,
                "--max-results",
                "1",
                "--max-returned-bytes",
                "49152",
                "--verbose",
            ),
            policy=policy,
            retained=True,
        )["document"]
        last = invoke(
            prefix + "-evidence-page1",
            route,
            command(
                config,
                ["result", "read"],
                "--ref",
                first["retention"]["reference"],
                "--cursor",
                str(first["row_window"]["end"]),
                "--evidence-cursor",
                str(first["evidence_window"]["end"]),
                *c.FIELDS,
                "--max-results",
                "1",
                "--max-returned-bytes",
                "49152",
                "--verbose",
            ),
            policy=policy,
            retained=True,
        )["document"]
        evidence_oracle(first, last, graph)
        completed_assertions.append(
            prefix + ": exact retained source, selector, row and independent evidence pagination"
        )

    try:
        # Same executable and descendant shape, differing only by java's exact allowlist entry.
        java = config["controlJava"]
        environment = {
            "HOME": config["routes"]["native"]["environment"]["HOME"],
            "PATH": "/usr/bin:/bin",
            "JAVA_HOME": str(Path(java).parents[1]),
        }
        for shape in ("direct", "descendant"):
            child = (
                [java, "-Duser.home=" + environment["HOME"], "-version"]
                if shape == "direct"
                else [
                    "/bin/sh",
                    "-c",
                    '"$JAVA_HOME/bin/java" -Duser.home="$HOME" -version; code=$?; exit "$code"',
                ]
            )
            for allowed, policy_path in ((True, positive), (False, strict)):
                name = "jvm-control-" + shape + ("-allowed" if allowed else "-denied")
                record = c.capture(
                    output / name,
                    ["/usr/bin/sandbox-exec", "-f", str(policy_path), *child],
                    environment,
                    config["live"]["root"],
                    b"",
                    Path(config["hostLog"]),
                    config["watchdogSeconds"],
                    {"name": name, "notLatencySample": True},
                )
                records[name] = record
                c.require(
                    record["state"] == "RECORDED"
                    and record["outputEof"]
                    and not record.get("interruption"),
                    "JVM control capture",
                )
                stderr = (output / name / "stderr").read_bytes()
                c.require(
                    (record["exitCode"] == 0 and b"version" in stderr)
                    if allowed
                    else (record["exitCode"] != 0 and b"Operation not permitted" in stderr),
                    f"JVM control {name}",
                )
                c.require(
                    not record["receipts"]["semantic_read"], "JVM control must not run semantics"
                )
        summary["positiveJvmControls"] = "PASS: direct and shell-descendant allowed/denied"

        for prefix, route, enforced in (
            ("baseline", "baseline", False),
            ("native", "native", False),
            ("policy", "native", True),
        ):
            request = (c.REPO / "docs/reviews/public-cli-v1/query.json").read_bytes()
            declared = invoke(
                prefix + "-declaration",
                route,
                command(config, ["query"], "--request", "-"),
                request,
                policy=enforced,
            )
            c.declaration(declared, config)
            c.check_receipts(records[prefix + "-declaration"]["receipts"], config, "discovery")
            related = invoke(
                prefix + "-callers",
                route,
                command(
                    config,
                    ["query"],
                    "--name",
                    "submitOrder",
                    "--relation",
                    "callers",
                    *c.FIELDS,
                    *c.GRANTS,
                    "--retain",
                ),
                policy=enforced,
            )
            c.caller(related, config)
            refs = [
                declared["document"]["items"][0]["ref"],
                *[
                    node["symbol"]["selector"]
                    for node in related["document"]["relation_graph"]["nodes"]
                ],
            ]
            args = command(config, ["query"], *c.FIELDS, *c.GRANTS, "--retain")
            for ref in refs:
                args += ["--ref", ref]
            full = invoke(prefix + "-three-symbols", route, args, policy=enforced)
            three_symbols(full, config)
            for name, relation in (
                ("NoSuchNativeAcceptanceDeclaration", False),
                ("placeOrder", True),
            ):
                args = command(config, ["query"], "--name", name, *c.FIELDS, *c.GRANTS, "--retain")
                if relation:
                    args += ["--relation", "callers"]
                suffix = "wrong-target" if relation else "absent-name"
                empty = invoke(prefix + "-" + suffix, route, args, policy=enforced)
                c.require(
                    c.common(empty, config, name, relation)["items"] == [],
                    "independent empty control",
                )
            followups(prefix + "-issued-" + prefix, route, declared, related, full, policy=enforced)
            if prefix != "baseline":
                followups(
                    "baseline-issued-" + prefix,
                    route,
                    outputs["baseline-declaration"],
                    outputs["baseline-callers"],
                    outputs["baseline-three-symbols"],
                    policy=enforced,
                )
            if prefix != "baseline":
                for case in (
                    "declaration",
                    "callers",
                    "three-symbols",
                    "absent-name",
                    "wrong-target",
                ):
                    c.require(
                        c.normalized(outputs[prefix + "-" + case])
                        == c.normalized(outputs["baseline-" + case]),
                        f"full fresh document parity: {prefix}/{case}",
                    )
                    completed_assertions.append(
                        prefix + "/" + case + ": full fresh document parity"
                    )
                for suffix in (
                    "read",
                    "source",
                    "source-selector",
                    "row-page0",
                    "row-page1",
                    "row-page2",
                    "evidence-page0",
                    "evidence-page1",
                ):
                    c.require(
                        outputs["baseline-issued-" + prefix + "-" + suffix]
                        == outputs["baseline-issued-baseline-" + suffix],
                        "full exact baseline-issued cross-client document",
                    )
                    completed_assertions.append(
                        "baseline-issued-" + prefix + "/" + suffix + ": full exact document parity"
                    )

        for route in c.ROUTES:
            name = "invalid-unissued-resume-" + route
            result = invoke(
                name,
                route,
                command(config, ["result", "resume"], "--continuation", UNISSUED_CONTROL),
                policy=route == "native",
                expected_exit=10,
            )
            unissued_resume_oracle(result, records[name]["receipts"])
            completed_assertions.append(
                name + ": known unissued token rejected with exit10 and no observed producer replay"
            )
        c.require(
            outputs["invalid-unissued-resume-baseline"]
            == outputs["invalid-unissued-resume-native"],
            "identical unissued RESUME document/exit10",
        )
        summary["unissuedResumeNegativeControl"] = (
            "PASS: both exit10, identical document, no observed producer replay; not successful issuance"
        )

        for route in c.ROUTES:
            args = command(
                config,
                ["query"],
                "--name",
                "OrderService",
                *c.FIELDS,
                *c.GRANTS,
                "--max-elapsed-ms",
                "1",
                "--retain",
            )
            timeout_result = invoke(
                "explicit-1ms-" + route,
                route,
                args,
                policy=route == "native",
                expected_exit=124 if route == "native" else 6,
                timeout=True,
            )
            c.require(
                timeout_result == c.load(c.PRIOR / "resume-elapsed-native.stdout"),
                "exact independent pre-admission timeout document",
            )
        c.require(
            outputs["explicit-1ms-baseline"] == outputs["explicit-1ms-native"],
            "identical document despite corrected candidate exit",
        )
        summary["explicit1ms"] = "PASS: candidate124 baseline6 identical document"
        preflight(config)
        # The packaged RPC child intentionally uses the JVM. This is not a query
        # process-count claim, execution-policy case, or latency sample.
        mcp_output = HERE / "mcp" / output.name
        c.require(not mcp_output.exists(), "new MCP evidence directory required")
        mcp_record = c.capture(
            output / "mcp-session",
            [
                config["mcpPython"],
                str(HERE / "mcp_check.py"),
                "--run",
                str(output / "config.json"),
                "--authorize-ready-host",
                "--output",
                str(mcp_output),
            ],
            config["routes"]["native"]["environment"],
            config["live"]["root"],
            b"",
            Path(config["hostLog"]),
            max(180, config["watchdogSeconds"]),
            {"name": "mcp-session", "notLatencySample": True, "outsideZeroQueryJvmClaim": True},
        )
        records["mcp-session"] = mcp_record
        c.require(
            mcp_record["state"] == "RECORDED"
            and mcp_record["outputEof"]
            and not mcp_record.get("interruption")
            and mcp_record["exitCode"] == 0,
            "packaged MCP/RPC session capture",
        )
        mcp_summary = c.load(mcp_output / "summary.json")
        c.require(
            mcp_summary["state"] == "PASS" and mcp_summary["sessionClosed"],
            "MCP session assertions/closure",
        )
        summary["packagedMcpRpc"] = {
            "state": "PASS",
            "evidence": str(mcp_output),
            "outsideZeroQueryJvmClaim": True,
        }
        completed_assertions.append(
            "MCP: final installed task service/RPC, independent declaration oracle, exact host/basis join"
        )
        summary["state"] = "PASS"
        # Fresh untimed baseline producer, after acceptance, for retained-first measurement pilot.
        seed = invoke(
            "measurement-producer-baseline",
            "baseline",
            command(config, ["query"], "--request", "-"),
            (c.REPO / "docs/reviews/public-cli-v1/query.json").read_bytes(),
        )
        c.declaration(seed, config)
        measurement = copy.deepcopy(config)
        measurement["retainedToken"] = seed["document"]["retention"]["reference"]
        measurement["retainedProducerStdout"] = str(output / "measurement-producer-baseline/stdout")
        measurement["retainedProducerReceipt"] = str(
            output / "measurement-producer-baseline/record.json"
        )
        for key in ("retainedProducerStdout", "retainedProducerReceipt"):
            measurement["identities"][measurement[key]] = c.digest(Path(measurement[key]))
        c.save(output / "measurement-ready.json", measurement)
    except (OSError, KeyError, TypeError, ValueError, KeyboardInterrupt) as error:
        summary["state"] = "FAIL"
        summary["failure"] = repr(error)
    finally:
        summary["recordedStarts"] = len(records)
        summary["recordedStartsQualification"] = (
            "outer captured children only; excludes MCP/RPC and other descendants"
        )
        summary["policyRoutes"] = [name for name, record in records.items() if record.get("policy")]
        summary["allRecordedOuterChildrenReaped"] = all(
            record.get("reapedBeforeNextInvocation") for record in records.values()
        )
        summary["identities"] = config["identities"]
        summary["completedAssertions"] = completed_assertions
        c.save(output / "summary.json", summary)
    print(
        json.dumps({"state": summary["state"], "summary": str(output / "summary.json")}), flush=True
    )
    return 0 if summary["state"] == "PASS" else 1


def self_test() -> None:
    c.self_test()
    invalid = c.load(c.PRIOR / "resume-unissued-native.stdout")
    observed = c.receipts((c.PRIOR / "resume-unissued-native.host.log").read_bytes())
    unissued_resume_oracle(invalid, observed)
    replay = copy.deepcopy(observed)
    for call in replay["semantic_read"][0]["nativeCalls"]:
        if call["call"] == "K2_ANALYSIS":
            call["entered"] = 1
    try:
        unissued_resume_oracle(invalid, replay)
    except ValueError:
        pass
    else:
        raise ValueError("unissued RESUME producer replay accepted")
    first = c.load(c.PRIOR / "baseline-issued-baseline-evidence-page0.stdout")["document"]
    last = c.load(c.PRIOR / "baseline-issued-baseline-evidence-page1.stdout")["document"]
    original = c.load(c.PRIOR / "baseline-callers.stdout")["document"]
    evidence_oracle(first, last, original)
    bad = copy.deepcopy(last)
    bad["evidence_window"]["start"] = 0
    try:
        evidence_oracle(first, bad, original)
    except ValueError:
        pass
    else:
        raise ValueError("changed evidence cursor accepted")
    three = c.load(c.PRIOR / "baseline-three-symbols.stdout")
    config = {"live": three["document"]["live"], "source": original["items"][0]["location"]["file"]}
    three_symbols(three, config)
    print(
        "PASS offline evidence/three-symbol/unissued-RESUME oracle replay; changed evidence cursor and producer replay rejected; no product starts"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--self-test", action="store_true")
    modes.add_argument("--check", type=Path)
    modes.add_argument("--run", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--authorize-ready-host", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.check:
        preflight(c.load(args.check))
        print("PASS read-only acceptance preflight; no product starts")
        return 0
    c.require(
        args.authorize_ready_host and args.output is not None,
        "--run requires ready-host authorization and new --output",
    )
    return run(c.load(args.run), args.output.resolve())


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, KeyError, TypeError, ValueError) as error:
        print(f"ACCEPTANCE_REJECTED: {error}", file=sys.stderr)
        sys.exit(2)
