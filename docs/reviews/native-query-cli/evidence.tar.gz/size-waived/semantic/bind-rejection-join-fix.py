# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# ///
"""Rebind only the corrected evidence harness; preserve every product/basis identity."""
import importlib
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c
original = HERE / "ready-epoch2-20261030T122938.550199Z/ready.json"
config = c.load(original)
script = HERE / "acceptance.py"
archived = HERE / "run-002/acceptance-before-rejection-join-fix.py"
c.require(c.digest(archived) == config["identities"][str(script)], "archived harness must match failed attempt")
config["identities"][str(archived)] = c.digest(archived)
config["identities"][str(original)] = c.digest(original)
config["identities"][str(script)] = c.digest(script)
config["harnessAmendment"] = "Negative-control joined transport terminal must be exactly REJECTED, not COMPLETED. Both archived unissued RESUME and explicit1ms logs establish this before the final run. Independent documents, exits, basis and no-replay assertions unchanged; incorrect COMPLETED mutation now rejected. run-002 remains failed."
a.preflight(config)
output = HERE / "ready-epoch2-rejection-join-fixed.json"
c.require(not output.exists(), "preserve previous config")
c.save(output, config)
print("PASS unchanged product/basis identities; corrected harness config " + str(output))
