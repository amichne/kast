# /// script
# requires-python = ">=3.13"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Prepare disposable, actual installer inputs without touching personal state."""

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

REPO = Path(__file__).resolve().parents[2]
BASE = REPO.with_name("kast.feature-native-query-baseline")
EVIDENCE = REPO / ".amp/in/artifacts/native-query"
IDEA = Path("/Users/amichne/Applications/IntelliJ IDEA.app/Contents")


@dataclass(frozen=True)
class Fixture:
    root: str
    baseline_home: str
    candidate_home: str
    assets: str
    installer_command: list[str]
    installer_exit: int


def main() -> None:
    root = Path(tempfile.mkdtemp(prefix="knq-", dir="/private/tmp"))
    baseline = root / "b"
    candidate = root / "n"
    assets = root / "assets"
    for directory in (baseline, candidate, assets):
        directory.mkdir()
    sources = [
        BASE / "build/distributions/kast-control-v0.0.0-macos-aarch64.tar.gz",
        BASE / "runtime/hosted/build/distributions/kast-ide-hosted-v0.0.0-idea-262.zip",
        BASE / "build/generated/host-release/kast-host-release-v0.0.0.json",
        BASE / "packaging/host-installation.py",
    ]
    for source in sources:
        target = assets / source.name
        shutil.copy2(source, target)
        digest = hashlib.file_digest(target.open("rb"), "sha256").hexdigest()
        target.with_name(target.name + ".sha256").write_text(f"{digest}  {target.name}\n")
    environment = {
        "PATH": os.environ["PATH"],
        "HOME": str(baseline),
        "USER": os.environ["USER"],
        "LANG": "en_US.UTF-8",
        "KAST_VERSION": "0.0.0",
        "KAST_HOST_VERSION": "0.0.0",
        "KAST_INSTALL_ASSETS_DIRECTORY": str(assets),
        "KAST_INSTALL_PROFILE": "persistent",
        "JAVA_TOOL_OPTIONS": f"-Duser.home={baseline}",
    }
    command = ["/bin/bash", str(BASE / "install.sh"), "--idea-home", str(IDEA), "--skip-codex-plugin", "--verbose"]
    with (EVIDENCE / "baseline-install.stdout").open("wb") as stdout, (EVIDENCE / "baseline-install.stderr").open("wb") as stderr:
        result = subprocess.run(command, env=environment, cwd=root, stdout=stdout, stderr=stderr, check=False)
    fixture = Fixture(str(root), str(baseline), str(candidate), str(assets), command, result.returncode)
    (EVIDENCE / "fixture.json").write_text(json.dumps(asdict(fixture), indent=2) + "\n")
    print(json.dumps(asdict(fixture), indent=2))
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
