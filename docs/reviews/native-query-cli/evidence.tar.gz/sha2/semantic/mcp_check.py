# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["pydantic==2.12.3", "jsonschema==4.25.1", "anyio==4.12.1", "mcp==1.26.0"]
# [tool.uv]
# no-build = true
# ///
"""Installed stdio task-service/RPC acceptance, outside native-query timing and JVM claims."""

from __future__ import annotations

import argparse
import copy
import importlib
import json
import sys
from pathlib import Path
from typing import Any

import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import get_default_environment, stdio_client
from mcp.types import TextContent

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c


def oracle(result: Any, config: Any) -> None:
    c.require(result["type"] == "complete", "MCP complete envelope")
    d = result["document"]
    c.require(d["operation"] == "query.run" and d["status"] == "complete", "MCP operation/status")
    c.require(
        d["live"] == config["live"] and d["coverage"] == {"exhaustive": True},
        "MCP exact live basis/coverage",
    )
    c.require(
        d["question"]
        == {
            "from": {
                "type": "symbols",
                "match": {"type": "name", "text": "OrderService", "matching": "exact-name"},
                "scope": {
                    "sourceSets": ["main", "test"],
                    "directory": {"path": ".", "containment": "descendants"},
                    "packageName": None,
                },
                "declarationKinds": ["class", "function", "property", "type-alias"],
            },
            "steps": [],
            "output": {"type": "symbols", "fields": ["name", "location", "signature"]},
            "completion": {"type": "COMPLETE_ONLY", "model": "COMPILER_RESOLVED_STATIC_V1"},
        },
        "MCP independent default question and ordered fields",
    )
    c.require(len(d["items"]) == 1, "MCP one known declaration")
    row = d["items"][0]
    c.require(row["name"] == "OrderService" and row["kind"] == "classlike", "MCP name/kind")
    c.require(
        row["signature"] == {"type": "class-like", "qualifiedIdentity": "example.OrderService"},
        "MCP signature",
    )
    c.require(
        row["location"]
        == {"file": config["source"], "range": {"startInclusive": 17, "endExclusive": 94}},
        "MCP exact file/range",
    )
    c.require(row["connections"] == [], "MCP declaration has no connections")
    c.require(
        d["original_evidence_summary"]
        == {"failure_count": 0, "omission_count": 0, "evidence_count": 1},
        "MCP original evidence",
    )


async def session(config: Any, output: Path) -> None:
    a.preflight(config)
    c.require(
        output.is_relative_to(HERE / "mcp") and not output.exists(),
        "new semantic/mcp output required",
    )
    output.mkdir(parents=True)
    c.save(output / "config.json", config)
    installation = Path(config["routes"]["native"]["manifest"]).parent
    home = config["routes"]["native"]["environment"]["HOME"]
    manifest = c.load(installation / "installation.json")
    verified = 0
    for entry in manifest["payloadFiles"]:
        path = installation / entry["path"]
        c.require(
            path.resolve(strict=True).is_relative_to(installation.resolve())
            and not path.is_symlink(),
            "manifest regular owned path",
        )
        c.require(
            "sha256:" + c.digest(path) == entry["sha256"],
            "MCP package payload mismatch: " + entry["path"],
        )
        verified += 1
    server = installation / "share/kast/agent-tools/plugins/kast/skills/kast/scripts/server.py"
    rpc = installation / "bin/kast-tool-rpc-complete"
    owned = {entry["path"] for entry in manifest["payloadFiles"]}
    c.require(
        str(server.relative_to(installation)) in owned
        and str(rpc.relative_to(installation)) in owned
        and "bin/kast-tool-rpc" in owned,
        "packaged task-service and RPC launchers required",
    )
    environment = {
        "PATH": "/usr/bin:/bin:/opt/homebrew/bin",
        "HOME": home,
        "JAVA_HOME": str(Path(config["controlJava"]).parents[1]),
        "JAVA_TOOL_OPTIONS": "-Duser.home=" + home,
        "KAST_CONFIGURATION_FILE": str(installation / "config/environment"),
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    parameters = StdioServerParameters(
        command=sys.executable,
        args=[str(server), "--rpc", str(rpc), "--workspace", config["live"]["root"]],
        env=environment,
        cwd=config["live"]["root"],
    )
    c.save(output / "parameters.json", parameters.model_dump())
    c.save(output / "effective-environment.json", get_default_environment() | environment)
    c.save(
        output / "payload-verification.json",
        {
            "manifestSha256": c.digest(installation / "installation.json"),
            "verifiedPayloadFiles": verified,
            "queryPayloadSha256": c.digest(installation / "bin/kast-query"),
            "serverSha256": c.digest(server),
            "rpcWrapperSha256": c.digest(rpc),
            "rpcLauncherSha256": c.digest(installation / "bin/kast-tool-rpc"),
            "qualification": "actual installed final package; no native-query or zero-JVM claim",
        },
    )
    log = Path(config["hostLog"])
    before = log.stat()
    result_summary: dict[str, Any] = {
        "state": "INCOMPLETE",
        "sessionClosed": False,
        "outsideLatencyCohort": True,
        "outsideZeroQueryJvmClaim": True,
    }
    try:
        with (output / "stderr").open("w") as errors, anyio.fail_after(120):
            async with (
                stdio_client(parameters, errlog=errors) as streams,
                ClientSession(*streams) as client,
            ):
                initialization = await client.initialize()
                c.save(output / "initialize.json", initialization.model_dump())
                tools = await client.list_tools()
                c.save(output / "tools.json", tools.model_dump())
                c.require(
                    {"find", "callers", "source", "result"} <= {tool.name for tool in tools.tools},
                    "installed task catalog",
                )
                c.save(
                    output / "call.json", {"name": "find", "arguments": {"name": "OrderService"}}
                )
                result = await client.call_tool("find", {"name": "OrderService"})
                c.save(output / "find.json", result.model_dump())
                c.require(
                    not result.isError and len(result.content) == 1,
                    "MCP one successful text result",
                )
                block = result.content[0]
                if not isinstance(block, TextContent):
                    raise ValueError("MCP expected TextContent")
                (output / "find-document.stdout").write_text(block.text)
                document = json.loads(block.text)
                oracle(document, config)
                c.require(
                    result.structuredContent == document, "MCP structured/text result equivalence"
                )
            result_summary["sessionClosed"] = True
        after = log.stat()
        c.require(
            (before.st_dev, before.st_ino) == (after.st_dev, after.st_ino)
            and after.st_size >= before.st_size,
            "MCP host log rotation",
        )
        with log.open("rb") as stream:
            stream.seek(before.st_size)
            raw = stream.read(after.st_size - before.st_size)
        (output / "host.log").write_bytes(raw)
        observed = c.receipts(raw)
        c.save(output / "host-receipts.json", observed)
        a.host_identity({"receipts": observed}, config)
        c.check_receipts(observed, config, "discovery")
        a.preflight(config)
        result_summary["state"] = "PASS"
        result_summary["oracle"] = (
            "independent exact OrderService declaration, fields, ranges, basis, coverage, completion, host join"
        )
    except BaseException as error:
        result_summary["state"] = "FAIL"
        result_summary["failure"] = repr(error)
        raise
    finally:
        c.save(output / "summary.json", result_summary)
        # Preserve the interval even if initialization or an oracle fails. The
        # outer collector separately keeps its own log slice and exit receipt.
        after = log.stat()
        c.save(
            output / "host-log-boundary.json",
            {
                "before": {"device": before.st_dev, "inode": before.st_ino, "size": before.st_size},
                "after": {"device": after.st_dev, "inode": after.st_ino, "size": after.st_size},
            },
        )
        if (before.st_dev, before.st_ino) == (
            after.st_dev,
            after.st_ino,
        ) and after.st_size >= before.st_size:
            with log.open("rb") as stream:
                stream.seek(before.st_size)
                (output / "host-final.log").write_bytes(stream.read(after.st_size - before.st_size))


def self_test() -> None:
    prior = c.load(c.PRIOR.parent / "installed-mcp-find.json")
    result = json.loads(prior["content"][0]["text"])
    config = {
        "live": result["document"]["live"],
        "source": result["document"]["items"][0]["location"]["file"],
    }
    oracle(result, config)
    changed = copy.deepcopy(result)
    changed["document"]["items"][0]["location"]["range"]["startInclusive"] = 18
    try:
        oracle(changed, config)
    except ValueError:
        print(
            "PASS offline MCP oracle replay and changed-range rejection; no server/RPC/host starts"
        )
    else:
        raise ValueError("MCP changed range admitted")
    print(json.dumps({"mcpPython": sys.executable, "sha256": c.digest(Path(sys.executable))}))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--self-test", action="store_true")
    modes.add_argument("--run", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--authorize-ready-host", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    c.require(
        args.authorize_ready_host and args.output is not None,
        "MCP requires explicit ready-host authorization",
    )
    anyio.run(session, c.load(args.run), args.output.resolve())
    print("PASS final installed stdio task service and packaged JVM RPC")
    return 0


if __name__ == "__main__":
    sys.exit(main())
