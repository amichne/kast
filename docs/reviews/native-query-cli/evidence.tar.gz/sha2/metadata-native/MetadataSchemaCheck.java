import com.networknt.schema.InputFormat;
import com.networknt.schema.SchemaRegistry;
import com.networknt.schema.SpecificationVersion;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reconstructed standalone validator: consumes native output, not a JVM CLI substitute. */
class MetadataSchemaCheck {
    public static void main(String[] args) throws Exception {
        Path directory = Path.of(args[0]);
        var registry = SchemaRegistry.withDefaultDialect(SpecificationVersion.DRAFT_2020_12);
        int count = 0;
        int invalid = 0;
        for (String line : Files.readAllLines(directory.resolve("validator-cases.tsv"))) {
            String[] fields = line.split("\t");
            if (fields.length != 3 || !(fields[1].equals("valid") || fields[1].equals("invalid"))) {
                throw new AssertionError("Malformed validator case: " + line);
            }
            var schema = registry.getSchema(Files.readString(directory.resolve(fields[0] + "-plan.schema.json")));
            boolean expected = fields[1].equals("valid");
            var errors = schema.validate(Files.readString(Path.of(fields[2])), InputFormat.JSON);
            boolean valid = errors.isEmpty();
            System.out.println(line + " expected=" + expected + " valid=" + valid);
            if (valid != expected) throw new AssertionError("Unexpected schema result: " + errors);
            count++;
            if (!expected) invalid++;
        }
        if (count != 99 || invalid != 4) throw new AssertionError("Wrong control inventory");
        System.out.println("NETWORKNT_VALIDATION_PASS=" + count);
    }
}
