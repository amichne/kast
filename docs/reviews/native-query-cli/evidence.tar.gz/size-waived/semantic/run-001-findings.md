# Final correctness attempt 001 — stopped at exact basis mismatch

Authorized readiness receipt: `../lifecycle/ready-host-receipt.json`, SHA-256 `7f5259a0da2bd0a7f29fab02b6c1f5217fae404781cd2325597eeab32abda541`.

Command (from repository root):

```sh
S=.amp/in/artifacts/native-query/size-waived/semantic
uv run --no-project --offline --locked --script "$S/acceptance.py" \
  --run "$S/ready.json" --authorize-ready-host --output "$S/run-001"
```

- PASS: exact copied JBR Java directly and beneath `/bin/sh` executes with the positive allowlist and fails with `Operation not permitted` under the query allowlist. All four raw command/environment/output/exit records remain in `run-001/jvm-control-*`.
- FAIL: the first baseline declaration exited 0, but exact receipt host/basis assertion rejected epoch2 against authorized epoch1. The assertion was not loosened, and no semantic fact was normalized to pass it.
- Same host: PID22176, UUID `2cd3f767-77b0-448c-b166-d9c526738a37`, exact workspace `/private/tmp/knq-lifecycle-5VGhDa/workspace`, `SAVED_PSI_COMMITTED`, version1. Both stdout and semantic read correlation independently contain epoch2.
- Joined read ID `19db797e-b3ae-4ecd-b78d-87184314b97b`, connection ID `2f248c94-0ec0-4ca6-81d7-3a60b3c9a58e`. See `run-001/baseline-declaration/{stdout,stderr,record.json,host.log}`. Captured host log bytes631872–689726.
- The returned declaration has `example.OrderService`, classlike kind, and range17–94. This does not make the attempt pass its frozen exact-basis assertion.
- NOT RUN: remaining native semantic cases, retained/source/pagination controls, unissued RESUME negatives, explicit1ms comparison, packaged MCP/RPC, fresh measurement producer, pilot, and cohort.
- Cleanup: all five captured outer children exited and were reaped. No host stop, installation change, source change, or Gradle invocation was performed.

Required next input: main/lifecycle confirmation of a stable authoritative basis, with a new readiness receipt if epoch2 is now the intended basis. Preserve epoch1 receipt, `ready.json`, and `run-001`; bind any later authorized basis into a new config and output directory. No pilot-ready configuration was emitted.

Prepared package identities remain native query `7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0`, management `f5c86b3c1ec27d676c4c19392213e7455d3b34d4e1a8ef3457a04b80a910ae01`, candidate manifest `45e892d90fa932beb305019512cca82d369965866971754308c18d902f9140f9`; the initial preflight verified these against the authorized installation receipt.
