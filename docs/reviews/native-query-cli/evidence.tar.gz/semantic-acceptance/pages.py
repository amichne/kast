"""Collect retained row/evidence page and source-selector follow-ups, using issued bytes."""
import json
from acceptance import OUT, FIELDS, GRANTS, command, invoke

def load(name):
    return json.loads((OUT / (name + '.stdout')).read_text())['document']

for route in ['baseline', 'native']:
    declaration = load(route + '-declaration')
    caller = load(route + '-callers')
    refs = [declaration['items'][0]['ref']] + [n['symbol']['selector'] for n in caller['relation_graph']['nodes']]
    args = command(['query'], *FIELDS, *GRANTS, '--retain')
    for ref in refs:
        args += ['--ref', ref]
    full, record = invoke(route + '-three-symbols', route, args)
    assert record['exitCode'] == 0
    names = {i['name'] for i in full['document']['items']}
    assert names == {'OrderService', 'submitOrder', 'placeOrder'} and len(full['document']['items']) == 3
    reference = full['document']['retention']['reference']
    for reader in (['baseline', 'native'] if route == 'baseline' else ['native']):
        invoke(route + '-issued-' + reader + '-row-page0', reader, command(['result', 'read'], '--ref', reference, *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152'))
        invoke(route + '-issued-' + reader + '-evidence-page0', reader, command(['result', 'read'], '--ref', caller['retention']['reference'], *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152', '--verbose'))
        source = load(route + '-issued-' + ('baseline' if route == 'baseline' else 'native') + '-source')
        selector = source['region']['selection']['selector']
        invoke(route + '-issued-' + reader + '-source-selector', reader, command(['source', 'read'], '--ref', selector))
