"""Capture one explicitly authorized lifecycle command; never advance automatically."""

from __future__ import annotations

import argparse
import json
import subprocess
import time

from live_worker import HERE, ROOT, digest, save


def snapshot() -> dict[str, object]:
    files: dict[str, object] = {}
    for home in ("h", "baseline-home", "home", "r"):
        for relative in (
            ".local/bin/kast",
            ".local/share/kast/management.json",
            ".local/share/kast/installation/installation.json",
            ".local/share/kast/installation/bin/kast-query",
            ".local/share/kast/installation/share/kast/libexec/kast-management",
        ):
            path = ROOT / home / relative
            if path.is_file():
                attributes = path.stat()
                files[str(path)] = {
                    "sha256": digest(path),
                    "device": attributes.st_dev,
                    "inode": attributes.st_ino,
                    "size": attributes.st_size,
                }
    observed = subprocess.run(
        ["/bin/ps", "-axo", "pid=,ppid=,lstart=,state=,comm="],
        capture_output=True,
        text=True,
        check=True,
    )
    processes = [
        line
        for line in observed.stdout.splitlines()
        if str(ROOT) in line or line.split()[0] in {"12733", "22172", "22174", "22176"}
    ]
    run = ROOT / "h/.local/share/kast/installation/state/run"
    records = {
        str(path): path.read_text() for path in run.glob("one-shot/*.json") if path.is_file()
    }
    return {"files": files, "processes": processes, "records": records, "time": time.time()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case")
    parser.add_argument("--status")
    parser.add_argument("--label")
    parser.add_argument("--home", choices=["h", "r"], default="h")
    parser.add_argument("--authorize-after-collection", action="store_true", required=True)
    options = parser.parse_args()
    if bool(options.case) == bool(options.status):
        parser.error("choose exactly one --case or --status label")
    plan = json.loads((HERE / "validation-plan.json").read_text())
    if options.case:
        case = next(case for case in plan["sequence"] if case["case"] == options.case)
        command = case.get("command") or [plan["publicCommand"], *case["commandArguments"]]
        environment = case.get("environment", plan["managementEnvironment"])
        directory = case.get("directory", str(ROOT / "workspace"))
        label = case.get("evidenceSubdirectory", options.case)
    else:
        command = [str(ROOT / options.home / ".local/bin/kast"), "status", "--json"]
        environment = dict(plan["managementEnvironment"], HOME=str(ROOT / options.home))
        directory = str(ROOT / "workspace")
        label = options.status
    label = options.label or label
    output = HERE / label
    if output.parent != HERE or output.exists():
        parser.error("output must be a fresh direct child of evidence directory")
    output.mkdir()
    save(
        output / "command.json",
        {"command": command, "environment": environment, "directory": directory},
    )
    save(output / "before.json", snapshot())
    started = time.monotonic()
    with (output / "stdout").open("xb") as stdout, (output / "stderr").open("xb") as stderr:
        result = subprocess.run(
            command, env=environment, cwd=directory, stdout=stdout, stderr=stderr
        )
    save(
        output / "result.json",
        {"exitCode": result.returncode, "durationSeconds": time.monotonic() - started},
    )
    save(output / "after.json", snapshot())
    print(json.dumps({"output": str(output), "exitCode": result.returncode}), flush=True)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
