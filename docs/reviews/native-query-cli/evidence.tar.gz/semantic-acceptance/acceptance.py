"""Installed-product correctness collection, deliberately not a latency cohort."""
from pathlib import Path
import copy
import hashlib
import json
import os
import subprocess
import sys
import time

REPO = Path('/Users/amichne/code/kast.feature-native-query-cli')
OUT = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/knq-iwg1g7v8')
WORKSPACE = Path('/private/tmp/kast-public-cli-v1-a3b5uat_/workspace')
SOURCE = WORKSPACE / 'src/main/kotlin/example/OrderService.kt'
HOST = 'a37aac46-4b61-4426-830a-8e9186f8d464'
LOG = ROOT / 'idea-logs/idea.log'
ENDPOINT = ROOT / 'n/.kast/ide-hosted/b00e70b458865193c9bd7d785206e125/endpoint.json'
FIELDS = ['--fields', 'name,signature,location']
GRANTS = ['--max-results', '128', '--max-returned-bytes', '49152']

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def records(text, marker):
    return [json.loads(line.split(marker, 1)[1]) for line in text.splitlines() if marker in line]

def invoke(name, route, args, request=b'', policy=False):
    home = ROOT / ('b' if route == 'baseline' else 'n')
    env = {'HOME': str(home), 'PATH': '/usr/bin:/bin:/opt/homebrew/bin'}
    if route == 'baseline':
        env['JAVA_TOOL_OPTIONS'] = '-Duser.home=' + str(ROOT / 'n')
    argv = [str(home / '.local/bin/kast')] + args
    if policy:
        assert route == 'native'
        profile = OUT.parent / 'installed-native-exec.sb'
        argv = ['/usr/bin/sandbox-exec', '-f', str(profile)] + argv
    assert not (OUT / (name + '.json')).exists(), name
    offset = LOG.stat().st_size
    record = {'name': name, 'route': route, 'argv': argv, 'environment': env, 'cwd': str(WORKSPACE), 'hostLogStart': offset, 'notLatencySample': True}
    save(name + '.json', record)
    (OUT / (name + '.stdin')).write_bytes(request)
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=WORKSPACE, env=env, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr)
        record['pid'] = process.pid
        record['startMonotonicNs'] = time.monotonic_ns()
        save(name + '.json', record)
        try:
            process.communicate(request, timeout=120)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
            record['harnessTimeout'] = True
        record['exitCode'] = process.returncode
        record['reapedBeforeNextInvocation'] = process.poll() is not None
        record['endMonotonicNs'] = time.monotonic_ns()
    with LOG.open('rb') as stream:
        stream.seek(offset)
        host = stream.read()
    (OUT / (name + '.host.log')).write_bytes(host)
    record['hostLogEnd'] = offset + len(host)
    record['semantic'] = records(host.decode(), ' - kast_semantic_read ')
    record['transport'] = records(host.decode(), ' - kast_transport ')
    save(name + '.json', record)
    print(name, 'exit', record['exitCode'], flush=True)
    raw = (OUT / (name + '.stdout')).read_bytes()
    assert raw.endswith(b'\n') and raw.count(b'\n') == 1, (name, 'framing')
    return json.loads(raw), record

def command(words, *args):
    return words + ['--catalog', 'complete', '--workspace', str(WORKSPACE)] + list(args)

def common(result, name, relation=False):
    assert result['type'] == 'complete'
    d = result['document']
    assert d['status'] == 'complete'
    assert d['coverage'] == {'exhaustive': True}
    assert d['question'] == {
        'from': {'type': 'symbols', 'match': {'type': 'name', 'text': name, 'matching': 'exact-name'}, 'scope': {'sourceSets': ['main', 'test'], 'directory': {'path': '.', 'containment': 'descendants'}, 'packageName': None}, 'declarationKinds': ['class', 'function', 'property', 'type-alias']},
        'steps': [{'type': 'related', 'relation': 'callers'}] if relation else [],
        'output': {'type': 'symbols', 'fields': ['name', 'signature', 'location']},
        'completion': {'type': 'COMPLETE_ONLY', 'model': 'COMPILER_RESOLVED_STATIC_V1'},
    }
    assert d['live'] == {'root': str(WORKSPACE), 'host': HOST, 'epoch': 2, 'contentView': 'SAVED_PSI_COMMITTED', 'version': 1}
    return d

def declaration(result):
    d = common(result, 'OrderService')
    assert len(d['items']) == 1
    i = d['items'][0]
    assert i['name'] == 'OrderService' and i['kind'] == 'classlike'
    assert i['signature'] == {'type': 'class-like', 'qualifiedIdentity': 'example.OrderService'}
    assert i['location'] == {'file': str(SOURCE), 'range': {'startInclusive': 17, 'endExclusive': 94}}
    assert i['connections'] == []
    assert d['original_evidence_summary'] == {'failure_count': 0, 'omission_count': 0, 'evidence_count': 1}

def caller(result):
    d = common(result, 'submitOrder', True)
    assert len(d['items']) == 1
    i = d['items'][0]
    assert i['name'] == 'placeOrder' and i['kind'] == 'function'
    assert i['signature'] == {'type': 'function', 'qualifiedIdentity': 'example.placeOrder', 'receiver': {'type': 'absent'}, 'contextReceivers': [], 'valueParameters': ['example/OrderService'], 'typeParameterCount': 0}
    assert i['location'] == {'file': str(SOURCE), 'range': {'startInclusive': 96, 'endExclusive': 174}}
    g = d['relation_graph']
    assert g['basis'] == d['retention']['reference'] == g['detail']['request']['result']
    nodes = {n['symbol']['qualifiedIdentity']: n for n in g['nodes']}
    assert set(nodes) == {'example.placeOrder', 'example.OrderService.submitOrder'}
    assert nodes['example.OrderService.submitOrder']['symbol']['range'] == {'startInclusive': 42, 'endExclusive': 92}
    assert len(g['connection_witnesses']) == 1
    edge = g['connection_witnesses'][0]
    assert edge['source'] == nodes['example.placeOrder']['id'] == i['node']
    assert edge['target'] == nodes['example.OrderService.submitOrder']['id']
    assert i['connections'] == [edge['id']]
    assert edge['meaning'] == 'callers' and edge['direction'] == 'SOURCE_TO_TARGET'
    assert edge['provenance'] == 'k2-authored-source' and edge['coverage'] == 'exact-compiler-confirmed'
    assert edge['occurrence']['file'] == str(SOURCE)
    assert edge['occurrence']['range'] == {'startInclusive': 152, 'endExclusive': 163}
    assert d['original_evidence_summary'] == {'failure_count': 0, 'omission_count': 0, 'evidence_count': 2}

def normalized(result):
    d = result['document']
    tokens = {d['retention']['reference']: '<fresh-result>'}
    for index, item in enumerate(d['items']):
        tokens[item['row_id']] = '<fresh-row-' + str(index) + '>'
    def visit(value):
        if isinstance(value, str):
            return tokens.get(value, value)
        if isinstance(value, list):
            return [visit(v) for v in value]
        if isinstance(value, dict):
            return {k: visit(v) for k, v in value.items()}
        return value
    return visit(result)

def main():
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == 'c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859'
    endpoint = json.loads(ENDPOINT.read_text())
    assert endpoint['host'] == HOST and endpoint['hostPid'] == 88083
    save('endpoint-before.json', endpoint)
    request = (REPO / 'docs/reviews/public-cli-v1/query.json').read_bytes()
    results = {}
    for route in ['baseline', 'native']:
        result, record = invoke(route + '-declaration', route, command(['query'], '--request', '-'), request)
        assert record['exitCode'] == 0
        declaration(result)
        results[route + '-declaration'] = result
        # A has exited and been waited for before this independent B is created.
        for reader in (['baseline', 'native'] if route == 'baseline' else ['native']):
            original = result['document']
            follow, r = invoke(route + '-issued-' + reader + '-read', reader, command(['result', 'read'], '--ref', original['retention']['reference'], *FIELDS, *GRANTS))
            assert r['exitCode'] == 0 and r['pid'] != record['pid']
            assert follow['document']['items'] == original['items']
            assert follow['document']['retention'] == original['retention']
            assert follow['document']['live'] == original['live']
            assert follow['document']['coverage'] == original['coverage']
            invoke(route + '-issued-' + reader + '-source', reader, command(['source', 'read'], '--ref', original['items'][0]['ref']))
        args = command(['query'], '--name', 'submitOrder', '--relation', 'callers', *FIELDS, *GRANTS, '--retain')
        c, r = invoke(route + '-callers', route, args)
        assert r['exitCode'] == 0
        caller(c)
        results[route + '-callers'] = c
        for name, relation in [('NoSuchNativeAcceptanceDeclaration', False), ('placeOrder', True)]:
            args = command(['query'], '--name', name, *FIELDS, *GRANTS, '--retain')
            if relation:
                args += ['--relation', 'callers']
            empty, r = invoke(route + '-' + ('wrong-target' if relation else 'absent-name'), route, args)
            assert r['exitCode'] == 0
            assert common(empty, name, relation)['items'] == []
            results[route + '-' + ('wrong-target' if relation else 'absent-name')] = empty
    for case in ['declaration', 'callers', 'absent-name', 'wrong-target']:
        assert normalized(results['baseline-' + case]) == normalized(results['native-' + case]), case
    # These mutations must fail independent oracles, not merely equality to the other client.
    mutations = [
        ('range', 'declaration', lambda d: d['items'][0]['location']['range'].update(startInclusive=18)),
        ('coverage', 'declaration', lambda d: d.update(coverage={'exhaustive': False})),
        ('host', 'declaration', lambda d: d['live'].update(host='wrong-host')),
        ('fields', 'declaration', lambda d: d['question']['output'].update(fields=['name'])),
        ('target', 'callers', lambda d: d['relation_graph']['connection_witnesses'][0].update(target=d['relation_graph']['connection_witnesses'][0]['source'])),
        ('graph-link', 'callers', lambda d: d['relation_graph'].update(basis='result:v1:unissued')),
    ]
    rejected = []
    for name, case, mutate in mutations:
        bad = copy.deepcopy(results['native-' + case])
        mutate(bad['document'])
        try:
            (declaration if case == 'declaration' else caller)(bad)
        except AssertionError:
            rejected.append(name)
        else:
            raise AssertionError('Comparator accepted ' + name)
    save('stage1-assertions.json', {'parity': 'PASS', 'independentDeclarationAndCaller': 'PASS', 'emptyControls': 'PASS', 'tokenReads': 'PASS', 'rejectedComparatorMutations': rejected, 'sourceAssertions': 'PENDING', 'noProducerReplayAssertions': 'PENDING'})

if __name__ == '__main__':
    main()
