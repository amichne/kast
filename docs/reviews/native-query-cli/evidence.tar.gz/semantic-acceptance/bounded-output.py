"""Look for a legitimately issued output continuation at the minimum byte grant."""
import json
from acceptance import OUT, FIELDS, command, invoke

for route in ['baseline', 'native']:
    caller = json.loads((OUT / (route + '-callers.stdout')).read_text())['document']
    invoke('bounded-output-' + route, route, command(['result', 'read'], '--ref', caller['retention']['reference'], *FIELDS, '--max-results', '128', '--max-returned-bytes', '4096', '--verbose'), policy=route == 'native')
