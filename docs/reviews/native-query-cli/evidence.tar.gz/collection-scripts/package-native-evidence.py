# /// script
# requires-python = ">=3.13"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Freeze this task's source identity and raw evidence, excluding product binaries."""

import hashlib
import json
import shutil
import subprocess
import tarfile
from dataclasses import asdict, dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / ".amp/in/artifacts/native-query"
DESTINATION = ROOT / "docs/reviews/native-query-cli/evidence.tar.gz"


@dataclass(frozen=True)
class FileIdentity:
    path: str
    bytes: int
    sha256: str


def identity(path: Path, base: Path) -> FileIdentity:
    data = path.read_bytes()
    return FileIdentity(
        path.relative_to(base).as_posix(), len(data), hashlib.sha256(data).hexdigest()
    )


def git(*args: str) -> bytes:
    return subprocess.run(["/usr/bin/git", *args], cwd=ROOT, check=True, capture_output=True).stdout


def main() -> None:
    source = EVIDENCE / "source-snapshot"
    source.mkdir(exist_ok=True)
    paths = set(git("diff", "--name-only", "-z").decode().split("\0"))
    paths.update(git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0"))
    selected = sorted(
        ROOT / name
        for name in paths
        if name and not name.startswith("docs/reviews/native-query-cli")
    )
    identities = [asdict(identity(path, ROOT)) for path in selected]
    (source / "identities.json").write_text(
        json.dumps(identities, indent=2) + "\n", encoding="utf-8"
    )
    (source / "head.txt").write_bytes(git("rev-parse", "HEAD"))
    (source / "status.txt").write_bytes(git("status", "--short", "--branch"))
    (source / "tracked.diff").write_bytes(git("diff", "--binary"))
    for path in selected:
        target = source / "files" / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    scripts = EVIDENCE / "collection-scripts"
    scripts.mkdir(exist_ok=True)
    for path in sorted((ROOT / ".amp/in").glob("native-query-*.py*")):
        shutil.copy2(path, scripts / path.name)
    shutil.copy2(Path(__file__), scripts / Path(__file__).name)
    lock = Path(str(__file__) + ".lock")
    shutil.copy2(lock, scripts / lock.name)
    candidates = sorted(path for path in EVIDENCE.rglob("*") if path.is_file())
    retained = [
        path
        for path in candidates
        if path.suffix not in {".html", ".pyc"}
        and not path.name.endswith(".tar.gz")
        and "__pycache__" not in path.parts
        and path.name != "bundle-inventory.json"
    ]
    inventory = EVIDENCE / "bundle-inventory.json"
    inventory.write_text(
        json.dumps([asdict(identity(path, EVIDENCE)) for path in retained], indent=2) + "\n",
        encoding="utf-8",
    )
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(DESTINATION, "w:gz") as archive:
        for path in [*retained, inventory]:
            archive.add(path, arcname=path.relative_to(EVIDENCE), recursive=False)
    with tarfile.open(DESTINATION, "r:gz") as archive:
        for expected in retained:
            member = archive.extractfile(expected.relative_to(EVIDENCE).as_posix())
            assert member is not None
            with member:
                assert member.read() == expected.read_bytes(), expected
    print(json.dumps(asdict(identity(DESTINATION, ROOT)), indent=2))
    print(f"Verified {len(retained)} raw evidence members byte-for-byte")


if __name__ == "__main__":
    main()
