#!/usr/bin/env -S uv run --locked --script
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["pytest==8.4.2", "ruff==0.14.3", "pyright==1.1.408"]
# [tool.uv]
# no-build = true
# required-version = ">=0.12.9"
# [[tool.uv.index]]
# name = "pypi"
# url = "https://pypi.org/simple"
# default = true
# ///
"""Reconstructed local-only qualification; never infers expectations from new output."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import cast
from urllib.parse import unquote, urlparse

type Json = None | bool | int | float | str | list[Json] | dict[str, Json]
HERE = Path(__file__).resolve().parent
SANDBOX = "(version 1)(allow default)(deny network*)(deny file-write*)"
MODE = "-XX:MissingRegistrationReportingMode=Exit"
COMMANDS = {"query", "query.plan", "result.read", "result.resume", "source.read", "describe"}

if not __debug__:
    raise RuntimeError("Qualification requires enabled test assertions; do not use python -O")


def obj(value: Json) -> dict[str, Json]:
    assert isinstance(value, dict), "Expected JSON object"
    return value


def array(value: Json) -> list[Json]:
    assert isinstance(value, list), "Expected JSON array"
    return value


def string(value: Json) -> str:
    assert isinstance(value, str), "Expected JSON string"
    return value


def decode(raw: str | bytes) -> Json:
    return cast(Json, json.loads(raw))


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


@dataclass(frozen=True)
class Case:
    name: str
    args: tuple[str, ...]
    input_hex: str
    expected_exit: int
    open_stdin: bool = False


def expected_exit(name: str, args: tuple[str, ...], payload: bytes) -> int:
    """Public contract: planning accepts RUN, not retained/source/resume actions."""
    if "-invalid-" in name or name in {
        "duplicate-fields",
        "invalid-utf8",
        "trailing-json",
        "empty-input",
        "common-restriction",
    }:
        return 2
    if args[:2] == ("query", "plan") and "--request" in args:
        request = obj(obj(decode(payload))["request"])
        return 0 if request.get("type") == "RUN" else 2
    return 0


def recover(previous: Path) -> None:
    """Explicit archive transformation only; does not execute any child program."""
    manifest = HERE / "cases.json"
    assert not manifest.exists(), "Refusing to replace prepared inputs"
    raw = (previous / "native-matrix.log").read_text()
    cases: list[Case] = []
    for block in re.split(r"\nCASE ", raw)[1:]:
        lines = block.splitlines()
        name = lines[0]
        command = shlex.split(lines[1].removeprefix("COMMAND "))
        args = tuple(command[command.index(MODE) + 1 :])
        is_file = "--request" in args and args[args.index("--request") + 1] != "-"
        input_name = name.removesuffix("-file") + "-stdin" if is_file else name
        input_path = previous / f"{input_name}.stdin"
        payload = input_path.read_bytes() if input_path.exists() else b""
        if is_file:
            args = tuple(
                "{request-file}" if value.endswith("request with spaces.json") else value
                for value in args
            )
        status = expected_exit(name, args, payload)
        recorded = re.search(r"^EXPECTED (\d+) ACTUAL (\d+)$", block, re.M)
        if name != "metadata-open-stdin":
            assert recorded and int(recorded[1]) == status, name
        cases.append(Case(name, args, payload.hex(), status, name == "metadata-open-stdin"))
    assert len(cases) == 158 and len({case.name for case in cases}) == 158
    manifest.write_text(json.dumps([asdict(case) for case in cases], indent=2) + "\n")
    for filename in (
        "resource-inventory.tsv",
        "validator-cases.tsv",
        "kast-hosted-platform.properties",
    ):
        shutil.copyfile(previous / filename, HERE / ("expected-" + filename))
    source_sha = re.search(r"^SHA256 (\w+)$", raw, re.M)
    assert source_sha is not None
    (HERE / "reconstruction.json").write_text(
        json.dumps(
            {
                "source_log": str(previous / "native-matrix.log"),
                "source_log_sha256": digest(previous / "native-matrix.log"),
                "source_executable_sha256": source_sha[1],
                "cases_sha256": digest(manifest),
                "original_driver_recovered": False,
                "expectations": "Explicit contract predicates cross-checked against recorded EXPECTED exits, not ACTUAL exits",
            },
            indent=2,
        )
        + "\n"
    )


def load_cases() -> list[Case]:
    cases: list[Case] = []
    for entry in array(decode((HERE / "cases.json").read_text())):
        row = obj(entry)
        status = row["expected_exit"]
        assert isinstance(status, int)
        case = Case(
            string(row["name"]),
            tuple(string(v) for v in array(row["args"])),
            string(row["input_hex"]),
            status,
            row["open_stdin"] is True,
        )
        assert case.expected_exit == expected_exit(
            case.name, case.args, bytes.fromhex(case.input_hex)
        )
        # Reject any accidental semantic execution except the known admission failures.
        assert (
            case.expected_exit == 2
            or case.args[0] == "describe"
            or "--help" in case.args
            or case.args[:2] == ("query", "plan")
        )
        cases.append(case)
    assert len(cases) == len({case.name for case in cases}) == 158
    return cases


def recursive_refs(schema: Json) -> int:
    """Resolve all local references without unfolding recursive definitions."""
    count = 0
    stack = [schema]
    while stack:
        item = stack.pop()
        if isinstance(item, dict):
            if "$ref" in item:
                ref = string(item["$ref"])
                assert ref.startswith("#/"), f"Nonlocal reference: {ref}"
                target = schema
                for part in ref[2:].split("/"):
                    target = obj(target)[part.replace("~1", "/").replace("~0", "~")]
                count += 1
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return count


def check_output(case: Case, stdout: bytes, stderr: bytes, status: int) -> None:
    assert status == case.expected_exit, f"exit {status}, expected {case.expected_exit}"
    assert not stderr, f"Unexpected stderr: {stderr[:500]!r}"
    if "--help" in case.args:
        assert b"kast " in stdout and b"--help" in stdout
        return
    result = obj(decode(stdout))
    if case.expected_exit == 2:
        failure = "INVALID_ARGUMENTS"
        if case.name == "duplicate-fields":
            failure = "INVALID_COMMAND"
        elif (
            "-invalid-" not in case.name
            and "--request" in case.args
            and case.args[:2] == ("query", "plan")
        ):
            failure = "RUN_REQUIRED"
        assert result == {"type": "rejected", "failure": failure}
    elif case.args[0] == "describe":
        catalog = (
            case.args[case.args.index("--catalog") + 1] if "--catalog" in case.args else "complete"
        )
        command = case.args[1] if len(case.args) > 1 and not case.args[1].startswith("--") else None
        section = (
            case.args[case.args.index("--section") + 1]
            if "--section" in case.args
            else ("summary" if command else "inventory")
        )
        assert result["catalog"] == catalog.upper()
        assert (
            result["schema"] == "kast.cli.describe.v1" and result["public_contract_version"] == 18
        )
        assert result["section"] == section and result.get("command") == command
        if section == "inventory":
            assert {string(obj(v)["command"]) for v in array(result["content"])} == COMMANDS
        if command == "query.plan" and section == "output":
            schema = obj(result["content"])
            assert len(obj(schema["$defs"])) == 35 and recursive_refs(schema) == 316
    else:
        assert result["type"] == "planned"
        assert result["basis"] == "REQUEST_SHAPE_ONLY" and result["estimate"] == "NOT_MEASURED"
        assert isinstance(result["request"], dict)


def snapshot(root: Path) -> dict[str, str]:
    return {
        str(p.relative_to(root)): digest(p) if p.is_file() else "directory" for p in root.rglob("*")
    }


def run_case(case: Case, executable: Path, root: Path, output: Path) -> str | None:
    request = root / "request with spaces.json"
    payload = bytes.fromhex(case.input_hex)
    request.write_bytes(payload)
    args = [str(request) if v == "{request-file}" else v for v in case.args]
    stdin = b"" if "{request-file}" in case.args else payload
    command = ["/usr/bin/sandbox-exec", "-p", SANDBOX, str(executable), MODE, *args]
    env = {"HOME": str(root / "home"), "PATH": "/nonexistent", "LANG": "en_US.UTF-8"}
    before = snapshot(root)
    stem = output / case.name
    stem.with_suffix(stem.suffix + ".stdin").write_bytes(stdin)
    timed_out = False
    with (
        (output / f"{case.name}.stdout").open("wb") as out,
        (output / f"{case.name}.stderr").open("wb") as err,
    ):
        with subprocess.Popen(
            command, cwd=root, env=env, stdin=subprocess.PIPE, stdout=out, stderr=err
        ) as child:
            try:
                if case.open_stdin:
                    child.wait(timeout=20)
                else:
                    child.communicate(stdin, timeout=20)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
                timed_out = True
            finally:
                if child.stdin:
                    child.stdin.close()
            status = child.returncode
    unchanged = snapshot(root) == before and not list((root / "home").iterdir())
    (output / f"{case.name}.command.json").write_text(
        json.dumps(
            {
                "argv": command,
                "cwd": str(root),
                "environment": env,
                "expected_exit": case.expected_exit,
                "actual_exit": status,
                "stdin_held_open": case.open_stdin,
                "files_unchanged": unchanged,
                "timed_out": timed_out,
            },
            indent=2,
        )
        + "\n"
    )
    try:
        assert not timed_out, "timeout (including open-stdin dependency if applicable)"
        assert unchanged, "Filesystem state changed"
        check_output(
            case,
            (output / f"{case.name}.stdout").read_bytes(),
            (output / f"{case.name}.stderr").read_bytes(),
            status,
        )
    except (AssertionError, ValueError, KeyError) as error:
        return str(error)
    return None


def fields(path: Path) -> list[list[str]]:
    return [line.replace("\\t", "\t").split("\t") for line in path.read_text().splitlines()]


def resources(report: Path, output: Path) -> int:
    rows = [obj(v) for v in array(decode(report.read_text()))]
    inventory = fields(HERE / "expected-resource-inventory.tsv")
    assert len(inventory) == 37
    actual: list[str] = []
    for name, size, sha, original in inventory:
        matches = [row for row in rows if row["name"] == name]
        assert len(matches) == 1 and not matches[0].get("is_missing"), name
        entries = array(matches[0]["entries"])
        assert len(entries) == 1, name
        entry = obj(entries[0])
        origin = Path(unquote(urlparse(string(entry["origin"])).path))
        assert origin.name == Path(original).name, name
        assert "io.github.amichne.kast/query/reachability-metadata.json" in string(
            entry["registration_origin"]
        )
        with zipfile.ZipFile(origin) as jar:
            data = jar.read(name)
        assert len(data) == int(size) == entry["size"], name
        assert hashlib.sha256(data).hexdigest() == sha, name
        actual.append("\t".join((name, size, sha, str(origin))))
        if name == "kast-hosted-platform.properties":
            assert data == (HERE / "expected-kast-hosted-platform.properties").read_bytes()
            assert b"ideBuild=262.10315.125\n" in data
            assert b"kotlinPluginBuild=262.10315.125-IJ\n" in data
            (output / name).write_bytes(data)
    (output / "resource-inventory.tsv").write_text("\n".join(actual) + "\n")
    shutil.copyfile(report, output / "embedded-resources.json")
    return len(rows)


def validator_inputs(output: Path) -> None:
    for catalog in ("complete", "common"):
        schema = obj(decode((output / f"{catalog}-query.plan-output.stdout").read_bytes()))[
            "content"
        ]
        (output / f"{catalog}-plan.schema.json").write_text(json.dumps(schema))
        source = "flag-plan.stdout" if catalog == "complete" else "common-plan.stdout"
        valid = (output / source).read_bytes()
        wrong_basis = obj(decode(valid))
        wrong_basis["basis"] = "UNKNOWN_BASIS"
        (output / f"{catalog}-invalid-basis.json").write_text(json.dumps(wrong_basis))
        wrong_name = obj(decode(valid))
        obj(obj(obj(wrong_name["request"])["from"])["match"])["text"] = ""
        (output / f"{catalog}-invalid-nested-name.json").write_text(json.dumps(wrong_name))
    rows = fields(HERE / "expected-validator-cases.tsv")
    assert len(rows) == 99 and sum(row[1] == "invalid" for row in rows) == 4
    (output / "validator-cases.tsv").write_text(
        "\n".join(
            "\t".join((catalog, expected, str(output / Path(path).name)))
            for catalog, expected, path in rows
        )
        + "\n"
    )


def qualify(
    executable: Path,
    sha: str,
    report: Path,
    build_report: Path,
    java: Path,
    classpath: Path,
    output: Path,
) -> int:
    assert re.fullmatch(r"[0-9a-f]{64}", sha), "Supply authorized SHA256"
    assert digest(executable) == sha, "Artifact digest differs from authorization"
    assert not output.exists(), "Use a new output directory"
    assert java.is_file() and (classpath / "json-schema-validator-3.0.8.jar").is_file()
    cases = load_cases()
    output.mkdir(parents=True)
    (output / "identity.json").write_text(
        json.dumps(
            {
                "executable": str(executable),
                "executable_sha256": sha,
                "driver_sha256": digest(Path(__file__)),
                "lock_sha256": digest(HERE / "native-metadata-qualification.py.lock"),
                "cases_sha256": digest(HERE / "cases.json"),
                "resource_report_sha256": digest(report),
                "build_report_sha256": digest(build_report),
                "validator_source_sha256": digest(HERE / "MetadataSchemaCheck.java"),
                "networknt_jar_sha256": digest(classpath / "json-schema-validator-3.0.8.jar"),
            },
            indent=2,
        )
        + "\n"
    )
    failures: list[str] = []
    summary: dict[str, Json] = {
        "executable": str(executable),
        "sha256": sha,
        "bytes": executable.stat().st_size,
        "cases": 158,
    }
    with tempfile.TemporaryDirectory(prefix="kast-sha2-metadata-", dir="/private/tmp") as temporary:
        root = Path(temporary)
        (root / "home").mkdir()
        for case in cases:
            failure = run_case(case, executable, root, output)
            print(f"{case.name}\t{'FAIL ' + failure if failure else 'PASS'}", flush=True)
            if failure:
                failures.append(f"{case.name}: {failure}")
        summary["home_unchanged"] = not list((root / "home").iterdir())
    try:
        summary["resource_report_entries"] = resources(report, output)
        summary["owned_resources"] = 37
        shutil.copyfile(build_report, output / "kast-query-build-report.html")
        validator_inputs(output)
        command = [
            "/usr/bin/sandbox-exec",
            "-p",
            "(version 1)(allow default)(deny network*)",
            str(java),
            "-XX:-UsePerfData",
            "--class-path",
            str(classpath / "*"),
            str(HERE / "MetadataSchemaCheck.java"),
            str(output),
        ]
        result = subprocess.run(command, capture_output=True, timeout=120, check=False)
        (output / "networknt-validation.log").write_bytes(result.stdout + result.stderr)
        (output / "networknt-command.json").write_text(json.dumps(command, indent=2))
        assert result.returncode == 0 and b"NETWORKNT_VALIDATION_PASS=99" in result.stdout
        summary["networknt_controls"] = 99
    except (AssertionError, ValueError, KeyError, OSError, subprocess.TimeoutExpired) as error:
        failures.append(f"resource/validator: {error}")
    assert digest(executable) == sha, "Artifact changed during qualification"
    summary["failures"] = cast(list[Json], failures)
    summary["passed"] = 158 - sum(
        not failure.startswith("resource/validator:") for failure in failures
    )
    summary["network_and_file_writes_denied"] = True
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return 1 if failures else 0


def test_reconstruction() -> None:
    cases = load_cases()
    assert sum(case.open_stdin for case in cases) == 1
    assert sum("{request-file}" in case.args for case in cases) == 37
    assert len(fields(HERE / "expected-validator-cases.tsv")) == 99
    assert len(fields(HERE / "expected-resource-inventory.tsv")) == 37


def test_recursive_reference_resolution() -> None:
    assert recursive_refs({"$defs": {"node": {"$ref": "#/$defs/node"}}}) == 1
    import pytest

    with pytest.raises(KeyError):
        recursive_refs({"$ref": "#/$defs/missing"})
    with pytest.raises(AssertionError):
        recursive_refs({"$ref": "https://example.invalid/schema"})


def test_output_negative_controls() -> None:
    import pytest

    rejection = Case("empty-input", ("query", "--request", "-"), "", 2)
    good = b'{"type":"rejected","failure":"INVALID_ARGUMENTS"}'
    check_output(rejection, good, b"", 2)
    for stdout, stderr, status in [(good, b"", 0), (good, b"warning", 2), (b"{}", b"", 2)]:
        with pytest.raises((AssertionError, KeyError)):
            check_output(rejection, stdout, stderr, status)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-from", type=Path)
    parser.add_argument("--check-archive", type=Path)
    parser.add_argument("--check-tools", action="store_true")
    parser.add_argument("--format", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--executable", type=Path)
    parser.add_argument("--expected-sha256")
    parser.add_argument("--resource-report", type=Path)
    parser.add_argument("--build-report", type=Path)
    parser.add_argument("--java", type=Path)
    parser.add_argument("--classpath-dir", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.prepare_from:
        recover(args.prepare_from.resolve())
        return 0
    if args.check_archive:
        for case in load_cases():
            check_output(
                case,
                (args.check_archive / f"{case.name}.stdout").read_bytes(),
                (args.check_archive / f"{case.name}.stderr").read_bytes(),
                case.expected_exit,
            )
        print("ARCHIVED_OUTPUT_ASSERTIONS_PASS=158 (not a new executable run)")
        return 0
    if args.format:
        return subprocess.call([sys.executable, "-m", "ruff", "format", str(Path(__file__))])
    if args.check_tools:
        for tool_args in (
            ("ruff", "format", "--check", str(Path(__file__))),
            ("ruff", "check", str(Path(__file__))),
            ("pyright", "--project", str(HERE / "pyrightconfig.json")),
        ):
            result = subprocess.run([sys.executable, "-m", *tool_args], check=False)
            if result.returncode:
                return result.returncode
        return 0
    if args.self_test:
        import pytest

        return int(
            pytest.main([str(Path(__file__)), "-q", "-p", "no:cacheprovider", "-o", "addopts="])
        )
    if not all(
        (
            args.executable,
            args.expected_sha256,
            args.resource_report,
            args.build_report,
            args.java,
            args.classpath_dir,
            args.output,
        )
    ):
        parser.error(
            "Qualification requires explicit executable, authorized digest, reports, Java, classpath and new output"
        )
    return qualify(
        args.executable.resolve(),
        args.expected_sha256,
        args.resource_report.resolve(),
        args.build_report.resolve(),
        args.java.resolve(),
        args.classpath_dir.resolve(),
        args.output.resolve(),
    )


if __name__ == "__main__":
    raise SystemExit(main())
