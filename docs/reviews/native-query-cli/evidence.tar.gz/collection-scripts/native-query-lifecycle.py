# /// script
# requires-python = ">=3.13"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Qualify live native ownership and fail-closed rollback in one disposable installation."""

import hashlib
import json
import os
import signal
import subprocess
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
ROOT = Path("/private/tmp/knq-iwg1g7v8")
HOME = ROOT / "n"
INSTALLATION = HOME / ".local/share/kast/installation"
EVIDENCE = REPO / ".amp/in/artifacts/native-query/lifecycle"
ENVIRONMENT = {"PATH": os.environ["PATH"], "HOME": str(HOME), "USER": os.environ["USER"]}


def invoke(
    label: str, argv: list[str], environment: dict[str, str]
) -> subprocess.CompletedProcess[bytes]:
    (EVIDENCE / f"{label}.argv.txt").write_text(repr(argv) + "\n")
    result = subprocess.run(
        argv, env=environment, cwd=ROOT, capture_output=True, check=False, timeout=120
    )
    (EVIDENCE / f"{label}.stdout").write_bytes(result.stdout)
    (EVIDENCE / f"{label}.stderr").write_bytes(result.stderr)
    (EVIDENCE / f"{label}.exit").write_text(str(result.returncode) + "\n")
    return result


def main() -> None:
    EVIDENCE.mkdir()
    native = INSTALLATION / "bin/kast-query"
    before = hashlib.sha256(native.read_bytes()).hexdigest()
    command = [
        str(native),
        "query",
        "--workspace",
        "/private/tmp/kast-public-cli-v1-a3b5uat_/workspace",
        "--name",
        "OrderService",
    ]
    (EVIDENCE / "worker.argv.txt").write_text(repr(command) + "\n")
    with (
        (EVIDENCE / "worker.stdout").open("wb") as stdout,
        (EVIDENCE / "worker.stderr").open("wb") as stderr,
    ):
        child = subprocess.Popen(command, env=ENVIRONMENT, cwd=ROOT, stdout=stdout, stderr=stderr)
        try:
            records = INSTALLATION / "state/run/one-shot"
            deadline = time.monotonic() + 15
            owned = None
            while time.monotonic() < deadline and child.poll() is None:
                for path in records.glob("*.json"):
                    try:
                        raw = path.read_bytes()
                        record = json.loads(raw)
                    except (FileNotFoundError, json.JSONDecodeError):
                        continue
                    if record["pid"] == child.pid:
                        owned = raw
                        break
                if owned is not None:
                    break
            assert owned is not None, "No live native invocation record was observed"
            child.send_signal(signal.SIGSTOP)
            assert child.poll() is None
            (EVIDENCE / "worker-record.json").write_bytes(owned)
            stopped = invoke(
                "worker-state",
                ["/bin/ps", "-p", str(child.pid), "-o", "pid=,stat=,comm="],
                ENVIRONMENT,
            )
            assert b"T" in stopped.stdout.split()[1]
            public = str(HOME / ".local/bin/kast")
            status = invoke("live-status", [public, "status", "--json"], ENVIRONMENT)
            assert status.returncode == 0
            observation = json.loads(status.stdout)["oneShotRequestsInFlight"]
            assert observation["state"] == "VERIFIED" and observation["value"] == 1
            rollback_environment = ENVIRONMENT | {
                "KAST_VERSION": "0.0.0",
                "KAST_HOST_VERSION": "0.0.0",
                "KAST_INSTALL_ASSETS_DIRECTORY": str(ROOT / "assets"),
                "KAST_INSTALL_PROFILE": "persistent",
                "JAVA_TOOL_OPTIONS": f"-Duser.home={HOME}",
            }
            rollback = invoke(
                "rollback-live-worker",
                [
                    "/bin/bash",
                    str(REPO.with_name("kast.feature-native-query-baseline") / "install.sh"),
                    "--idea-home",
                    "/Users/amichne/Applications/IntelliJ IDEA.app/Contents",
                    "--skip-codex-plugin",
                    "--verbose",
                ],
                rollback_environment,
            )
            assert rollback.returncode != 0, "Rollback must not replace a live stopped worker"
            assert child.poll() is None
            assert hashlib.sha256(native.read_bytes()).hexdigest() == before
            retired = invoke("force-stop", [public, "stop", "--force", "--json"], ENVIRONMENT)
            assert child.wait(timeout=10) == -signal.SIGKILL
            # Client retirement is not host quiescence: the selected IDEA is still live.
            assert retired.returncode != 0
            assert b"HOST_RESTART_REQUIRED" in retired.stdout + retired.stderr
            assert hashlib.sha256(native.read_bytes()).hexdigest() == before
            final = invoke("retired-status", [public, "status", "--json"], ENVIRONMENT)
            observation = json.loads(final.stdout)["oneShotRequestsInFlight"]
            assert observation["state"] == "VERIFIED" and observation["value"] == 0
            print("PASS: live status, rollback refusal, exact native retirement")
            print("NOT RUN: restoration to Java-only owner; selected IDEA remains live")
        finally:
            if child.poll() is None:
                child.kill()
            child.wait(timeout=10)


if __name__ == "__main__":
    main()
