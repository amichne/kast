# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# ///
"""Bind the explicitly authorized final correctness config; no product execution."""
import importlib
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c
receipt_path = HERE.parent / "lifecycle/ready-host-receipt.json"
c.require(c.digest(receipt_path) == "7f5259a0da2bd0a7f29fab02b6c1f5217fae404781cd2325597eeab32abda541", "main authorized receipt digest")
ready = c.load(receipt_path)
identity_path = Path(ready["installationIdentities"])
identities = c.load(identity_path)
config = c.load(HERE.parent / "measurements/final-pending.json")
old_home = config["routes"]["native"]["environment"]["HOME"]
config["identities"] = {path: sha for path, sha in config["identities"].items() if not path.startswith(old_home + "/")}
for route, owner in (("native", "candidate"), ("baseline", "baseline")):
    installed = identities[owner]
    c.require(installed["rejected"] == [], "installation identity rejection")
    installation = Path(installed["installation"])
    selected = config["routes"][route]
    selected["command"] = str(Path(installed["home"]) / ".local/bin/kast")
    selected["manifest"] = str(installation / "installation.json")
    selected["payload"] = str(installation / "bin/kast-query")
    selected["environment"]["HOME"] = installed["home"]
    config["identities"].update(installed["identities"])
    manifest = c.load(installation / "installation.json")
    payloads = {entry["path"]: entry["sha256"].removeprefix("sha256:") for entry in manifest["payloadFiles"]}
    for relative in ("bin/kast-query-complete", "bin/kast-tool-rpc-complete", "share/kast/agent-tools/plugins/kast/skills/kast/scripts/server.py"):
        path = installation / relative
        c.require(c.digest(path) == payloads[relative], "manifest-owned wrapper/server identity")
        config["identities"][str(path)] = payloads[relative]
config["routes"]["baseline"]["environment"]["JAVA_TOOL_OPTIONS"] = "-Duser.home=" + ready["home"]
for key in ("live", "endpoint", "endpointExpected", "hostLog"):
    config[key] = ready[key]
config["identities"].update(identities["fixture"])
config["readyHostReceipt"] = str(receipt_path)
config["mcpPython"] = "/Users/amichne/.cache/uv/environments-v2/mcp-check-e7d60f50675c94de/bin/python3"
for path in (receipt_path, identity_path, Path(config["mcpPython"]), HERE / "acceptance.py", HERE / "mcp_check.py", HERE / "mcp_check.py.lock", HERE.parent / "measurements/collector.py"):
    config["identities"][str(path)] = c.digest(path)
config["status"] = "READY_MAIN_AUTHORIZED"
config["authorizationScope"] = "Final installed correctness and packaged stdio/RPC only. No pilot/cohort authorization. Main supplied pinned ready receipt."
config["externalLoadNotes"] = "Main confirms product gate completed and no builds running; correctness only."
output = HERE / "ready.json"
c.require(not output.exists(), "preserve any existing ready config")
a.preflight(config)
c.save(output, config)
print("PASS read-only fixture/identity preflight; wrote authorized correctness config " + str(output))
