# Issued-token RESUME investigation

**No concrete supported public producer of a successful query output RESUME was established. Do not manufacture a token from the owner tests.** This is source investigation, not a live negative proof. No live attempt was made.

## Exact owners and distinction

- `runtime/hosted/src/test/kotlin/io/github/amichne/kast/runtime/hosted/HostedQueryRetainedPresentationTest.kt:128–143` manually constructs a detached page and supplies a retention callback. Its `retainedOutput()` at lines 377–378 returns a literal zero-UUID token; this does not create live hosted authority. The row/evidence fitting tests prove presentation rules, not a public token producer.
- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/HostedCanonicalQuery.kt:113–139` uses the production continuation service and `CanonicalQueryProtocol.execute`, then fits through `HostedQueryPublicationSession` (lines 143–162).
- `query/protocol/src/main/kotlin/io/github/amichne/kast/query/protocol/CanonicalQueryProtocol.kt:33–39` rejects external pipeline continuation RESUME. Lines 117–120 still route an **issued output** continuation to `executeOutput`; acceptance of that variant does not establish a reachable public producer.
- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/HostedQueryResponse.kt:97–118` sends oversized retained automatic pages to ordinary automatic presentation, rather than output-continuation issuance. `QueryPageEncoding.retainPrefix` (lines 182–214) is the real output-token issuance branch, but its presence alone is not reachability proof.
- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/HostedSymbolInvocationPolicy.kt:22–48` limits preview rows/bytes using the same admitted execution grant. Lines 52–65 measure the full wire envelope before admitting inline presentation; an oversized inline result requires retention.
- `query/protocol/src/main/kotlin/io/github/amichne/kast/query/protocol/QueryInvocationProjection.kt:131–140` falls back from inline to retained presentation; lines 237–238 attach invocation/evidence-window metadata, and lines 245–250 retain when row/evidence/byte preview limits require it. These facts explain why reducing rows/bytes on the existing public fixture produces retained result cursors, not an output RESUME.
- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/HostedQueryPublicationSession.kt:86–107` calls the real store's `issueOutput` under a prepared publication claim. Directly invoking this owner or injecting a claim would bypass the requested public producer and is outside this task.

Existing raw attempts corroborate only the attempted inputs: `../../semantic-acceptance/output-continuation-native.stdout` is complete, has three accumulated rows with one-row preview, a retained `result:v1:` reference and `next_cursor: 1`; it has no issued output continuation. `bounded-output-native.stdout` is another retained presentation case. Reusing those old tokens after host retirement is invalid.

## Safe live follow-up, if a supported producer is identified

Keep this outside the latency cohort. First capture the actual successful producer stdout, exit, process-reaping receipt, full host/basis and log joins. Require its real qualified checkpoint to identify an output continuation and RESUME next action. Then pass **those exact issued bytes**, not a guessed UUID or a result reference:

```sh
"$NATIVE_HOME/.local/bin/kast" result resume \
  --catalog complete --workspace "$WORKSPACE" \
  --continuation "$ACTUALLY_ISSUED_OUTPUT_CONTINUATION"
```

The production consumer exists, but a reachable producer command remains the material blocker. Do not call an unissued-token rejection a successful RESUME, and do not substitute the internal `executeQueryPage` tests for the public `execute` path. Main should either supply a documented supported producer or retain successful issued-token RESUME as NOT RUN with this source evidence. No recommendation to change production semantics is implied.
