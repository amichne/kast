# Native query CLI evidence

The native-query replacement is not product-qualified. The assembled archive exceeds the unchanged size limits.
The unchanged installer nevertheless admitted it in a disposable home. Installation acceptance and product qualification are separate results.
This report does not grant release or replacement authority.
It follows the October 30, 2026 native-query specification, AC01–AC17.
Every criterion began as NOT RUN. Partial checks do not pass a complete criterion.

## Source and isolation

- Requested examined baseline: `96e4c4bb3d1b9185869e4f0c73e9f3d7c95bfb6a`.
- Refreshed baseline: `1e3a654d3ea4f160d603a37e5c574d5470c9a543`.
- Task checkout: `/Users/amichne/code/kast.feature-native-query-cli`, branch `feature/native-query-cli`.
- Pristine comparison checkout: `/Users/amichne/code/kast.feature-native-query-baseline`.
- Candidate HEAD is the refreshed baseline plus uncommitted changes; no candidate commit exists.
- Existing changes in `/Users/amichne/code/kast` were preserved.
- Local evidence: `.amp/in/artifacts/native-query/` in the task checkout.
- Portable raw evidence: [evidence.tar.gz](native-query-cli/evidence.tar.gz), with source snapshots and per-file SHA-256 inventory.
- No release, push, personal installation replacement, or personal IDEA restart occurred.

The baseline checkout built numeric version `0.0.0`. The public installer admitted it in `/private/tmp/knq-iwg1g7v8/b`.
The native candidate home is `/private/tmp/knq-iwg1g7v8/n`.
An owned IDEA process uses that home, separate config/system/log paths, and the baseline installation's plugin directory.
The real baseline declaration and caller requests succeeded against that isolated host.
These baseline results do not prove candidate behavior.

## Acceptance record

PASS requires every assertion at the criterion's stated scope.
FAIL identifies an executed contradiction. NOT RUN identifies missing complete evidence, even when supporting checks passed.
SKIP identifies a deliberately disabled suite; it supplies no behavioral pass.

| Criterion | Result | Evidence and remaining scope |
| --- | --- | --- |
| AC01 | PASS | Exact macOS arm64 archive payload matches its native producer. No fallback is enabled. Executed artifact tests reject substituted bytes and a matching script producer. Linux execution remains NOT RUN. |
| AC02 | NOT RUN | The enforced execution policy proves zero client JVM launches for 22 installed calls, with an absolute-JBR control. Successful issued-token RESUME remains untested, so the complete command scope is not passed. |
| AC03 | PASS | Public parser, encoded-contract and catalog tests passed. Actual native file/stdin plans, defaults and local rejection controls passed. |
| AC04 | FAIL | Local native composition passed, but `describe query.plan --section output` throws StackOverflowError in both catalogs. The pristine JVM baseline reproduces it. |
| AC05 | PASS | Installed native semantic calls and live invocation records passed. Shared-context tests cover marker/fence, foreign/detached/replaced payload and explicit configuration cases. Native peer fixtures use paths with spaces and unrelated working directories. |
| AC06 | PASS | Actual native peers reject wrong host/root, incompatible platform, replaced socket incarnation, malformed JSON, duplicate keys and trailing documents. An admitted host rejection preserves input exit 2; protocol controls preserve exit 6, one document and record cleanup. |
| AC07 | FAIL | Native output/exit tests and ordinary pagination pass. Both baseline and candidate classify an explicit 1 ms CALLER_TIMEOUT as protocol exit 6, not elapsed exit 124. This is inherited, not a native-only regression. |
| AC08 | PASS | Real IDEA declaration/caller parity, exact ranges, fields, coverage and completion passed. Absent-name, wrong-target and seven comparator mutation controls passed. |
| AC09 | NOT RUN | Thirty retained reads and ten source checks passed in separate processes, preserving exact issued tokens and row/evidence cursors. Successful issued-token RESUME remains unverified. |
| AC10 | PASS | Both signals passed at sampled incomplete-input and admitted active-socket states, with exact child reaping, socket closure and no replay. |
| AC11 | PASS | Native sampled blocked writes stop before consumer drain. Broken stdout selects exit 5. Exact output-prefix and terminal-order checks passed. |
| AC12 | NOT RUN | Pure ownership controls and actual live native status pass. The first stop/rollback pilot failed before retirement; complete mixed-version restoration remains unqualified. |
| AC13 | PASS | Existing queue, connection, executor, backpressure and read-accounting checks passed. Active ownership survives cancellation until the controlled analysis callback drains. |
| AC14 | PASS | CLI MCP/RPC contracts, 43 task-service/transport tests and an actual installed stdio session with its packaged JVM RPC child passed. |
| AC15 | FAIL | Final restored archive: 78,156,716 compressed bytes and 156,038,791 payload bytes. Limits remain 67,108,864 and 134,217,728 bytes. The earlier installed build also fails both limits. |
| AC16 | NOT RUN | Protocol frozen before collection; no qualified paired cohort collected. |
| AC17 | FAIL | Focused checks pass; the enforced archive gate fails. Source wrapper admission rejects the uncommitted tree. The underlying sourceValidationGate passed in the product run, with semantic fixture suites disabled. |

## Independent semantic oracle

The saved source remains [OrderService.fixture.txt](public-cli-v1/OrderService.fixture.txt).
Its SHA-256 is `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`.
The workspace is `/private/tmp/kast-public-cli-v1-a3b5uat_/workspace`.

| Expected declaration or occurrence | UTF-16 range, end-exclusive |
| --- | --- |
| `example.OrderService` | [17,94) |
| `example.OrderService.submitOrder` | [42,92) |
| `example.placeOrder` | [96,174) |
| `submitOrder` call in `placeOrder` | [152,163) |

The caller oracle expects exactly `example.placeOrder → example.OrderService.submitOrder`.
Its direction is `SOURCE_TO_TARGET`, provenance is `k2-authored-source`, and coverage is `exact-compiler-confirmed`.
Absent-name and wrong-target controls must reject broader or incorrect answers.
Fresh allocation normalization permits only row IDs and consistently linked result references.
Host, workspace, basis, source, fields, coverage, and completion are never removed to get equality.
Retained reads must preserve their producer's token bytes.

The installed baseline and native clients passed these semantic assertions against the same ready IDEA host.
The final verifier checked 62 recorded calls: 58 exited 0, two expected unissued-token rejections exited 10, and two shared timeout cases exited 6.
Seven comparator mutations changed range, coverage, host, selected fields, target, graph links, or completion model; every mutation rejected equivalence.
All accepted results retained host `a37aac46-4b61-4426-830a-8e9186f8d464`, epoch 2, `SAVED_PSI_COMMITTED`, version 1.

Thirty separate-process retained reads used unchanged native-issued and baseline-issued tokens.
Three row pages preserved all three exact declarations. Evidence pages advanced [0,1) then [1,2), with zero rows in the final evidence page.
Ten source cases preserved exact saved text, ranges, line numbers and independently calculated UTF-16 digests.
Every retained receipt reported RETENTION with zero entered native calls/searches, declaration visits, discovery pages and relation pages.
Producer controls entered K2 and published discovery pages.
Host logs lack an inner READ_RESULT label and a connection-ID/read-ID join; each serialized captured interval contains exactly one semantic receipt.
This supports no producer replay at the instrumented owner, without inventing the missing join.

Successful RESUME remains NOT RUN. The attempted producers issued retained references/cursors or deferred detail, not output continuations.
The unissued-token control returned `continuation-unavailable`, exit 10, in both clients; no issued capability was fabricated.
The explicit 1 ms probe instead returned `BUDGET_EXCEEDED / CALLER_TIMEOUT / REQUEST_ADMISSION` with exit 6 in both clients.
Its envelope lacks the fields expected by the operation decoder in [PublicShellExit](../../cli/src/main/kotlin/io/github/amichne/kast/cli/publicshell/PublicShellExit.kt).
The serialization-error path selects PROTOCOL. The shared defect was recorded, not changed by this implementation.

## Measurement contract

The frozen collection decision is `.amp/in/artifacts/native-query/collection-decision.md`.
It specifies one warm-up per route and workload, then 30 alternating pairs each for metadata, plans, discovery, callers, and retained reads.
Retained reads run before other cohorts can evict their pre-existing result.
All started samples, including failures, must remain in the record.
Only size-qualified installed artifacts qualify for the paired cohort.
No timing, speedup, or removed-startup-cost claim is made without that evidence.
The enforced zero-JVM result is separate from latency measurement and limited to the executed routes.
Process duration minus hosted time is not JVM startup time.

## Baseline commands and observations

Commands ran from the task checkout unless a different directory is stated.

```sh
mise exec -- ./gradlew :cli:test --tests 'io.github.amichne.kast.cli.publicshell.*' :distribution:cli:test --console=plain
mise exec -- ./gradlew assembleKastControlDist :publicLauncherTest --console=plain
```

Both baseline commands passed. The second used the historical JVM query child; it is not native-query evidence.
The pristine baseline checkout then ran:

```sh
mise exec -- ./gradlew -Pversion=0.0.0 assembleKastControlDist generateHostReleaseRecord \
  -PhostedIdeaHome='/Users/amichne/Applications/IntelliJ IDEA.app/Contents' --console=plain
```

That command passed. The numeric baseline archive contains 55,281,121 bytes.
The installer reported 15,520 payload files and 92,697,162 payload bytes.
Fixture setup and owned IDEA launch used locked, dependency-free uv scripts under `.amp/in/`.
The setup record preserves the exact installer argv and isolated homes.

The valid public command places options after the namespace and spells the catalog `complete`.
An initial pilot with options before `query` rejected with exit 2. Its raw output remains in the evidence directory.
The corrected command was:

```sh
env -i PATH=/usr/bin:/bin:/opt/homebrew/bin HOME=/private/tmp/knq-iwg1g7v8/b \
  JAVA_TOOL_OPTIONS=-Duser.home=/private/tmp/knq-iwg1g7v8/n \
  /private/tmp/knq-iwg1g7v8/b/.local/bin/kast query \
  --workspace /private/tmp/kast-public-cli-v1-a3b5uat_/workspace --catalog complete \
  --request /Users/amichne/code/kast.feature-native-query-cli/docs/reviews/public-cli-v1/query.json
```

It returned exit 0 and one `example.OrderService` row at [17,94), with exhaustive coverage and the selected fields.
The host identity was `a37aac46-4b61-4426-830a-8e9186f8d464`, epoch 1, saved committed content, version 1.
The owned IDEA PID was 88083. Client exit alone does not establish host settlement.

## Native artifact and resource evidence

The installed query is an arm64 Mach-O executable with `cffaedfe` magic and 63,354,440 bytes.
Its SHA-256 is `70d3cbbe07bc3955fbd23414e02c2d40c6cd3de3a57ca2b6afda43d44e8d23f8`.
The archive used for installation had one `bin/kast-query` entry matching that producer and installed payload.
The installed public dispatcher digest is `a38acfc6577c186afed92f9f8056eca54c1cc721d80851d341e902be7f3d0cc1`.
The selected wrapper digest is `1468f1b0c19cae43bba5faf9699ec17579a1f8f2110bb84ba3ee9021acdc7bb1`.
The installer generated manifest digest is `f210b6431c1c142eecfb6639c98bc81f512ac566066dffdd959b2757a0a912a7`.

Rebuilding after the reverted size experiments produced different executable bytes; the disposable installation was not replaced.
The final numeric archive identities are distinct from the installed semantic evidence:

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `kast-control-v0.0.0-macos-aarch64.tar.gz` | 78,156,716 | `7986331ae3b429fe486582ee1ee574d9f36d32b6911c20c4e4dea367be0f7744` |
| Management `kast` | 37,176,968 | `101bf586f35b9b56f977cf2a659fc4942077bcb196b191767882f9f010fbbf0a` |
| Query `kast-query` | 63,354,440 | `6b07cfc96a9b97f91b86649f475c9f2fedd7c0e99fa30e545d8795187ba379d8` |

Both archived executables match their final producers exactly.
The artifact substitution test ran one case with two assertions: changed bytes reject, and a script matching its producer also rejects.
The final artifact is not a repeat of the installed semantic acceptance; equal source policy does not make executable digests equal.

The product wrapper subsequently selected published version `0.50.2` for a local build; it did not publish that build.
That archive contains 78,157,612 compressed bytes and 156,038,859 regular-file payload bytes, with 15,658 total entries and 15,520 files.
Its archive SHA-256 is `61db47642335b45cabfdd960d7f8260862dc04174dca57f94df634eeba76a737`.
The query digest is `dbad8a16ef638392f5eebc7bd68164cae0977819a80af927fbd0d7949c35ec36`;
the management digest is `1faa38adeddc886a0f25f6cab13f0574b268d6e0afc26053be138ee33426aa88`.
The archived query matches its producer. The final expanded native-peer check used this query, not the installed semantic-test payload.

Oracle GraalVM 25.0.2+10.1 built the image with Java 25, `--no-fallback`, exact reachability metadata and `-Os`.
The build configuration also sets `fallback=false`. Neither launcher selects a JVM fallback.
The resource inventory verified 37 owned resources, including all public contracts/examples and the processed compatibility properties.
The complete embedded inventory contains 263 resources and no `.class` resources.
The properties contain `ideBuild=262.10315.125` and `kotlinPluginBuild=262.10315.125-IJ`, not template placeholders.

The first native runs exposed specific `Logback` registration failures. The final metadata covers the actual logging configuration and its methods.
Only the broken upstream Logback-classic metadata module is excluded; NetworkNT and Jackson validation remain enabled.
The 158-case local matrix used `-XX:MissingRegistrationReportingMode=Exit` and recorded no missing-registration exit in its final run.
Its two stack-overflow cases remain failures. A third initial negative oracle incorrectly assumed COMMON disallowed TRACE.
The corrected control uses `--max-elapsed-ms 9`: COMMON rejects with exit 2; COMPLETE accepts.
Eight representative baseline/native controls have byte-identical stdout and matching exits.

## Focused checks and scope

The following checks executed against the changed checkout:

| Check | Executed cases | Result |
| --- | ---: | --- |
| Complete CLI JVM suite | 552 | PASS, no skips |
| Complete management JVM suite | 281 | PASS, no skips |
| JVM Unix-socket deadline suite, now `:cli:udsTest` | 3 | PASS, no skips |
| Hosted queue/connection/retention owners | 21 | PASS, no skips |
| Hosted executor/backpressure/read accounting | 19 | PASS, no skips |
| Retained-row admission | 10 | PASS, no skips |
| Actual native launcher/output composition | 7 | PASS, no skips |
| Python task-service and transport | 43 | PASS |
| Source-gate consumer tests | 13 | PASS |
| Artifact substitution and script rejection | 1 | PASS, no skips |

`verifyJsonContracts`, `verifyVerificationGraph`, `verifyKastArchitecture` and `verifyKnowledgeBase` passed.
Both changed modules' `Detekt` checks passed after the installation admission was split by manifest and payload ownership.
The consumer graph was regenerated by `generateVerificationGraph`; its three changed hashes were copied through the documented owner workflow.
GraalVM's plugin reserves `nativeTest` even with test support disabled. The former JVM UDS suite therefore uses `udsTest`, including its check and CI consumers.

The first native pipe run failed its sampling precondition, not an observed cancellation assertion.
macOS exposed the worker as `st-public-query`, the last 15 characters of its name.
The corrected oracle requires that exact thread header and a kernel read/write frame. Both signal cases then passed.
No sleep or live-process observation substitutes for the pipe precondition.

The native peer tests use actual candidate bytes, production framing and response admission in a private installation with spaces.
Their test wrapper is not evidence for the production installation wrapper. The separate actual installation supplies that boundary.
The final eight peer cases cover wrong host/root, platform incompatibility, socket replacement, malformed JSON, duplicate keys, trailing data and an admitted host rejection.
The replacement peer moves the original socket inode before publishing its DESCRIBE reply, then binds a new listener at the selected path.
It asserts no operation or replay reaches either listener; an elapsed sleep is not the replacement precondition.
They do not establish compiler semantics.

The installed MCP check initializes the packaged Python stdio task service and calls its `find` task through `bin/kast-tool-rpc-complete`.
It asserts one complete `OrderService` result, range [17,94), and the exact ready host identity.
The unchanged JVM route remains intentionally JVM-based. Its launch is not part of the zero-query-JVM claim.

## Build and artifact costs

| Observation | Raw value | Interpretation |
| --- | ---: | --- |
| Initial query image without `-Os` | 96.55 MB | Build report, not installed archive size |
| Qualified resource build query image | 63,354,424 bytes | Earlier build05 digest retained in raw evidence |
| Build05 native compilation | 113 seconds | Native compiler report |
| Build05 whole command | 122.45 seconds | External timing |
| Build05 peak RSS | 3.42 GB | Native build process report |
| Final context-refactor native compilation | 73 seconds | Compiler report; image 63,354,440 bytes |
| Final context-refactor peak RSS | 3.79 GB | Build process, not query execution RSS |
| Baseline numeric archive | 55,281,121 bytes | Actual compressed artifact |
| Installed native candidate archive | 78,156,401 bytes | Actual compressed artifact |
| Baseline payload | 92,697,162 bytes | Installer accounting |
| Native candidate payload | 156,038,791 bytes | Installer accounting |
| Payload regular files, both products | 15,520 | Below the 16,384 entry gate |

There is one native query payload and one management payload. Archive hashing found no duplicate files larger than 10 KB.
All embedded query resources total only 1,752,327 bytes. Removing necessary resources cannot close the installed-size deficit.
Compressing again with `gzip` level 9 saved about 300 KB; it cannot close the compressed-size deficit.
The required JVM libraries remain for MCP/RPC and private operations.

No qualified paired measurement cohort has started: sample count is zero for each frozen workload.
Median, empirical p95, range, paired differences, client CPU and peak RSS are unavailable, not zero.
The installer did not enforce the separate product size gate. Its success does not admit this artifact to the frozen cohort.

Two bounded size experiments also failed the product limits. Neither experiment is part of the final source change.
Management `-Os` reduced the archive to 73,575,834 bytes.
Excluding `kotlin-reflect` from the native query classpath reduced it further to 71,099,830 bytes and 139,102,279 installed bytes.
The combined experiment still exceeded the compressed limit by 3,990,966 bytes and the installed limit by 4,884,551 bytes.
Its query image was 56,883,192 bytes. The JVM libraries stayed unchanged.
All seven native process tests and 156 local matrix cases passed; the two inherited metadata failures remained.
All 37 owned resources kept their exact size and digest. No missing-registration exit occurred.
Both experimental changes were removed. This result does not prove that every possible size reduction has been exhausted.
The restored policy exceeds the compressed limit by 11,047,852 bytes and the installed limit by 21,821,063 bytes.

## Implementation boundaries

`InstalledClientContext` admits the runtime payload, canonical installation, manifest-owned payload digest, and selected configuration.
The direct session and invocation recorder keep that same context. Metadata and request planning stay outside its construction.
The query wrapper omits Java selection. MCP, RPC, and private service wrappers keep it.
Ordinary status and retirement share manifest-qualified JVM/native process admission, with PID/start identity and executable revalidation.
Force reset retains its existing authority.

The public entry selects runtime `HOME`, matching the native dispatcher.
GraalVM's POSIX `user.home` derives from the operating-system account, not `HOME`; the diagnostic control confirmed this difference.
Private JVM entries keep their existing system-property selection.
This prevents a disposable public installation from selecting the personal host merely because the native runtime ignores `JAVA_TOOL_OPTIONS`.

| Invariant | Source owner |
| --- | --- |
| One admitted runtime installation | [InstalledClientContext](../../cli/src/main/kotlin/io/github/amichne/kast/cli/direct/InstalledClientContext.kt) |
| Shared context in session and recorder | [KastDirectToolSession](../../cli/src/main/kotlin/io/github/amichne/kast/cli/direct/KastDirectToolSession.kt), [OneShotInvocationRecord](../../cli/src/main/kotlin/io/github/amichne/kast/cli/rpc/OneShotInvocationRecord.kt) |
| Query-only Java environment removal | [InstallationWorkflow](../../cli/src/main/kotlin/io/github/amichne/kast/cli/installation/InstallationWorkflow.kt) |
| Exact native and JVM worker ownership | [LifecycleProcesses](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/LifecycleProcesses.kt) |
| Shared status and retirement admission | [OneShotObservation](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/OneShotObservation.kt), [InstallationRequestRetirement](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/InstallationRequestRetirement.kt) |
| Sole native producer | [CLI build](../../cli/build.gradle.kts), [root assembly](../../build.gradle.kts) |
| Artifact identity and unchanged limits | [VerifyDistributionTasks](../../build-logic/src/main/kotlin/support/tasks/verification/VerifyDistributionTasks.kt) |

## Lifecycle qualification stopped before retirement

The live native pilot observed worker PID 93334 and its recorded start identity, then stopped that owned child with SIGSTOP.
Installed `status --json` reported `oneShotRequestsInFlight` as VERIFIED with value 1.
Rollback through the baseline installer rejected `PRIOR_ADMISSION_EXIT_REJECTED`, with underlying `REGISTRY_REJECTED`.
The installed native payload stayed unchanged and the worker remained live.
Public `stop --force --json` then failed at `COORDINATOR / CHILD_REJECTED`; its private service child exited 64 before request retirement.
The harness killed and reaped its own stopped child in cleanup. That cleanup is not product retirement evidence.

The follow-up preserved these failures and tested the exact IDEA JBR in both disposable homes.
Setting `HOME` and `JAVA_HOME` alone still produced `user.home=/Users/amichne`.
Explicit `-Duser.home=<disposable-home>` selected the isolated home.
The private installed service owner, invoked with that property through `JAVA_OPTS`, disabled the isolated candidate coordinator and returned exit 0.
Later private status reported lifecycle absent; baseline disable/status also exited 0, but its coordinator was already absent.
Both public status observations reported zero in-flight requests after harness cleanup.

This does not qualify public shutdown. [InstallationLifecycle](../../distribution/cli/src/main/kotlin/io/github/amichne/kast/distribution/cli/InstallationLifecycle.kt)
filters the child environment to PATH, JAVA_HOME, CODEX_EXECUTABLE and TMPDIR, then sets HOME and configuration.
It does not forward the explicit JVM-home options, and it disables the coordinator before retiring requests.
[KastServiceMain](../../cli/src/main/kotlin/io/github/amichne/kast/cli/KastServiceMain.kt) still selects `System.getProperty("user.home")`.
Missing JAVA_HOME is not established as the original failure's cause: the successful private diagnostic changed both runtime and home selection.
The public child executor discarded its child's stdout/stderr, so the original service rejection is not recoverable from that pilot.

Host retirement also rejects while any process uses the selected IDEA executable.
The disposable and personal IDEA processes share that executable; stopping the disposable process cannot establish quiescence for mixed-version restoration.
No personal process was stopped to force acceptance. Both disposable shutdown fences and installation payloads were preserved.
AC12 therefore remains NOT RUN at its complete scope. Exact controls, environments and identity checks are in `lifecycle/` and `lifecycle-jbr/`.
After verification, the owned IDEA launcher terminated and reaped PID 88083 with exit 143 through its explicit stop marker.
Personal IDEA PID 12733 remained alive. This fixture cleanup supplies no new host-settlement or rollback assertion.

## Evidence limits

Apple `eslogger` is present but cannot create an Endpoint Security client under the available unprivileged account.
`sudo` requires credentials that were not available. Full Disk Access is unverified.
The available `sandbox-exec` utility is deprecated, but its execution policy passed allowed and denied controls on this macOS host.
The exact allowlist permits only the installed dispatcher, wrapper, query payload, system shells and `dirname`.
An allowed shell cannot launch the selected absolute-path JBR: the kernel rejects that child with `Operation not permitted`.
That same JBR reports Java 25.0.4 and exits 0 outside the policy.
Twenty-two installed calls ran under the policy, including declarations, callers, retained reads, source reads, pagination and bounded output.
The negative RESUME control also ran under it; successful issued-token RESUME did not.
This proves the enforced execution restriction for those calls; it is not an execution-event count or a claim about future macOS versions.
Missing Java on PATH, missing startup notices, and process snapshots cannot establish AC02.

Linux IDEA acceptance has not run. macOS evidence does not qualify another release target.
Native peer replies prove only the exercised admission, framing, cancellation, and output behavior.
They do not supply compiler-backed parity, retained-state continuity, or host-settlement evidence.

## Exact integration commands

The raw logs preserve command output and JUnit XML. These commands used the task checkout and numeric version unless stated otherwise.

```sh
mise exec -- ./gradlew -Pversion=0.0.0 :cli:spotlessApply :cli:detekt :distribution:cli:detekt \
  :cli:test --tests '*InstalledClientContextTest' :publicLauncherTest generateVerificationGraph \
  --continue --console=plain

mise exec -- ./gradlew -Pversion=0.0.0 :cli:test :cli:udsTest :distribution:cli:test \
  :runtime:hosted:test --tests '*HostedQueuedConnectionCancellationTest' \
  --tests '*HostedConnectionAdmissionTest' --tests '*HostedQueryRetainedPresentationTest' \
  --tests '*HostedContinuationOwnerRetentionTest' --tests '*HostedCompletionRejectionPublicationTest' \
  :workspace:intellij-read:test --tests '*HostedQueryExecutorTest' \
  --tests '*HostedQueryBackpressureTest' --tests '*HostedReadActionAccountingTest' \
  :query:protocol:test --tests '*QueryRetainedRowAdmissionTest' \
  verifyJsonContracts verifyVerificationGraph verifyKastArchitecture knowledgeImpact verifyKnowledgeBase \
  verifyKastControlDistLayout --continue --console=plain

mise exec -- python3 -m unittest discover -s .github/scripts/ci -p 'test_source_validation.py'
mise exec -- uv run --project packaging/task-access --locked pytest \
  packaging/task-access/test_service.py packaging/task-access/test_transport.py \
  --junitxml=.amp/in/artifacts/native-query/task-access-tests.xml
mise exec -- uv run --locked --script .amp/in/native-query-install.py
mise exec -- uv run --locked --script .amp/in/native-query-mcp.py
mise exec -- python3 .github/scripts/ci/source_validation.py
```

The first command passed. The second failed only the archive-size assertion; its selected tests and other guards passed.
The source wrapper rejected the dirty tree before running the complete source gate. This is a source-admission failure, not a test failure.
The scratch installer and MCP scripts preserve their exact child argv and environment selections in raw evidence.
The artifact-collector pilot initially expected an archive directory prefix; inspection showed the exact path is `bin/kast-query`.
That pilot failed before installation. The corrected collector asserts one entry, native magic and exact producer digest before invoking the unchanged installer.

The execution-policy controls used:

```sh
'/Users/amichne/Applications/IntelliJ IDEA.app/Contents/jbr/Contents/Home/bin/java' -version
/usr/bin/sandbox-exec -f .amp/in/artifacts/native-query/installed-native-exec.sb \
  /bin/bash -c 'exec "$1" -version' jvm-descendant-control \
  '/Users/amichne/Applications/IntelliJ IDEA.app/Contents/jbr/Contents/Home/bin/java'
```

The first exited 0. The restricted descendant exited 1 with `Operation not permitted`.
The policy digest is `b91801a2749f5c26971e10ed6c185dfbfd3e40e430c5ccf2984eb06806bca47f`.
The evidence also records every allowlisted executable digest.

Final integration commands were:

```sh
mise exec -- ./gradlew -p build-logic test --tests '*VerifyControlDistributionTaskTest' --console=plain
mise exec -- uv run --project docs/tooling --locked python docs/tooling/okf_public.py --write
mise exec -- python3 distribution/release/run_product_gate.py
mise exec -- ./gradlew -Pversion=0.50.2 :cli:spotlessApply :publicLauncherTest \
  --tests '*native endpoint response admission*' generateVerificationGraph --console=plain
cp build/reports/ci/verification-graph.json config/ci/verification-graph.json
mise exec -- uv run --project docs/tooling --locked python docs/tooling/okf_public.py --write
mise exec -- python3 distribution/release/run_product_gate.py
```

The artifact substitution case and expanded eight-case native-peer loop passed.
Generated files changed only through their owners. Public knowledge provenance retained CHANGED/NOT_ASSESSED rather than inventing refreshed claims.
The first product-wrapper attempt failed public provenance drift; its log remains `product-gate.log`.
After regeneration, the wrapper passed in 6m 45s (`product-gate-final.log`), including `sourceValidationGate`, `installedProductTest` and native process tests.
That task graph omitted `verifyKastControlDistLayout`, despite the oversized archive. This was not product qualification.
The final wiring adds that existing verifier to `productBuildGate`; `product-gate-enforced.log` records its size rejection.
No size limit changed. The gate now also requires the native payload identity and format checks in that verifier.

The product run reported semantic fixture suites SKIP because `KAST_SEMANTIC_FIXTURES` was unset.
Three opt-in installed Codex checks also skipped: `CodexProtocolQualifierTest`, `ManagedCodexUpstreamTest`, and `NativeCatalogAdmissionTest`.
Their omissions supply no semantic or adapter pass. The independent live IDEA run and actual installed stdio task service supply only their stated cases.
The build's Kotlin configuration-error tasks were skipped by their normal empty-error condition; that is distinct from disabled behavioral tests.

The evidence archive excludes product binaries, large HTML compiler reports and Python bytecode caches.
It retains raw build/measurement logs, resource inventories, all recorded semantic calls, execution policy and controls, lifecycle failures, JUnit XML and collection scripts.
`source-snapshot/` binds the uncommitted implementation to HEAD, exact source bytes, their digests and the tracked diff.
HTML compiler reports and product archives remain in the local artifact directory or Gradle outputs; their identities are recorded above.
