# /// script
# requires-python = ">=3.13"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Measure actual candidate bytes, then exercise the unchanged disposable installer."""

import hashlib
import json
import os
import shutil
import subprocess
import tarfile
from dataclasses import asdict, dataclass
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
EVIDENCE = REPO / ".amp/in/artifacts/native-query"
ROOT = Path("/private/tmp/knq-iwg1g7v8")


@dataclass(frozen=True)
class Artifact:
    archive: str
    archive_sha256: str
    archive_bytes: int
    archive_regular_files: int
    archive_regular_bytes: int
    query_entry: str
    query_bytes: int
    query_sha256: str
    query_magic: str
    producer_sha256: str
    archive_limit: int = 64 * 1024 * 1024
    installed_limit: int = 128 * 1024 * 1024
    entry_limit: int = 16384


@dataclass(frozen=True)
class Installation:
    command: list[str]
    environment: dict[str, str]
    working_directory: str
    exit: int


def digest(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def main() -> None:
    archive = REPO / "build/distributions/kast-control-v0.0.0-macos-aarch64.tar.gz"
    with tarfile.open(archive) as packed:
        members = packed.getmembers()
        selected = [item for item in members if item.name == "bin/kast-query"]
        assert len(selected) == 1, "The archive must select exactly one query payload"
        entry = selected[0]
        stream = packed.extractfile(entry)
        assert stream is not None and entry.isfile()
        with stream:
            query = stream.read()
        artifact = Artifact(
            str(archive),
            digest(archive),
            archive.stat().st_size,
            sum(item.isfile() for item in members),
            sum(item.size for item in members if item.isfile()),
            entry.name,
            len(query),
            hashlib.sha256(query).hexdigest(),
            query[:4].hex(),
            digest(REPO / "cli/build/native/nativeCompile/kast-query"),
        )
    assert artifact.query_sha256 == artifact.producer_sha256
    assert artifact.query_magic == "cffaedfe", "Expected arm64 Mach-O bytes"
    (EVIDENCE / "candidate-artifact.json").write_text(json.dumps(asdict(artifact), indent=2) + "\n")
    assets = ROOT / "assets-native"
    assets.mkdir(exist_ok=True)
    for source in (ROOT / "assets").iterdir():
        if "kast-control" not in source.name:
            shutil.copy2(source, assets / source.name)
    shutil.copy2(archive, assets / archive.name)
    (assets / f"{archive.name}.sha256").write_text(f"{artifact.archive_sha256}  {archive.name}\n")
    home = ROOT / "n"
    command = [
        "/bin/bash",
        str(REPO / "install.sh"),
        "--idea-home",
        "/Users/amichne/Applications/IntelliJ IDEA.app/Contents",
        "--skip-codex-plugin",
        "--verbose",
    ]
    environment = {
        "PATH": os.environ["PATH"],
        "HOME": str(home),
        "USER": os.environ["USER"],
        "LANG": "en_US.UTF-8",
        "KAST_VERSION": "0.0.0",
        "KAST_HOST_VERSION": "0.0.0",
        "KAST_INSTALL_ASSETS_DIRECTORY": str(assets),
        "KAST_INSTALL_PROFILE": "persistent",
        "JAVA_TOOL_OPTIONS": f"-Duser.home={home}",
    }
    with (
        (EVIDENCE / "candidate-install.stdout").open("wb") as stdout,
        (EVIDENCE / "candidate-install.stderr").open("wb") as stderr,
    ):
        result = subprocess.run(
            command, env=environment, cwd=ROOT, stdout=stdout, stderr=stderr, check=False
        )
    installation = Installation(command, environment, str(ROOT), result.returncode)
    (EVIDENCE / "candidate-install.json").write_text(
        json.dumps(asdict(installation), indent=2) + "\n"
    )
    print(json.dumps(asdict(artifact), indent=2))
    print(f"Actual installer exit: {result.returncode}")


if __name__ == "__main__":
    main()
