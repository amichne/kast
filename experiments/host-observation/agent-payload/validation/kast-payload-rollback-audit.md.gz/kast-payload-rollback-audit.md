# Rollback audit

Generated: 2026-10-27T14:12:22.164151+00:00

Result: exact installed host bytes exist and match the active ownership receipt. Post-success rollback is not yet qualified.

No backups, installs, refreshes, queries, model calls, credential reads, or repository edits occurred in this audit.

## Current independent component identities

- Control installation: `/Users/amichne/.local/share/kast/installation`
- Control manifest: `/Users/amichne/.local/share/kast/installation/installation.json`
- Control version: `0.0.3719`
- Control payload identity: `sha256:6fad4741eb7086185bafecd904e6d18f6462d6da626939ce99dd622ad6339255`
- Control manifest SHA-256: `d8c977d1028aad719009c57a6a7b92cbd463feafb1365d916d4c3f8709c313e5`
- Active host receipt: `/Users/amichne/Library/Application Support/JetBrains/IntelliJIdea2026.2/.kast-plugin-recovery/host-install.json`
- Receipt SHA-256: `ee3f60b25bd2f1270ed3ac6bcafea840d1cc7f1ee994c1652d333b546156a37d`
- Host version: `0.20261026.5903`
- Original host ZIP SHA-256 recorded by receipt: `8ffe2733741b272ddbef07130b5b9a81a2098dacf59ec642fffe111816de2449`
- Host destination: `/Users/amichne/Library/Application Support/JetBrains/IntelliJIdea2026.2/plugins/kast-ide-hosted`
- Host main JAR: `/Users/amichne/Library/Application Support/JetBrains/IntelliJIdea2026.2/plugins/kast-ide-hosted/lib/kast-ide-hosted-0.20261026.5903.jar`
- Main JAR SHA-256: `8b3b3a2722bf953747deefa0d4bad16c9a18fbb90be5739fee3c46fe5b0cfb71`
- Receipt inventory: 40 entries, including 39 regular files. Exact identities, sizes, and SHA-256 values matched. Errors: `[]`.

The control release pair for `0.0.3719` does not identify the independently installed host `0.20261026.5903`.
Restoring another host version does not restore this exact host baseline.

The host source label `9ff85c5156e6e838e5a2e46e6779db669dce35e6` comes from installed library filenames and local Git resolution.
That label does not independently attest source-to-binary reproducibility.

## Archive availability in scoped known outputs

No archive matched the original host ZIP digest in the following inspected build outputs.
This scoped search does not prove global absence. No broad repository search occurred.

| Archive | Bytes | SHA-256 |
| --- | ---: | --- |
| `/Users/amichne/.codex-workspaces/worktrees/ios-ce65fd8a-9ce0-4ea3-9e2b-1bac0a5b7518/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.50.2-idea-262.zip` | 36433504 | `2b13d7c8953073a6f4d16f16999c0e720f06ef0d9a34cd44de4b9de16e917af5` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.0.3702-idea-262.zip` | 34833565 | `01242e1f5f79b70a7a3293505ce202a5a255adeb90bfc7185cdc11795ba8db09` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.20260927.70212-idea-262.zip` | 23687480 | `e2380a6a967e4a517b2e25a0aa557c37da1cccfce3785c4100b5e35a594a0fee` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.20260927.90001-idea-262.zip` | 23687478 | `834c8914ec77728cd60572adff6cf8eaadd5aba62b81246fadb127c858fdfea9` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.20260928.121700-idea-262.zip` | 23699315 | `5e6a3054481cfdfea6d87236abdeece769d4f8d68b90c128aa70e42979b1f185` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.20261023.31735-idea-262.zip` | 35049971 | `86bab6b612eb365ca5bbeeebf6454edfba91efcde65877388db80f8bf855bdf9` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.20261023.31921-idea-262.zip` | 35049967 | `e99899a528d19564f784d46abd33ecbdc4c0a19bc838768438ecb1ff77b1a3c9` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.47.0-1-g2a649b7de-idea-262.zip` | 23687681 | `b84607316a38a5dbd67253cfe82dfb9d1b22b9178f6634c32bdf236fa852f3c7` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.47.0-idea-262.zip` | 23686808 | `64e5543f2aec83c14f85ce8db8fe4166a0b1b03aa5ee2235e5047e9afea956ce` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.47.4-idea-262.zip` | 23898820 | `364c12e22e672d2af7cf94731efe5432045cc14dbeee60863795a2296d934c9c` |
| `/Users/amichne/code/kast/runtime/hosted/build/distributions/kast-ide-hosted-v0.50.2-14-g0f26603775-idea-262.zip` | 34812401 | `0943b9afa8c8dd68df04a11b9935ca2fc6bdf2097c5d311a3c2b3890196bfe11` |

The known prior worktree output `/Users/amichne/.codex/worktrees/7ee5/kast/runtime/hosted/build/distributions` does not exist.
The plugin recovery directory contains only `host-install.json` and `host-install.lock`. It contains no prior host payload.
The control recovery directory contains lifecycle/recovery scripts and an Active receipt. It contains no captured prior payload archive.

## Transactional activation recovery

Source: `/Users/amichne/.local/share/kast/installation/share/kast/host-installation.py:654-716`
Source SHA-256: `82cdaebdd6042577e56b205206ef4428f8784ba50f9b2f262d4f2fdd9506fe05`

The installer stages a candidate and records the prior destination identity. It renames the prior directory to `host-prior-<token>`.
On activation failure, it restores that prior directory and prior receipt.
After successful activation, it deletes the prior directory at lines 714-716.
This transaction protects failed activation. It supplies no retained post-success rollback payload.

## Existing inert archive mechanism

Source: `/Users/amichne/.codex-workspaces/worktrees/ios-ce65fd8a-9ce0-4ea3-9e2b-1bac0a5b7518/kast/runtime/hosted/native/mixed_version_acceptance.py:717-798` and `810-974`
Runner SHA-256: `7f199491753456b096f330607aff699a1e7a5285bdca918bd0194e6f2bcc57d4`

The native acceptance owner captures `control-original.tar`, `plugin-original.tar`, and `publication-original.tar` with file facts and archive digests.
Its snapshot first requires IDEA to be closed and admits the normal installed lifecycle, service, public command, registrations, and workspace.
The archives remain inert files. They do not form a second installation.
Its restore path stops IDEA, uses the installed lifecycle reset, takes owner locks, checks archive digests, and rehydrates admitted regular files.
It then checks content facts, service identity, state epoch, versions, and protected registrations.
The harness has no standalone snapshot-only or restore-only CLI. Its full entry point also runs independent upgrade acceptance operations.
Invoking the full harness solely to capture rollback state exceeds this read-only audit.

## Material post-success ownership gap

The harness snapshots the plugin directory, but it does not snapshot or restore the sibling `host-install.json` active receipt.
Its restore recreates the plugin directory and files, which changes inode identities.
The installed owner at `/Users/amichne/.local/share/kast/installation/share/kast/host-installation.py:398-424` checks destination and inventory identities against that receipt.
The receipt therefore needs a proven owner transition after byte restoration. A content match alone does not prove future managed installation ownership.
This is a source-based qualification gap. No destructive restore reproduction ran.

## Unmet actions before a rollback claim

1. Capture the exact current component state before activation through an authorized, owner-admitted inert snapshot while IDEA is closed.
2. Preserve the active host receipt and account for its identity constraints. Do not treat an old receipt as valid for recreated inodes.
3. Get the exact host archive matching the receipt digest, or qualify an owner-supported restoration transition for the captured plugin bytes.
4. Restore control and host independently. Use normal lifecycle ownership, not copied process state or another release pair.
5. Prove post-restore bytes, active ownership, service generation, state epoch, and protected registrations through the existing owners.
6. Prove the fresh host state and semantic behavior through a separately authorized native run.

No backup or post-success rollback qualification was created by this audit.
