# Collector handoff — not live evidence

## 2026-10-30 correction

Read [the rotation and capacity amendment](rotation-capacity-amendment.md) before using this collector.
It supersedes the historical pending paths, no-rotation restriction, and pilot commands below.
The old pilot and failed cohort remain preserved.
The corrected collector needs a new pilot on a fresh measurement-only IDEA lifetime.
The earlier preparation notes below remain for provenance, not as current authorization.

Only this ignored measurements directory was edited. No Gradle, installed command, JVM payload, or IDEA was started for this work. `collector.py` has no third-party runtime dependencies; its uv lock contains no packages.

## Pending inputs

Lifecycle owner established `/private/tmp/knq-lifecycle-5VGhDa`:

- Candidate and shared host HOME: `home`.
- Baseline HOME: `baseline-home`.
- Shared workspace: `workspace`.
- IDEA: `Owned IDEA.app/Contents`.
- Log: `idea-logs/idea.log`.

These are new cohort paths, not the old host's identity. Populate `config.example.json` into a new `ready.json` **after** main supplies final installed artifact digests and host readiness. Supply the entire exact endpoint document, the complete `live` basis, and source path under the new workspace. The source must retain SHA-256 `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`.

Pin both dispatcher/payload/manifest files and readiness/qualification receipts in `identities`. Also pin configuration, wrappers, archive, and source/build evidence supplied by main where available. `qualificationReceipt` is main's evidence, not a product qualification produced by this collector. Include source SHAs, tree-state evidence, exact IDEA/JBR/GraalVM/platform versions, build duration and artifact byte sizes. Missing measurements must say UNAVAILABLE, never zero.

Supply one **already-issued** OrderService retained producer stdout and receipt (`exitCode: 0`, `reapedBeforeNextInvocation: true`) and its exact token. Producer execution is outside every timing sample. Both routes read that same token, including native reads of a baseline-issued token when baseline is the producer. Prefer a fresh baseline-issued producer immediately before the pilot/cohort, since the retained TTL is finite. A new producer/token may be supplied between pilot and cohort; neither belongs inside measured reads. Never generate a token string independently.

Baseline environment needs the selected JBR and explicit JVM home targeting the shared host home; candidate receives no Java options. Main must confirm these exact selected environments against the new installation context. The sample environment is the entire subprocess environment, not a merge with this shell. No extra timeout option is added to the product. `watchdogSeconds` is only a recorded harness termination bound.

No builds, other host clients, source changes, endpoint replacement, or log rotation during a cohort. All mismatches/failures remain recorded; an invalid cohort must be preserved rather than rerun into the same output directory.

## Commands

From the repository root:

```sh
M=.amp/in/artifacts/native-query/size-waived/measurements
uv run --no-project --locked --script "$M/collector.py" --self-test
uv run --no-project --locked --script "$M/collector.py" --check "$M/ready.json"
```

Only after main authorizes the ready host:

```sh
uv run --no-project --locked --script "$M/collector.py" \
  --pilot "$M/ready.json" --authorize-ready-host --output "$M/pilot-001"
```

Pilot is ten fresh processes: one baseline/native pair per workload, retained first. It is excluded from the 30-pair cohort. Inspect every pilot assertion, output, host join and resource receipt. The actual process capture boundary has not been exercised during preparation; pilot must qualify it. Require the pilot summary's `state: PASS`, not only individual command exits.

Add `pilotReceipt` pointing to the pilot `summary.json`, and pin its SHA-256 in `identities`. Do not change routes/artifacts/live basis or collector code after the pilot; `--run` rejects those changes. Then, only on main's go-ahead:

```sh
uv run --no-project --locked --script "$M/collector.py" \
  --run "$M/ready.json" --authorize-ready-host --output "$M/cohort-001"
```

## Recorded evidence and limits

- A STARTING record precedes every process creation; the STARTED record includes its PID. Exact argv, complete selected env, cwd, input bytes, UTC epoch wall time, monotonic process-to-output-EOF time, exits, output bytes/hashes, load averages, log inode/offsets/slices, and decoded receipt arrays survive assertions.
- `wait4` captures CPU and peak RSS for the waited public child under OS accounting. This is not full descendant telemetry or summed concurrent tree RSS. Raw units are explicit; launch counts remain unavailable.
- stdout/stderr are drained concurrently to EOF, not inferred complete from the public process disappearing. Interruptions/watchdog expiry kill only the collector-created process group, reap its public child, preserve diagnostics, and invalidate the cohort. No automatic replay.
- Receipt checking requires the actual `kast_transport_read` connection/read join and exact host PID/host/epoch. Retained reads require RETENTION plus exact zero producer/search entries and the established zero discovery/relation counters. The historical receipt replay proves the parser sees the existing join, unlike the earlier report's stated join limitation.
- Independent OrderService and caller assertions retain fixed signatures, ranges, direction, compiler coverage and selected fields. Full-document pairs are compared after only fresh result/row allocation renaming. Retained documents receive **no normalization**.
- Metadata and plan compare complete nonempty JSON documents and require no hosted receipt activity. Main's focused schema/metadata qualification is still required; peer equality alone is not an independent schema oracle.
- Statistics preserve all completed measured samples, including failures, and show count, median, nearest-rank empirical p95, min/max, and native-minus-baseline paired differences. Failures and incomplete runs prohibit a latency claim. Pilot and warmups are excluded.

## Validation status

Offline self-test replays saved acceptance documents/receipts, checks seven semantic mutation rejections, missing-join rejection, fixed 310-slot scheduling/alternation, and p95. This is comparator/collector logic evidence only, not new native behavior. The initial self-test exposed an overly narrow occurrence-object check: real occurrences include `candidateSelector`; the corrected oracle checks independently expected file/range and retains the entire object in full-document comparison. Earlier failing logs are preserved.

Successful issued-token RESUME remains a separate investigation in `resume-findings.md`, not an added timing workload or fabricated producer.
