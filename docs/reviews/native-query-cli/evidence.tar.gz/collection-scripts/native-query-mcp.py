# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["pydantic==2.12.3", "jsonschema==4.25.1", "anyio==4.12.1", "mcp==1.26.0"]
# [tool.uv]
# no-build = true
# ///
"""Real stdio task session with the actual installed JVM RPC child."""

import json
import os
import sys
from pathlib import Path

import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import TextContent

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / ".amp/in/artifacts/native-query"
HOME = Path("/private/tmp/knq-iwg1g7v8/n")
INSTALLATION = HOME / ".local/share/kast/installation"


async def main() -> None:
    parameters = StdioServerParameters(
        command=sys.executable,
        args=[
            str(INSTALLATION / "share/kast/agent-tools/plugins/kast/skills/kast/scripts/server.py"),
            "--rpc",
            str(INSTALLATION / "bin/kast-tool-rpc-complete"),
            "--workspace",
            "/private/tmp/kast-public-cli-v1-a3b5uat_/workspace",
        ],
        env={
            "PATH": os.environ["PATH"],
            "HOME": str(HOME),
            "JAVA_TOOL_OPTIONS": f"-Duser.home={HOME}",
        },
    )
    (EVIDENCE / "installed-mcp-parameters.json").write_text(parameters.model_dump_json(indent=2))
    with (EVIDENCE / "installed-mcp.stderr").open("w") as errors:
        with anyio.fail_after(120):
            async with (
                stdio_client(parameters, errlog=errors) as streams,
                ClientSession(*streams) as client,
            ):
                initialization = await client.initialize()
                (EVIDENCE / "installed-mcp-initialize.json").write_text(
                    initialization.model_dump_json(indent=2)
                )
                tools = await client.list_tools()
                (EVIDENCE / "installed-mcp-tools.json").write_text(tools.model_dump_json(indent=2))
                assert {"find", "callers", "source", "result"} <= {
                    tool.name for tool in tools.tools
                }
                result = await client.call_tool("find", {"name": "OrderService"})
                (EVIDENCE / "installed-mcp-find.json").write_text(result.model_dump_json(indent=2))
                assert not result.isError
                assert len(result.content) == 1
                block = result.content[0]
                assert isinstance(block, TextContent)
                document = json.loads(block.text)
                assert document["type"] == "complete"
                items = document["document"]["items"]
                assert len(items) == 1 and items[0]["name"] == "OrderService"
                assert items[0]["location"]["range"] == {"startInclusive": 17, "endExclusive": 94}
                assert (
                    document["document"]["live"]["host"] == "a37aac46-4b61-4426-830a-8e9186f8d464"
                )
    print("PASS: installed stdio service and JVM RPC return the independent class oracle")


if __name__ == "__main__":
    anyio.run(main)
