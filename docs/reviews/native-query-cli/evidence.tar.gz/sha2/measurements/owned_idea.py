"""Prepare by default; own one measurement lifetime only after explicit release."""

import argparse
import json
import os
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/knq-lifecycle-5VGhDa")
HOME = ROOT / "m"
JBR = ROOT / "Owned IDEA.app/Contents/jbr/Contents/Home"
STOP = ROOT / "stop-idea-sha2-measurement-001"


def save(name: str, value: object) -> None:
    with (HERE / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorize-measurement-lifetime", action="store_true")
    options = parser.parse_args()
    if not options.authorize_measurement_lifetime:
        print("PREPARED_NOT_RUN: main release and correctness completion required")
        return
    reaped = HERE.parent / "lifecycle/host-reaped.json"
    if not reaped.is_file() or json.loads(reaped.read_text())["pid"] != 35613:
        raise SystemExit("correctness IDEA must be stopped and reaped by its owner first")
    if STOP.exists() or (HERE / "host-launch.json").exists():
        raise SystemExit("refusing reused lifetime or existing stop marker")
    command = [str(ROOT / "Owned IDEA.app/Contents/MacOS/idea"), str(ROOT / "workspace")]
    environment = {
        "PATH": "/usr/bin:/bin:/opt/homebrew/bin",
        "HOME": str(HOME),
        "USER": "amichne",
        "LOGNAME": "amichne",
        "LANG": "en_US.UTF-8",
        "TMPDIR": str(ROOT / "tmp"),
        "IDEA_PROPERTIES": str(HERE / "idea-measurement.properties"),
        "IDEA_VM_OPTIONS": str(ROOT / "idea-sha2.vmoptions"),
        "KAST_INSTALL_IDEA_HOME": str(ROOT / "Owned IDEA.app/Contents"),
        "KAST_GRADLE_JAVA_HOME": str(JBR),
        "JAVA_HOME": str(JBR),
        "GRADLE_USER_HOME": str(ROOT / "gradle"),
    }
    with (HERE / "host.stdout").open("xb") as stdout, (HERE / "host.stderr").open("xb") as stderr:
        child = subprocess.Popen(command, env=environment, cwd=ROOT, stdout=stdout, stderr=stderr)
        save(
            "host-launch.json",
            {
                "pid": child.pid,
                "ownerPid": os.getpid(),
                "command": command,
                "environment": environment,
                "directory": str(ROOT),
                "stopMarker": str(STOP),
                "start": subprocess.check_output(
                    ["/bin/ps", "-p", str(child.pid), "-o", "lstart="], text=True
                ).strip(),
            },
        )
        print(f"Owned measurement IDEA PID {child.pid}; owner {os.getpid()}", flush=True)
        try:
            while child.poll() is None and not STOP.exists():
                time.sleep(0.25)
        finally:
            if child.poll() is None:
                child.terminate()
            try:
                code = child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                child.kill()
                code = child.wait(timeout=30)
            save("host-reaped.json", {"pid": child.pid, "exitCode": code})
            print(f"Owned IDEA reaped: {code}", flush=True)


if __name__ == "__main__":
    main()
