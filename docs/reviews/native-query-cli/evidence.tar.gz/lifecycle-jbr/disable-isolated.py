"""Exercise the private coordinator owner with explicit JBR and isolated JVM home.

This does not substitute for public stop, whose environment strips JAVA_OPTS.
"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/private/tmp/knq-iwg1g7v8')
OUT = Path(__file__).resolve().parent
JBR = '/Users/amichne/Applications/IntelliJ IDEA.app/Contents/jbr/Contents/Home'

for tag in ['b', 'n']:
    home = ROOT / tag
    installation = home / '.local/share/kast/installation'
    env = {'HOME': str(home), 'PATH': '/usr/bin:/bin', 'JAVA_HOME': JBR, 'JAVA_OPTS': '-Duser.home=' + str(home), 'KAST_CONFIGURATION_FILE': str(installation / 'config/environment')}
    for action in ['disable', 'status']:
        label = tag + '-isolated-' + action
        command = [str(installation / 'share/kast/libexec/kast-service'), action]
        (OUT / (label + '.command.json')).write_text(json.dumps({'command': command, 'environment': env, 'directory': str(installation)}, indent=2) + '\n')
        result = subprocess.run(command, env=env, cwd=installation, capture_output=True, timeout=60)
        (OUT / (label + '.stdout')).write_bytes(result.stdout)
        (OUT / (label + '.stderr')).write_bytes(result.stderr)
        (OUT / (label + '.exit')).write_text(str(result.returncode) + '\n')
        print(label, result.returncode, flush=True)
    identities = json.loads((OUT / (tag + '-identities.json')).read_text())
    for path, facts in identities.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == facts['sha256'], path
    print(tag, 'payload, management receipt manifest, service script and fence bytes unchanged', flush=True)
