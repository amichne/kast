# Temporary size-only collection amendment

Authority: the user's continuation instruction explicitly waives size checks temporarily and authorizes preparation of a collector, not live execution yet.

The original `../../collection-decision.md` is unchanged. Its SHA-256 is `ebf863611b67b1cdcfb9d5b93b5f68d38fbaa06d3f53974b5bcec84995813e9b`.

The 64 MiB archive and 128 MiB installed limits are temporarily waived for this separately labeled cohort. This is not a size PASS, a permanent product-limit change, or permission to omit measured artifact bytes. No other acceptance condition is waived. Main owns the final artifact/installer qualification receipt.

The previous disposable host was stopped. The lifecycle owner supplies replacement installation roots, host identity, endpoint, and basis. Those are explicit configuration inputs, held exact across all pairs. Saved source bytes and independent ranges remain unchanged; changing the actual workspace path does not permit removing or normalizing that path in comparisons.

Unchanged counts and order: retained read first; then metadata, plan, discovery, callers. Each cohort has one untimed warmup per route and 30 alternating fresh-process pairs, baseline-first for even zero-based pairs. Total: 10 warmups and 300 measured starts. Warmup duration is preserved but excluded from descriptive statistics. A failed or interrupted run is never silently dropped or automatically replaced.

The collector uses the exact installed public routes without a timing wrapper. Zero-JVM enforcement-policy evidence is separately qualified by main. All launch-count fields in this collector are unavailable, not zero. `wait4` resource accounting is not full descendant execution tracing or summed concurrent tree RSS.

No product or IDEA launches occurred while preparing this amendment and collector. A final explicit ready-host authorization is still required.
