# Native import diagnosis

Generated: 2026-10-27T13:32:36.940674+00:00

Gradle rejected `:noise0` because its declared directory did not exist. Both installed-client attempts reached this same error.

Fixture root: `/Users/amichne/.codex-workspaces/worktrees/ios-ce65fd8a-9ce0-4ea3-9e2b-1bac0a5b7518/kast/experiments/host-observation/semantic-fixture`

| Attempt | Request ID | Error time as recorded | Log lines |
| --- | --- | --- | --- |
| Initial | `8daeb1b8-188c-4d71-82b6-47e7aa1d5484` | 2026-10-27 06:00:09 | `idea.log:25603-25604`, `25816-25850` |
| Recheck | `10637c75-ba26-4c39-b341-a47ef3562802` | 2026-10-27 07:26:55 | `idea.log:27310-27315` |

Log path: `/Users/amichne/Library/Logs/JetBrains/IntelliJIdea2026.2/idea.log`

Each error precedes an import callback with `FAILED`, then lifecycle `IMPORT_FAILED`. Task completion does not prove successful model application.

The control installation reports `0.0.3719`. Its knowledge manifest reports source `48584596eebba0b23e6fc79f8e306b8219e9ce76`.

Control manifest: `/Users/amichne/.local/share/kast/installation/installation.json`

Knowledge manifest: `/Users/amichne/.local/share/kast/installation/share/kast/knowledge/manifest.json`

CLI library: `/Users/amichne/.local/share/kast/installation/lib/cli-0.0.3719.jar`

The loaded runtime reports `0.20261026.5903`. Its installed library names carry source label `9ff85c515`, resolved locally to `9ff85c5156e6e838e5a2e46e6779db669dce35e6`.

Runtime library: `/Users/amichne/Library/Application Support/JetBrains/IntelliJIdea2026.2/plugins/kast-ide-hosted/lib/kast-ide-hosted-0.20261026.5903.jar`

Source-label library: `/Users/amichne/Library/Application Support/JetBrains/IntelliJIdea2026.2/plugins/kast-ide-hosted/lib/contract-0.0.3702-16-g9ff85c515.jar`

Loaded-plugin evidence: `/Users/amichne/Library/Logs/JetBrains/IntelliJIdea2026.2/idea.1.log:15861` records `Kast Existing IDE Runtime (0.20261026.5903)`.

These metadata identify installed artifacts. They do not prove reproducible source-to-binary identity. The JSON companion records exact artifact digests.

The root owner can create the declared empty directory, preserve existing files, and use normal lifecycle admission for one bounded retry.

No source edits, native calls, refreshes, or installs occurred during this diagnosis. A later retry is outside this historical evidence scope.

# Later root-owned retry: generated wrapper files

Request `a65e4bde-a9cc-4eed-a56a-e11cd476d96f` entered normal IDE import after the root owner created the empty directory.

`idea.log:27678` records the IDE Tooling API `wrapper` task at 09:31:25.136. Its temporary init script redirects files only when a wrapper already exists.

The four wrapper files appeared between 09:31:41.591 and 09:31:41.751 EDT. The Gradle 9.6.0 build completed at 09:31:41.898 EDT.

Gradle log: `/Users/amichne/.gradle/daemon/9.6.0/daemon-37138.out.log:57-94`

Build ID: `e6ef6f28-d3ef-4056-8180-b07364ae4626`

The generated properties select `gradle-9.6.0-bin.zip`. The JSON companion records all four file hashes and creation timestamps.

The lifecycle reached `ADMISSION` at `idea.log:28589`, then `COMPLETE` at `idea.log:28705`. The semantic reply remains a separate acceptance claim.

This agent inspected logs and files only. It created no repository files and performed no native call or refresh.
