"""Read-only JVM/home and installed-service diagnostics for the two disposable roots."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/private/tmp/knq-iwg1g7v8')
OUT = Path(__file__).resolve().parent
JBR = Path('/Users/amichne/Applications/IntelliJ IDEA.app/Contents/jbr/Contents/Home')

def run(label, command, environment, directory):
    record = {'command': command, 'environment': environment, 'directory': str(directory)}
    (OUT / (label + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
    completed = subprocess.run(command, env=environment, cwd=directory, capture_output=True, timeout=60)
    (OUT / (label + '.stdout')).write_bytes(completed.stdout)
    (OUT / (label + '.stderr')).write_bytes(completed.stderr)
    (OUT / (label + '.exit')).write_text(str(completed.returncode) + '\n')
    print(label, completed.returncode, flush=True)
    return completed

for tag in ['b', 'n']:
    home = ROOT / tag
    installation = home / '.local/share/kast/installation'
    env = {'HOME': str(home), 'PATH': '/usr/bin:/bin', 'JAVA_HOME': str(JBR)}
    # The exact filtered lifecycle environment lacks all JVM user.home options.
    default = run(tag + '-java-default-home', [str(JBR / 'bin/java'), '-XshowSettings:properties', '-version'], env, ROOT)
    assert default.returncode == 0 and b'user.home = /Users/amichne\n' in default.stderr
    explicit = run(tag + '-java-explicit-home', [str(JBR / 'bin/java'), '-Duser.home=' + str(home), '-XshowSettings:properties', '-version'], env, ROOT)
    assert explicit.returncode == 0 and ('user.home = ' + str(home) + '\n').encode() in explicit.stderr
    # Direct status is diagnostic only. Unlike public lifecycle children it retains JAVA_OPTS.
    safe = env | {'JAVA_OPTS': '-Duser.home=' + str(home), 'KAST_CONFIGURATION_FILE': str(installation / 'config/environment')}
    run(tag + '-service-status', [str(installation / 'share/kast/libexec/kast-service'), 'status'], safe, installation)
    run(tag + '-management-status', [str(home / '.local/bin/kast'), 'status', '--json'], env, ROOT)
    files = [home / '.local/bin/kast', installation / 'installation.json', installation / 'share/kast/libexec/kast-service', installation.parent / 'shutdown.json']
    if tag == 'n':
        files.append(installation / 'bin/kast-query')
    identities = {str(p): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in files}
    (OUT / (tag + '-identities.json')).write_text(json.dumps(identities, indent=2) + '\n')
    (OUT / (tag + '-shutdown.json')).write_bytes((installation.parent / 'shutdown.json').read_bytes())
