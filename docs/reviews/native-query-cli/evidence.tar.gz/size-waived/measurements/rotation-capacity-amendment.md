# Collector amendment and fresh-fixture handoff — 2026-10-30

Status: offline collector checks PASS; new live pilot and cohort NOT RUN.
This amendment does not qualify product size, launch counts, or latency.
It changes log collection and fixture lifetime, not semantic expectations or the frozen schedule.
No product command, host call, installation change, or production source edit occurred during this correction.
Tests started only short-lived Python children against private temporary log files.

## Preserved evidence

The following SHA-256 identities remain unchanged:

| Evidence | SHA-256 |
| --- | --- |
| Original collector, preserved as `collector-before-log-rotation.py` | `f673336227ec73ec6c9d6b0788d793fcea8876b7fc16540b7f524ed893f335ae` |
| `cohort-001/summary.json` | `6a6387c50362c0ab726b9a4ab0bf68f345913735915c2f197c99f40ed2d8f47b` |
| `pilot-001/summary.json` | `e9d21bfd1e779e08b61b1d85d91c49bbae98af58301ecf36b3984abbbd44be6e` |
| Original `../../collection-decision.md` | `ebf863611b67b1cdcfb9d5b93b5f68d38fbaa06d3f53974b5bcec84995813e9b` |
| Original size-only `collection-amendment.md` | `e2bada4ecec65f6c99c36ea42bfe6366eda176ef0d0327a4cf5c9680e4572738` |

The corrected `collector.py` SHA-256 is `e65318dec10295f4b5a240d410598e4899ba97aaab29f833bad7d53db51edc02`.
`pilot-001` remains PASS for its original collector and host.
`cohort-001` remains FAIL: 310 records, 252 passing assertions, one log-capture failure, and 57 capacity rejections.
No old sample was rewritten, excluded, or promoted to PASS.

## Two separate causes

### Discovery sample 191: log rotation

`cohort-001/191-discovery-measured-01-baseline/record.json` records exit 0, complete output, and `host log rotated/truncated`.
The secondary assertion was `KeyError('receipts')`, not a semantic rejection.
Its initial log inode was 464060085 at offset 9948695.
The prior read-only diagnosis found that inode at `idea.1.log`, ending at 10004221.
The successor `idea.log` inode was 464186386.
Joining the 55526-byte original tail and 2016-byte successor prefix satisfied the unchanged declaration and receipt assertions.
The joined read was `e7370b16-b039-4304-afd5-960e89bc2558`; its connection was `ddf0f6d1-f53c-4c45-ab44-70b7db378364`.
These are prior diagnostic observations, not a rerun or repaired cohort record.

The collector now holds the initial file descriptor across the child invocation.
It records the initial prefix hash and archive identities before the timed interval.
After pipe EOF, it accepts an append or one verified rename to `idea.1.log` plus the successor prefix.
Each span records its path, device/inode identity, byte bounds, and SHA-256.
Existing older archives must have the expected shifted identities when present.
Capture and hashing remain outside the process-to-pipe-EOF timer.
Their I/O cost still exists outside that interval; the new pilot must qualify the changed collector.

Missing generations, multiple rotations, ambiguous inode aliases, copy rotation, unexplained archives, observed truncation, and unstable capture fail closed.
Archive enumeration has a 64-file bound.
Prefix hashes detect observable truncate-and-regrow changes, not an adversarial exact restore between observations.
An explicit `logFailure` now fails validation before receipt access.
No parser join or semantic comparator was weakened.

### Caller samples 253–309: application-lifetime capacity

The first capacity rejection is `cohort-001/253-callers-measured-01-baseline/`.
Its stdout is exactly:

```json
{"type":"rejected_document","document":{"status":"rejected","boundary":"runtime","reason":"daemon-operation-lifecycle-capacity"}}
```

Its stderr records request `e985cbbc-515c-4630-b438-11826049b7b3`, stage `OPENING`, then `CAPACITY`.
All 57 rejected samples exit 4; both clients fail.
Their host log offsets remain 3617578, with no semantic producer invocation.
The earlier complete-log diagnosis counted 256 distinct preparation STARTED requests and 256 COMPLETE requests in this application lifetime.
There were 127 before the cohort and 129 during it: 62 retained, 62 discovery, and five caller calls.
The last admitted request was `75049762-25c0-4525-a944-209260635426`, sample 252, at 08:43:38.903.
These complete-log counts were established before the old host was released; this correction did not query that host.

Source evidence, relative to the repository root:

- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/lifecycle/IdeLifecycleState.kt:15,30–31,86–105,190–200`: default capacity 256; new requests enter `operations`; completion updates entries without removal.
- `runtime/hosted/src/main/kotlin/io/github/amichne/kast/runtime/hosted/lifecycle/IdeLifecycleApplication.kt:46–54`: one application service owns that state and emits preparation observations.
- `app-server/src/main/kotlin/io/github/amichne/kast/appserver/runtime/WorkspacePreparations.kt:179–197`: each preparation ID becomes the lifecycle Open request ID.

These files match baseline commit `1e3a654d3ea4f160d603a37e5c574d5470c9a543` byte for byte.
Their respective SHA-256 values are:

```text
c60d21c3c571d8bd3a48431af4f88f0367e98efbe53362581452f89f9cf35673
b05ed00975b026ca0629b7ee8f57368e01d6df102f0b56de38c4c3d83bb81fcf
6ffa943ad7cd1a814f1ac83b09bb32704500fb98c25f84e1181632761a938243
```

This is terminal operation bookkeeping, not active concurrency or retained-query capacity.
Waiting does not remove entries.
Release and Close also encounter the capacity check before admission.
Reusing IDs or bypassing preparation alters the tested product path.
The bounded fixture correction is a separately authorized fresh measurement-only IDEA application lifetime, not a production fix.

## Fresh readiness strategy

Main and the lifecycle owner supply the new fixture; this collector does not start or restart IDEA.
Do not reuse old PID 22176, its endpoint identity, or its token.
Do not replay the 65 correctness captures, MCP, or prior diagnostic calls on the measurement lifetime.
Those results remain separate, artifact-bound correctness evidence.

Before authorizing collection, record the new PID/start time, host UUID, complete endpoint, source path/digest, and both installation identities.
Pin the new readiness receipt, manifests, dispatchers, payloads, configurations, source provenance, qualification receipt, and this collector hash.
Both clients must target the same new workspace and host home.
Use the explicit disposable JBR for baseline and `JAVA_TOOL_OPTIONS=-Duser.home=<shared-host-home>`.
Native receives no Java option variables.
Use complete environments, not an inherited shell environment.

Require two sequential installed declaration readiness probes with identical complete live basis and the independent OrderService oracle.
Do not normalize host, epoch, root, source locations, coverage, or evidence.
If the basis changes, stop and preserve the failed readiness attempt.
Issue one fresh retained declaration through the installed baseline producer, outside all timings.
Record its exit, reaping, raw document, receipts, and exact issued token.
Both measured clients must read that token after the producer exits.

| Planned activity | Public processes | Capacity-consuming preparations |
| --- | ---: | ---: |
| Two readiness declaration probes | 2 | 2 |
| One retained producer | 1 | 1 |
| New pilot: one pair per workload | 10 | 6 |
| Frozen cohort: five workloads, one warmup per route, 30 alternating pairs each | 310 | 186 |
| Total | 323 | 195 |

The cohort still runs retained reads first; metadata and plan account for its other 124 processes.
The budget leaves 61 entries out of 256 for separately recorded setup activity.
Any extra readiness, producer, retry, or diagnostic call consumes that margin.
Unknown prior consumption is not zero.
The lifecycle owner must account for the application's earlier operations before approving this budget.
This accounting is a fixture admission condition, not a new collector claim about unobserved lifecycle operations.
An extra producer between pilot and cohort costs one more entry and needs fresh pinned receipts.
Retained expiry remains a failure; do not invent or refresh tokens inside measured reads.

Create new configuration and output paths; preserve every old configuration and receipt.
`config.example.json` defines the required fields, but its placeholders are not a ready fixture.
Bind `live`, `endpointExpected`, `source`, routes, and all identities to the new receipt.
Do not copy old host-specific facts as if they were defaults.
The source digest remains `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`.
If main changes the candidate bytes, require new qualification and correctness evidence before collection.

## Commands and checks

From `/Users/amichne/code/kast.feature-native-query-cli`:

```sh
M=.amp/in/artifacts/native-query/size-waived/measurements
uv run --no-project --offline --locked --script "$M/test_collector_rotation.py"
uv run --no-project --offline --locked --script "$M/collector.py" --self-test
uv tool run --offline pyright --project "$M/pyrightconfig.json"
R=/Users/amichne/.local/share/mise/installs/ruff/0.16.8/ruff-aarch64-apple-darwin/ruff
"$R" check "$M/collector.py" "$M/test_collector_rotation.py"
"$R" format --check "$M/collector.py" "$M/test_collector_rotation.py"
```

Observed: 12 deterministic tests PASS; historical comparator self-test PASS; strict Pyright has zero errors or warnings; Ruff check and format check PASS.
The tests use real file renames and reaped Python children, without sleeps or product calls.
`rotation-red.log` preserves the original failure: 12 tests, eight failures and three errors.
`rotation-green-final.log`, `rotation-self-test-final.log`, `rotation-pyright-final.log`, and `rotation-ruff-*.log` preserve final results.
AST comparison shows only `capture` and `validate_sample` changed among existing definitions.
The schedule, arguments, semantic comparators, receipt joins, normalization rules, and statistics are unchanged.

Only after main supplies and authorizes the new ready fixture:

```sh
uv run --no-project --offline --locked --script "$M/collector.py" --check "$M/ready-002.json"
uv run --no-project --offline --locked --script "$M/collector.py" \
  --pilot "$M/ready-002.json" --authorize-ready-host --output "$M/pilot-002"
```

Require pilot summary PASS, then pin that summary in a new cohort configuration as `pilotReceipt`.
The collector rejects a pilot with different artifact, host, route, or collector identities.
The old pilot cannot qualify this collector.
Only after separate cohort authorization:

```sh
uv run --no-project --offline --locked --script "$M/collector.py" \
  --run "$M/cohort-ready-002.json" --authorize-ready-host --output "$M/cohort-002"
```

No new live configuration was fabricated during this correction.
No pilot, cohort, product command, host query, installation operation, or build ran.
Complete descendant launch counts and successful issued-token RESUME remain outside this correction.
