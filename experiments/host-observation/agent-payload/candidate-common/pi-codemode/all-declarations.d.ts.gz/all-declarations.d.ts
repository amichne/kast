declare const tools: {
  /** Add one declaration at an exact top-level Kotlin target. A class or object target inserts into its existing body. A function, property, or type alias target inserts after that declaration. Kast plans and applies the change, examines the resulting source, and reports a verified receipt or finite failure with recovery evidence. Preserve the returned result. A cancelled or missing response does not prove that no write occurred. */
  mcp__kast__add_declaration(args: {
  // Kotlin declaration text to add at the exact target.
  // @minLength 1 @maxLength 1048576
  declaration: string;
  // Opaque exact-symbol reference to a top-level Kotlin declaration. Member and local targets reject. Copy the issued reference unchanged.
  // @minLength 1 @maxLength 1048576
  exactTarget: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { application: { [key: string]: unknown; }; plan?: { [key: string]: unknown; } | null; planIdentity: string; status: "complete"; } | { error: { application?: { [key: string]: unknown; } | null; code: "PLANNING_REJECTED" | "AUTHORIZATION_UNAVAILABLE" | "APPLY_REJECTED" | "APPLY_UNVERIFIED" | "RECOVERY_UNAVAILABLE"; plan?: { [key: string]: unknown; } | null; planIdentity?: string | null; recovery?: { [key: string]: unknown; } | null; }; status: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; } | {
  // @integer
  limitBytes: number;
  semantic: { authority: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    contentView: string;
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    root: string;
    type: "LIVE";
    // @integer
    version: number;
  } | {
    contentView: "SAVED_PSI_COMMITTED";
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    type: "LIVE_DIGEST";
    // @integer
    version: number;
    workspace_digest: string;
  } | { result: string; type: "RETAINED_RESULT"; } | { type: "UNAVAILABLE"; }; blockers: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    codes: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    failure: string | null;
    // @integer
    failure_count: number | null;
    kinds: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    qualification: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    rejection: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    stop: string | null;
  }; completion: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    interpretation: string | null;
    model: "COMPILER_RESOLVED_STATIC_V1" | "UNAVAILABLE";
    policy: "COMPLETE_ONLY" | "UNAVAILABLE";
  }; coverage: {
    exhaustive: boolean | null;
    // @integer
    known_minimum: number | null;
    limitations: Array<string>;
    progress: {
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      next_action: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      reason: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      type: string | null;
    };
    type: "COMPLETE" | "QUALIFIED" | "UNKNOWN";
  }; omissions: {
    codes: Array<string>;
    // @integer
    count: number | null;
  }; original_outcome: "complete" | "qualified" | "rejected_document" | "rejected"; presentation: {
    // @integer
    accumulated_rows: number | null;
    // @integer
    deferred_count: number;
    detail: "INLINE" | "DEFERRED_DETAIL" | "UNAVAILABLE";
    detail_read: "NONE" | "FRAGMENT" | "FINAL_FRAGMENT";
    // @integer
    evidence_presented: number;
    // @integer
    evidence_total: number | null;
    // @integer
    rows: number;
  }; recovery: {
    // @integer
    cursor: number;
    // @integer
    evidence_cursor: number;
    result: string;
    type: "READ_RESULT";
  } | {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    continuation: string;
    type: "RESUME";
  } | { reason: "NO_RETAINED_AUTHORITY" | "AUTHORITY_REJECTED"; type: "UNAVAILABLE"; }; };
  status: "rejected";
  type: "OUTPUT_LIMIT";
}; [key: string]: unknown; }>;
  /** Check compiler diagnostics for a file or recursively beneath a directory in the session workspace. Use '.' explicitly for the workspace root. This is not symbol search and does not build the project. Results retain incomplete-coverage evidence; an incomplete empty result does not establish that the scope is clean. Requires the saved, indexed IntelliJ state. */
  mcp__kast__check_diagnostics(args: {
  // Opaque same-basis diagnostic continuation. Omit or use null to start. Resume the same relative_path; increase execution_budget if a grant cannot cross the enumeration prefix.
  // @minLength 1 @maxLength 1048576
  continuation?: string | null;
  executionBudget?: {
    // Explicit timeout in milliseconds for RUNNER_CONTROLLED execution, including model capture. Omission adds no timeout. Legacy BOUNDED mode uses KAST_READ_SEMANTIC_MILLIS and host clamps.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxElapsedMs?: number | null;
    // In BOUNDED mode, this caps results. In RUNNER_CONTROLLED mode, this caps each output page.
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Query minimum: 4096 UTF-8 bytes. Omission uses KAST_READ_SEMANTIC_RETURNED_BYTES.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
    // Accounted work allowance. Query omission uses KAST_READ_SEMANTIC_WORK. Time and response size do not change this allowance.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxWorkUnits?: number | null;
  } | null | null;
  // Maximum diagnostic entries to return. Omission or null selects 100. This limits results, not module admission, indexing, or compiler work; incomplete coverage remains explicit.
  // @integer @minimum 1 @maximum 1000 @default 100
  maxDiagnostics?: number | null;
  // File or directory path relative to the session workspace root, such as src/main/kotlin/orders/OrderService.kt or services/orders. Use '.' for the root. Not a package name, glob, absolute path, or parent traversal.
  // @minLength 1 @maxLength 1048576
  relativePath: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: unknown; [key: string]: unknown; }>;
  /** Observe exact workspace binding and saved/indexed readiness. This passive check does not validate semantic answers. */
  mcp__kast__health_check(args: { verbose?: boolean; }): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { data: { contentView: "SAVED_PSI_COMMITTED" | null; host?: string | null; hostState: "INDEXED" | "UNAVAILABLE"; readiness: "READY" | "UNAVAILABLE"; readinessEvidence: unknown; workspaceBinding: string; }; status?: "complete"; } | { error: { code: "INVALID_REQUEST" | "HOST_UNAVAILABLE" | "OUT_OF_SCOPE" | "INTERNAL_ERROR"; message: string; }; status?: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; } | {
  // @integer
  limitBytes: number;
  semantic: { authority: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    contentView: string;
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    root: string;
    type: "LIVE";
    // @integer
    version: number;
  } | {
    contentView: "SAVED_PSI_COMMITTED";
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    type: "LIVE_DIGEST";
    // @integer
    version: number;
    workspace_digest: string;
  } | { result: string; type: "RETAINED_RESULT"; } | { type: "UNAVAILABLE"; }; blockers: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    codes: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    failure: string | null;
    // @integer
    failure_count: number | null;
    kinds: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    qualification: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    rejection: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    stop: string | null;
  }; completion: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    interpretation: string | null;
    model: "COMPILER_RESOLVED_STATIC_V1" | "UNAVAILABLE";
    policy: "COMPLETE_ONLY" | "UNAVAILABLE";
  }; coverage: {
    exhaustive: boolean | null;
    // @integer
    known_minimum: number | null;
    limitations: Array<string>;
    progress: {
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      next_action: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      reason: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      type: string | null;
    };
    type: "COMPLETE" | "QUALIFIED" | "UNKNOWN";
  }; omissions: {
    codes: Array<string>;
    // @integer
    count: number | null;
  }; original_outcome: "complete" | "qualified" | "rejected_document" | "rejected"; presentation: {
    // @integer
    accumulated_rows: number | null;
    // @integer
    deferred_count: number;
    detail: "INLINE" | "DEFERRED_DETAIL" | "UNAVAILABLE";
    detail_read: "NONE" | "FRAGMENT" | "FINAL_FRAGMENT";
    // @integer
    evidence_presented: number;
    // @integer
    evidence_total: number | null;
    // @integer
    rows: number;
  }; recovery: {
    // @integer
    cursor: number;
    // @integer
    evidence_cursor: number;
    result: string;
    type: "READ_RESULT";
  } | {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    continuation: string;
    type: "RESUME";
  } | { reason: "NO_RETAINED_AUTHORITY" | "AUTHORITY_REJECTED"; type: "UNAVAILABLE"; }; };
  status: "rejected";
  type: "OUTPUT_LIMIT";
}; [key: string]: unknown; }>;
  /** Find exact Kotlin declarations with NAME, LOCATION, and SIGNATURE. Select the exact overload before relations or TRACE. Copy issued references unchanged. READ_RESULT and READ_SOURCE preserve original authority and freshness. This session exposes the common query grammar. Start a COMPLETE session for advanced operations. */
  mcp__kast__query_symbols(args: { request: {
  executionBudget?: {
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Query minimum: 4096 UTF-8 bytes.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
  } | null | null;
  executionMode?: "RUNNER_CONTROLLED" | null | null;
  retention?: "DISCARD" | "RETAIN" | null;
  source: {
    // @minItems 1 @maxItems 4 @uniqueItems
    declarationKinds?: Array<"CLASS" | "FUNCTION" | "PROPERTY" | "TYPE_ALIAS"> | null;
    // @minLength 1 @maxLength 256
    declarationName: string;
    nameMatch?: "EXACT" | "FUZZY" | null;
    scope?: {
      includeSubdirectories?: boolean | null;
      // @minLength 1 @maxLength 1048576
      relativeDirectoryPath: string;
      // @minItems 1 @maxItems 1000 @uniqueItems
      sourceSetNames?: Array<string> | null;
      type: "DIRECTORY";
    } | {
      includeSubpackages?: boolean | null;
      // @minLength 1 @maxLength 1048576
      packageName: string;
      // @minItems 1 @maxItems 1000 @uniqueItems
      sourceSetNames?: Array<string> | null;
      type: "PACKAGE";
    } | null | null;
    type: "SEARCH_DECLARATIONS";
  } | {
    // @minLength 1 @maxLength 1048576
    file: string;
    // @integer @minimum 0
    offset: number;
    type: "AT_LOCATION";
  } | {
    // @minItems 1 @maxItems 1000
    symbolRefs: Array<string>;
    type: "SYMBOL_REFS";
  };
  // @minItems 0 @maxItems 1000
  steps?: Array<{ expansionScope?: { type: "WORKSPACE"; } | { type: "RETAINED_SEED"; } | {
    // @minLength 1 @maxLength 4096
    directory?: string | null;
    generatedSources: "EXCLUDE" | "INCLUDE";
    includeSubdirectories?: boolean | null;
    sourcePolicy: "PRODUCTION_ONLY" | "TEST_ONLY" | "PRODUCTION_AND_TEST";
    // @minItems 1 @maxItems 64 @uniqueItems
    sourceSets: Array<string>;
    type: "SOURCE_DOMAIN";
  } | null; relation: "REFERENCES" | "CALLERS" | "CALLEES" | "IMPLEMENTATIONS" | "INHERITORS" | "OVERRIDES" | "TYPE_USES"; type: "EXPAND_RELATION"; }> | null;
  terminalStep: { output?: {
    // @minItems 0 @maxItems 4 @uniqueItems
    fields: Array<"NAME" | "LOCATION" | "SIGNATURE" | "SOURCE">;
    type: "SYMBOLS";
  } | { type: "OCCURRENCES"; } | null | null; type: "EMIT"; } | { expansionScope?: { type: "WORKSPACE"; } | { type: "RETAINED_SEED"; } | {
    // @minLength 1 @maxLength 4096
    directory?: string | null;
    generatedSources: "EXCLUDE" | "INCLUDE";
    includeSubdirectories?: boolean | null;
    sourcePolicy: "PRODUCTION_ONLY" | "TEST_ONLY" | "PRODUCTION_AND_TEST";
    // @minItems 1 @maxItems 64 @uniqueItems
    sourceSets: Array<string>;
    type: "SOURCE_DOMAIN";
  } | null; output?: {
    // @minItems 0 @maxItems 4 @uniqueItems
    fields: Array<"NAME" | "LOCATION" | "SIGNATURE" | "SOURCE">;
    type: "SYMBOLS";
  } | null; type: "TRACE"; };
  type: "RUN";
} | {
  // @minLength 52 @maxLength 52
  continuation: string;
  executionBudget?: {
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Query minimum: 4096 UTF-8 bytes.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
  } | null | null;
  type: "RESUME";
} | {
  // @integer @minimum 0 @maximum 1000000
  cursor?: number | null | null;
  detail?: {
    kind: "EXACT_SYMBOL" | "OCCURRENCE" | "REFERENCE_OCCURRENCE" | "TRAVERSAL_RECORD" | "BINDING_ROW" | "VALUE_PATH" | "IMPACT_WITNESS" | "FAILURE" | "OMISSION" | "WALK_OBSERVATION" | "REFERENCE_OBSERVATION" | "DISCOVERY_OBSERVATION" | "RELATION_OBSERVATION";
    // @integer @minimum 0 @maximum 2147483647
    offset: number;
    // @integer @minimum 0 @maximum 1000000
    ordinal: number;
    result: string;
    section: "CANONICAL_ENTRY_JSON";
    // @minLength 64 @maxLength 64 @pattern ^[0-9a-f]{64}$
    sha256: string;
    target: "ROW" | "EVIDENCE";
  } | null | null;
  // @integer @minimum 0 @maximum 1000000
  evidence_cursor?: number | null | null;
  executionBudget?: {
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Query minimum: 4096 UTF-8 bytes.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
  } | null | null;
  output?: {
    // @minItems 0 @maxItems 4 @uniqueItems
    fields: Array<"NAME" | "LOCATION" | "SIGNATURE" | "SOURCE">;
    type: "SYMBOLS";
  } | { type: "OCCURRENCES"; } | null | null;
  result: string;
  type: "READ_RESULT";
} | {
  // @minLength 1
  candidateRef: string;
  executionBudget?: {
    // @integer @minimum 1 @maximum 2147483647
    maxResults?: number | null;
    // Query minimum: 4096 UTF-8 bytes.
    // @integer @minimum 1 @maximum 9223372036854776000
    maxReturnedBytes?: number | null;
  } | null | null;
  region?: "ANCHOR" | "CALLABLE_BODY" | "CLASS_BODY" | "FILE" | "ENCLOSING_DECLARATION" | "ENCLOSING_CALLABLE_BODY" | "ENCLOSING_CLASS_BODY" | null;
  text?: { type: "COMPLETE"; } | { type: "NONE"; } | {
    // @integer @minimum 0 @maximum 1000
    afterLines?: number | null;
    // @integer @minimum 0 @maximum 1000
    beforeLines?: number | null;
    type: "WINDOW";
  } | {
    // @integer @minimum 1 @maximum 1000
    maxLines?: number | null;
    type: "EXCERPT";
  } | null;
  type: "READ_SOURCE";
}; verbose?: boolean; }): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: unknown; [key: string]: unknown; }>;
  /** Replace only the block body of one existing, non-inline named Kotlin function selected by an exact Kast symbol reference. Kast plans, applies, verifies, and reports a verified receipt or finite failure with recovery evidence. The signature and surrounding source are preserved. */
  mcp__kast__replace_body(args: {
  // One complete Kotlin block body, including braces. Syntax errors and trailing input are rejected.
  // @minLength 1 @maxLength 1048576
  body: string;
  // Opaque exact-symbol reference returned by Kast. Copy it unchanged.
  // @minLength 1 @maxLength 1048576
  exactTarget: string;
  // Return execution diagnostics and redundant phase detail when true. Omitted or false returns compact semantic results, preserving qualifications, references, continuation and recovery evidence.
  // @default false
  verbose?: boolean;
}): Promise<{ content: Array<{ data?: string; mimeType?: string; text?: string; type: "text" | "image" | "audio" | "resource_link" | "resource"; [key: string]: unknown; }>; isError?: boolean; structuredContent?: { application: { [key: string]: unknown; }; plan?: { [key: string]: unknown; } | null; planIdentity: string; status: "complete"; } | { error: { application?: { [key: string]: unknown; } | null; code: "PLANNING_REJECTED" | "AUTHORIZATION_UNAVAILABLE" | "APPLY_REJECTED" | "APPLY_UNVERIFIED" | "RECOVERY_UNAVAILABLE"; plan?: { [key: string]: unknown; } | null; planIdentity?: string | null; recovery?: { [key: string]: unknown; } | null; }; status: "rejected"; } | { document: { [key: string]: unknown; }; status: "rejected"; type: "BOUNDARY_REJECTED"; } | { error: { code: "INVALID_ARGUMENTS" | "UNKNOWN_TOOL" | "NOT_GRADLE_WORKSPACE" | "INVOCATION_FAILED" | "INVOCATION_IN_PROGRESS" | "INVALID_RESULT_SCHEMA"; evidence?: unknown; message: string; }; status: "rejected"; type: "MCP_REJECTED"; } | {
  // @integer
  limitBytes: number;
  semantic: { authority: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    contentView: string;
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    root: string;
    type: "LIVE";
    // @integer
    version: number;
  } | {
    contentView: "SAVED_PSI_COMMITTED";
    // @integer
    epoch: number;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    host: string;
    type: "LIVE_DIGEST";
    // @integer
    version: number;
    workspace_digest: string;
  } | { result: string; type: "RETAINED_RESULT"; } | { type: "UNAVAILABLE"; }; blockers: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    codes: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    failure: string | null;
    // @integer
    failure_count: number | null;
    kinds: Array<string>;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    qualification: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    rejection: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    stop: string | null;
  }; completion: {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    cause: string | null;
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    interpretation: string | null;
    model: "COMPILER_RESOLVED_STATIC_V1" | "UNAVAILABLE";
    policy: "COMPLETE_ONLY" | "UNAVAILABLE";
  }; coverage: {
    exhaustive: boolean | null;
    // @integer
    known_minimum: number | null;
    limitations: Array<string>;
    progress: {
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      next_action: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      reason: string | null;
      // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
      type: string | null;
    };
    type: "COMPLETE" | "QUALIFIED" | "UNKNOWN";
  }; omissions: {
    codes: Array<string>;
    // @integer
    count: number | null;
  }; original_outcome: "complete" | "qualified" | "rejected_document" | "rejected"; presentation: {
    // @integer
    accumulated_rows: number | null;
    // @integer
    deferred_count: number;
    detail: "INLINE" | "DEFERRED_DETAIL" | "UNAVAILABLE";
    detail_read: "NONE" | "FRAGMENT" | "FINAL_FRAGMENT";
    // @integer
    evidence_presented: number;
    // @integer
    evidence_total: number | null;
    // @integer
    rows: number;
  }; recovery: {
    // @integer
    cursor: number;
    // @integer
    evidence_cursor: number;
    result: string;
    type: "READ_RESULT";
  } | {
    // @minLength 1 @maxLength 1048576 @pattern [\s\S]*\S[\s\S]*
    continuation: string;
    type: "RESUME";
  } | { reason: "NO_RETAINED_AUTHORITY" | "AUTHORITY_REJECTED"; type: "UNAVAILABLE"; }; };
  status: "rejected";
  type: "OUTPUT_LIMIT";
}; [key: string]: unknown; }>;
};