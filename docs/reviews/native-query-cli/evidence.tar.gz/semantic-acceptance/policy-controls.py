"""The two independent empty-answer controls under the execution policy."""
from acceptance import FIELDS, GRANTS, command, invoke, common, save

for name, relation in [('NoSuchNativeAcceptanceDeclaration', False), ('placeOrder', True)]:
    args = command(['query'], '--name', name, *FIELDS, *GRANTS, '--retain')
    if relation:
        args += ['--relation', 'callers']
    result, record = invoke('policy-' + ('wrong-target' if relation else 'absent-name'), 'native', args, policy=True)
    assert record['exitCode'] == 0
    assert common(result, name, relation)['items'] == []
save('policy-empty-controls.json', {'absentName': 'PASS', 'wrongTarget': 'PASS'})
