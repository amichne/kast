# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# ///
"""Bind successful correctness receipts into a pending-authorization pilot config; no calls."""
import importlib
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c
run = HERE / "run-002-corrected"
config = c.load(run / "measurement-ready.json")
summary = c.load(run / "summary.json")
c.require(summary["state"] == "PASS" and summary["recordedStarts"] == 65 and summary["allRecordedOuterChildrenReaped"], "complete corrected acceptance")
mcp = Path(summary["packagedMcpRpc"]["evidence"])
c.require(c.load(mcp / "summary.json")["state"] == "PASS", "actual packaged MCP success")
config["executionEvidence"] = {"status": "PASS", "mechanism": "enforced exact execution allowlist, qualified with direct and descendant absolute-JVM allowed/denied controls; not event counting", "correctnessSummary": str(run / "summary.json"), "policyRoutes": summary["policyRoutes"], "packagedMcpOutsideQueryJvmClaim": str(mcp / "summary.json")}
config["pilotAuthorization"] = "NOT AUTHORIZED: main must authorize separately; no pilot/cohort executed"
for path in (run / "measurement-ready.json", run / "summary.json", run / "native-exec.sb", run / "java-positive.sb", mcp / "summary.json", mcp / "payload-verification.json"):
    config["identities"][str(path)] = c.digest(path)
a.preflight(config)
c.preflight(config, artifacts=True)
output = run / "pilot-ready.json"
c.require(not output.exists(), "preserve prior pilot configuration")
c.save(output, config)
print("PASS read-only receipt/producer/artifact preflight; pilot config " + str(output))
