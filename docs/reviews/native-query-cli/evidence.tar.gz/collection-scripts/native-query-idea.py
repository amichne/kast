# /// script
# requires-python = ">=3.13"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Own one isolated IDEA process until its explicit fixture stop marker exists."""

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

REPO = Path(__file__).resolve().parents[2]
EVIDENCE = REPO / ".amp/in/artifacts/native-query"
OLD = Path("/private/tmp/kast-public-cli-v1-a3b5uat_")
IDEA = Path("/Users/amichne/Applications/IntelliJ IDEA.app/Contents")


@dataclass(frozen=True)
class Launch:
    pid: int
    command: list[str]
    home: str
    configuration: str
    plugins: str
    workspace: str


def main() -> None:
    fixture = json.loads((EVIDENCE / "fixture.json").read_text())
    root = Path(fixture["root"])
    home = Path(fixture["candidate_home"])
    plugins = Path(fixture["baseline_home"]) / "Library/Application Support/JetBrains/IntelliJIdea2026.2/plugins"
    config = root / "idea-config"
    shutil.copytree(OLD / "config", config)
    properties = root / "idea.properties"
    properties.write_text(
        f"idea.config.path={config}\nidea.system.path={root / 'idea-system'}\n"
        f"idea.plugins.path={plugins}\nidea.log.path={root / 'idea-logs'}\n"
        "jb.consents.confirmation.enabled=false\n"
    )
    vmoptions = root / "idea.vmoptions"
    vmoptions.write_text("\n".join(
        line for line in (OLD / "idea.vmoptions").read_text().splitlines()
        if not line.startswith("-Duser.home=")
    ) + f"\n-Duser.home={home}\n")
    (root / "tmp").mkdir()
    environment = {
        "PATH": os.environ["PATH"], "HOME": str(home), "USER": os.environ["USER"],
        "LOGNAME": os.environ["USER"], "LANG": "en_US.UTF-8", "TMPDIR": str(root / "tmp"),
        "IDEA_PROPERTIES": str(properties), "IDEA_VM_OPTIONS": str(vmoptions),
        "KAST_INSTALL_IDEA_HOME": str(IDEA), "KAST_GRADLE_JAVA_HOME": str(IDEA / "jbr/Contents/Home"),
        "GRADLE_USER_HOME": str(OLD / "gradle"),
    }
    command = [str(IDEA / "MacOS/idea"), str(OLD / "workspace")]
    with (EVIDENCE / "idea.stdout").open("wb") as stdout, (EVIDENCE / "idea.stderr").open("wb") as stderr:
        child = subprocess.Popen(command, env=environment, stdout=stdout, stderr=stderr)
        launch = Launch(child.pid, command, str(home), str(config), str(plugins), str(OLD / "workspace"))
        (EVIDENCE / "idea-launch.json").write_text(json.dumps(asdict(launch), indent=2) + "\n")
        print(f"Owned IDEA PID {child.pid}", flush=True)
        try:
            while child.poll() is None and not (root / "stop-idea").exists():
                time.sleep(1)
        finally:
            if child.poll() is None:
                child.terminate()
            try:
                status = child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                child.kill()
                status = child.wait(timeout=30)
            (EVIDENCE / "idea-exit.txt").write_text(f"{status}\n")
            print(f"Owned IDEA reaped: {status}", flush=True)


if __name__ == "__main__":
    main()
