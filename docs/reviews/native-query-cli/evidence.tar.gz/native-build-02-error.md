# GraalVM Native Image Error Report

## Build Output

```
========================================================================================================================
GraalVM Native Image: Generating 'kast-query' (executable)...
========================================================================================================================
For detailed information and explanations on the build output, visit:
https://github.com/oracle/graal/blob/master/docs/reference-manual/native-image/BuildOutput.md
------------------------------------------------------------------------------------------------------------------------

[1/8] Initializing...                                                                                    (0.0s @ 0.27GB)
```

## Stack Trace

```java
com.oracle.svm.core.util.VMError$HostedError: Bulk queries can only be set with 'name' which does not allow run-time conditions.
	at org.graalvm.nativeimage.builder/com.oracle.svm.core.util.VMError.shouldNotReachHere(VMError.java:78)
	at org.graalvm.nativeimage.builder/com.oracle.svm.core.util.VMError.guarantee(VMError.java:122)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.reflect.ReflectionDataBuilder.guaranteeNotRuntimeConditionForQueries(ReflectionDataBuilder.java:256)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.reflect.ReflectionDataBuilder.registerMethodLookup(ReflectionDataBuilder.java:523)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.RegistryAdapter.registerMethodNegativeQuery(RegistryAdapter.java:396)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.ReflectionRegistryAdapter.registerMethodNegativeQuery(ReflectionRegistryAdapter.java:219)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.RegistryAdapter.registerMethod(RegistryAdapter.java:363)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.RegistryAdapter.registerMethod(RegistryAdapter.java:59)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ReflectionConfigurationParser.parseMethod(ReflectionConfigurationParser.java:137)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ReflectionConfigurationParser.parseMethods(ReflectionConfigurationParser.java:116)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ReflectionMetadataParser.parseClass(ReflectionMetadataParser.java:128)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ReflectionConfigurationParser.parseClassArray(ReflectionConfigurationParser.java:78)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ReflectionMetadataParser.parseAndRegister(ReflectionMetadataParser.java:54)
	at org.graalvm.nativeimage.configure/com.oracle.svm.configure.ConfigurationParser.parseAndRegister(ConfigurationParser.java:110)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.ConfigurationParserUtils.doParseAndRegister(ConfigurationParserUtils.java:149)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.ConfigurationParserUtils.lambda$parseAndRegisterConfigurations$0(ConfigurationParserUtils.java:108)
	at java.base/java.util.stream.ReferencePipeline$4$1.accept(ReferencePipeline.java:231)
	at java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:214)
	at java.base/java.util.ArrayList$ArrayListSpliterator.forEachRemaining(ArrayList.java:1716)
	at java.base/java.util.stream.Streams$ConcatSpliterator.forEachRemaining(Streams.java:735)
	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:570)
	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
	at java.base/java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:921)
	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
	at java.base/java.util.stream.IntPipeline.reduce(IntPipeline.java:517)
	at java.base/java.util.stream.IntPipeline.sum(IntPipeline.java:475)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.ConfigurationParserUtils.parseAndRegisterConfigurations(ConfigurationParserUtils.java:110)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.config.ConfigurationParserUtils.parseAndRegisterConfigurationsFromCombinedFile(ConfigurationParserUtils.java:93)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.reflect.ReflectionFeature.duringSetup(ReflectionFeature.java:317)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGenerator.lambda$setupNativeImage$2(NativeImageGenerator.java:1097)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.FeatureHandler.forEachFeature(FeatureHandler.java:93)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGenerator.setupNativeImage(NativeImageGenerator.java:1097)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGenerator.doRun(NativeImageGenerator.java:567)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGenerator.run(NativeImageGenerator.java:534)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGeneratorRunner.buildImage(NativeImageGeneratorRunner.java:548)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGeneratorRunner.build(NativeImageGeneratorRunner.java:761)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGeneratorRunner.start(NativeImageGeneratorRunner.java:163)
	at org.graalvm.nativeimage.builder/com.oracle.svm.hosted.NativeImageGeneratorRunner.main(NativeImageGeneratorRunner.java:111)
```

## GraalVM Setup

| Name | Value |
| ---- | ----- |
| Java version | `25.0.2+10-LTS` |
| Vendor version | `Oracle GraalVM 25.0.2+10.1` |
| Runtime version | `25.0.2+10-LTS-jvmci-b01` |
| C compiler | `cc (apple, arm64, 21.0.0)` |
<details>
<summary>GraalVM <code>release</code> file</summary>

```
IMPLEMENTOR="Oracle Corporation"
JAVA_RUNTIME_VERSION="25.0.2+10-LTS-jvmci-b01"
JAVA_VERSION="25.0.2"
JAVA_VERSION_DATE="2026-01-20"
LIBC="default"
MODULES="java.base java.logging java.management jdk.internal.vm.ci org.graalvm.collections jdk.management jdk.unsupported org.graalvm.truffle.compiler org.graalvm.word jdk.graal.compiler com.oracle.graal.graal_enterprise org.graalvm.nativeimage com.oracle.svm.enterprise.truffle java.compiler java.datatransfer java.xml java.prefs java.desktop java.instrument java.security.sasl java.naming java.rmi java.management.rmi java.net.http java.scripting java.security.jgss java.transaction.xa java.sql java.sql.rowset java.xml.crypto java.se java.smartcardio jdk.accessibility jdk.internal.jvmstat jdk.attach jdk.charsets jdk.internal.opt jdk.zipfs jdk.compiler jdk.crypto.cryptoki jdk.crypto.ec jdk.dynalink jdk.internal.ed jdk.editpad jdk.graal.compiler.management jdk.hotspot.agent jdk.httpserver jdk.incubator.vector jdk.internal.le jdk.internal.md jdk.jartool jdk.javadoc jdk.jcmd jdk.management.agent jdk.jconsole jdk.jdeps jdk.jdwp.agent jdk.jdi jdk.jfr jdk.jlink jdk.jpackage jdk.jshell jdk.jsobject jdk.jstatd jdk.localedata jdk.management.jfr jdk.naming.dns jdk.naming.rmi jdk.net jdk.nio.mapmode jdk.sctp jdk.security.auth jdk.security.jgss jdk.unsupported.desktop jdk.xml.dom org.graalvm.nativeimage.libgraal org.graalvm.nativeimage.llvm org.graalvm.webimage.api"
OS_ARCH="aarch64"
OS_NAME="Darwin"
SOURCE=".:git:cbcffa9c3961 open:git:2ea5f0bb564c labsjdk-builder:730f35899d04557d42cb3ac8b3e2f74088a66c62 compiler:981ecb6e1be6bf4591a6dd24b48ea053221209f5 espresso-shared:981ecb6e1be6bf4591a6dd24b48ea053221209f5 graal-enterprise:e5b20d944dcc4662b075b4254041be1794431ca1 lium:e5b20d944dcc4662b075b4254041be1794431ca1 regex:981ecb6e1be6bf4591a6dd24b48ea053221209f5 reporter:e5b20d944dcc4662b075b4254041be1794431ca1 sdk:981ecb6e1be6bf4591a6dd24b48ea053221209f5 substratevm:981ecb6e1be6bf4591a6dd24b48ea053221209f5 substratevm-enterprise:e5b20d944dcc4662b075b4254041be1794431ca1 substratevm-enterprise-gcs:4cc47ecc8e0f2a5259b33ae3b912a2a091ab1bf2 tools:981ecb6e1be6bf4591a6dd24b48ea053221209f5 truffle:981ecb6e1be6bf4591a6dd24b48ea053221209f5 truffle-enterprise:e5b20d944dcc4662b075b4254041be1794431ca1 vm:981ecb6e1be6bf4591a6dd24b48ea053221209f5 vm-enterprise:e5b20d944dcc4662b075b4254041be1794431ca1 wasm:981ecb6e1be6bf4591a6dd24b48ea053221209f5 web-image:981ecb6e1be6bf4591a6dd24b48ea053221209f5 web-image-enterprise:e5b20d944dcc4662b075b4254041be1794431ca1"
GRAALVM_VERSION="25.0.2"
COMMIT_INFO={"compiler": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "espresso-shared": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "graal-enterprise": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "lium": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "regex": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "reporter": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "sdk": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "substratevm": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "substratevm-enterprise": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "substratevm-enterprise-gcs": {"commit.committer": "Danilo Ansaloni <danilo.ansaloni@oracle.com>", "commit.committer-ts": 1750267448, "commit.rev": "4cc47ecc8e0f2a5259b33ae3b912a2a091ab1bf2"}, "tools": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "truffle": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "truffle-enterprise": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "vm": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "vm-enterprise": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}, "wasm": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "web-image": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824302, "commit.rev": "981ecb6e1be6bf4591a6dd24b48ea053221209f5"}, "web-image-enterprise": {"commit.committer": "Marouane El Hallaoui <marouane.el.hallaoui@oracle.com>", "commit.committer-ts": 1767824303, "commit.rev": "e5b20d944dcc4662b075b4254041be1794431ca1"}}
```

</details>

## Builder Setup

<details>
<summary>Class path</summary>

```
/Users/amichne/code/kast.feature-native-query-cli/cli/build/libs/cli-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/app-server/build/libs/app-server-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/distribution/managed/build/libs/distribution-managed-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/distribution/contract/build/libs/distribution-contract-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/protocol/wire/build/libs/wire-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/protocol/registry/build/libs/registry-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/protocol/contract/build/libs/contract-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/symbol/contract/build/libs/symbol-contract-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/workspace/contract/build/libs/workspace-contract-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/code/kast.feature-native-query-cli/kernel/build/libs/kernel-0.0.3702-69-g1e3a654d3.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.modelcontextprotocol/kotlin-sdk-core-jvm/0.15.0/ca390878393c156bd4401991ec0faced637c014a/kotlin-sdk-core-jvm-0.15.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-server-cio-jvm/3.6.0/c2deec304f3ece3f24e57fe6ada9d2dcc3e905d5/ktor-server-cio-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-server-websockets-jvm/3.6.0/fa500eccff2924ee37d3a5cc1cadfcf4698a811b/ktor-server-websockets-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-server-core-jvm/3.6.0/3042adafa6a7b40c1be63abbb2a321297e6fc422/ktor-server-core-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-client-cio-jvm/3.6.0/5d90533989c1d1b9257e533a71b0c8409337ee63/ktor-client-cio-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-client-websockets-jvm/3.6.0/14759934d3f98b0b581d7101c74994c00ee2ad2/ktor-client-websockets-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-client-core-jvm/3.6.0/b0e9aa39c710d430dc358f1dfc8e271e96baeebb/ktor-client-core-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-http-cio-jvm/3.6.0/d3e902551e204d656334dc3b927d669803822812/ktor-http-cio-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-websocket-serialization-jvm/3.6.0/aaaeacd09b5b534e1dc2cc63456396f926725b24/ktor-websocket-serialization-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-serialization-jvm/3.6.0/a7c9b8688f521d726ad7a3b72e0ff70f3e55df73/ktor-serialization-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-websockets-jvm/3.6.0/5dcb20170ccba4710bf708dd2740b628e1f55858/ktor-websockets-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-network-tls-jvm/3.6.0/d8fa8a640c1f7833b93ef670b628ca8d335e9200/ktor-network-tls-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-http-jvm/3.6.0/3ae16bcdca60505e82e2e528d15a65a36feef0b7/ktor-http-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-events-jvm/3.6.0/ea771314f209eec799410ff5bac76f56c76fc487/ktor-events-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-network-jvm/3.6.0/af8b0b83b089c24b0825ebf5e4818f8ca496a09/ktor-network-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-sse-jvm/3.6.0/9d437e3da73e49701ae70f86ccc3a567486aed38/ktor-sse-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-utils-jvm/3.6.0/8ccaacf81a0d1818dcdf667d663870cc1af503b9/ktor-utils-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-serialization-core-jvm/1.11.0/c1905c9bf7452b045d5af9248835abe64ddad6bf/kotlinx-serialization-core-jvm-1.11.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-serialization-json-jvm/1.11.0/e7e045e99e56f07599bb9ccb708c2190e2af0606/kotlinx-serialization-json-jvm-1.11.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/com.github.ajalt.clikt/clikt-core-jvm/5.1.0/ecf03e3f2e70f3b22daa4a891113311bf6846fdc/clikt-jvm.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-coroutines-slf4j/1.11.0/556153d93573d016dd4e5df37e3d03d07d8d303/kotlinx-coroutines-slf4j-1.11.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-io-jvm/3.6.0/b74e79e9debe4fc37341fb3d23401d9f69c01417/ktor-io-jvm-3.6.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-coroutines-core-jvm/1.11.0/3d57dc678bd8d72a60e7adf0eca5c54e3f4f4b79/kotlinx-coroutines-core-jvm-1.11.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-reflect/2.3.21/6acc55c52691ce3fd41b20a0472f3513106521a5/kotlin-reflect-2.3.21.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-io-core-jvm/0.9.1/8c926478f17f8109e01e68adee93795c68dcad3c/kotlinx-io-core-jvm-0.9.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-collections-immutable-jvm/0.5.1/75cd0756424334b5b2d637a895fc8daf1d2dbbfa/kotlinx-collections-immutable-jvm-0.5.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/io.github.oshai/kotlin-logging-jvm/8.0.4/e6b2cc0236be77e274cec7195ab59a8d341ae888/kotlin-logging-jvm-8.0.4.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlinx/kotlinx-io-bytestring-jvm/0.9.1/7a28d93fce9fc8b663a6fe19cb2ae14a6ade7e8a/kotlinx-io-bytestring-jvm-0.9.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-stdlib/2.4.21/c343e135bd1e7dd94b7ed76b4159068d888d09db/kotlin-stdlib-2.4.21.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/com.networknt/json-schema-validator/3.0.8/89981e0d1f6798f6c2a64c399b377f18102c4ad1/json-schema-validator-3.0.8.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/ch.qos.logback/logback-classic/1.6.5/3a0959903d420ba1ca087100a34063938ac0602b/logback-classic-1.6.5.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.jetbrains/annotations/23.0.0/8cc20c07506ec18e0834947b84a864bfc094484e/annotations-23.0.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/com.ethlo.time/itu/1.14.0/c0f9f9d4f4404787e992ab3af5ae95f2fad79e47/itu-1.14.0.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/tools.jackson.core/jackson-core/3.2.1/5bff2a525073cff8a8206751f6f6bc4650b81b94/jackson-core-3.2.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/tools.jackson.dataformat/jackson-dataformat-yaml/3.2.1/2e71c35d099e8837affd1709d9dca326d58e7eab/jackson-dataformat-yaml-3.2.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/tools.jackson.core/jackson-databind/3.2.1/363dc46ceb44a97cba68cb0e9da4a3cb5bf723d4/jackson-databind-3.2.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.slf4j/slf4j-api/2.0.19/efad9817997b3a6ce9e058f92e612917a744c290/slf4j-api-2.0.19.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/ch.qos.logback/logback-core/1.6.5/821f011acaffb543404e94bc35f651b483a5a161/logback-core-1.6.5.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/com.fasterxml.jackson.core/jackson-annotations/2.22/15c67f9498d6934cff9510fc70c5a12e52290457/jackson-annotations-2.22.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/org.snakeyaml/snakeyaml-engine/3.0.1/aaa97268dd9fcf97a3e44c96e6a50961d65199dd/snakeyaml-engine-3.0.1.jar
/Users/amichne/.gradle/caches/modules-2/files-2.1/com.typesafe/config/1.4.9/fc87584fea1adcf5df899e58501a470329e59b52/config-1.4.9.jar
```

</details>

<details>
<summary>Module path</summary>

```
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/library-support.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/espresso-svm.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/native-image-base.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/objectfile.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm-enterprise.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm-foreign.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/reporter.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm-configure.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/svm-capnproto-runtime.jar
/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/builder/pointsto.jar
```

</details>

<details>
<summary>Builder arguments</summary>

```
-H:CLibraryPath=/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/clibraries/darwin-aarch64,/Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/clibraries
-H:Path@driver=/Users/amichne/code/kast.feature-native-query-cli/cli/build/native/nativeCompile
-H:ReachabilityMetadataResources@jar:file:///Users/amichne/code/kast.feature-native-query-cli/cli/build/libs/cli-0.0.3702-69-g1e3a654d3.jar!/META-INF/native-image/io.github.amichne.kast/query/reachability-metadata.json+api=META-INF/native-image/io.github.amichne.kast/query/reachability-metadata.json
-H:ReflectionConfigurationResources@jar:file:///Users/amichne/.gradle/caches/modules-2/files-2.1/io.ktor/ktor-network-jvm/3.6.0/af8b0b83b089c24b0825ebf5e4818f8ca496a09/ktor-network-jvm-3.6.0.jar!/META-INF/native-image/io.ktor/ktor-network/reflect-config.json+api=META-INF/native-image/io.ktor/ktor-network/reflect-config.json
-H:ReflectionConfigurationResources@jar:file:///Users/amichne/.gradle/caches/modules-2/files-2.1/com.networknt/json-schema-validator/3.0.8/89981e0d1f6798f6c2a64c399b377f18102c4ad1/json-schema-validator-3.0.8.jar!/META-INF/native-image/com.networknt/json-schema-validator/native-image.properties=META-INF/native-image/com.networknt/json-schema-validator/reflect-config.json
-H:ResourceConfigurationResources@jar:file:///Users/amichne/.gradle/caches/modules-2/files-2.1/com.networknt/json-schema-validator/3.0.8/89981e0d1f6798f6c2a64c399b377f18102c4ad1/json-schema-validator-3.0.8.jar!/META-INF/native-image/com.networknt/json-schema-validator/native-image.properties=META-INF/native-image/com.networknt/json-schema-validator/resource-config.json
-H:ReflectionConfigurationResources@jar:file:///Users/amichne/.gradle/caches/modules-2/files-2.1/com.networknt/json-schema-validator/3.0.8/89981e0d1f6798f6c2a64c399b377f18102c4ad1/json-schema-validator-3.0.8.jar!/META-INF/native-image/com.networknt/json-schema-validator/reflect-config.json+api=META-INF/native-image/com.networknt/json-schema-validator/reflect-config.json
-H:ResourceConfigurationResources@jar:file:///Users/amichne/.gradle/caches/modules-2/files-2.1/com.networknt/json-schema-validator/3.0.8/89981e0d1f6798f6c2a64c399b377f18102c4ad1/json-schema-validator-3.0.8.jar!/META-INF/native-image/com.networknt/json-schema-validator/resource-config.json+api=META-INF/native-image/com.networknt/json-schema-validator/resource-config.json
-H:FallbackThreshold@user+api=0
-H:Color@user+api=never
-H:Name@user+api=kast-query
-H:ConfigurationFileDirectories@user=/Users/amichne/code/kast.feature-native-query-cli/cli/build/native/generated/generateResourcesConfigFile,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlin/kotlin-stdlib/1.7.10,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains/annotations/13.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-serialization-json-jvm/1.8.1,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-serialization-core-jvm/1.9.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/com.networknt/json-schema-validator/1.5.7,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/com.ethlo.time/itu/1.10.3,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/tools.jackson.core/jackson-databind/3.0.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/com.fasterxml.jackson.core/jackson-annotations/2.3.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/tools.jackson.core/jackson-core/3.0.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/tools.jackson.dataformat/jackson-dataformat-yaml/3.1.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.snakeyaml/snakeyaml-engine/3.0.1,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.slf4j/slf4j-api/1.7.36,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-coroutines-slf4j/1.10.2,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-io-core-jvm/0.8.2,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-io-bytestring-jvm/0.8.2,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlinx/kotlinx-collections-immutable-jvm/0.4.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-server-websockets-jvm/3.4.3,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-server-core-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/com.typesafe/config/1.4.2,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-utils-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-io-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-http-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-websockets-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-events-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-http-cio-jvm/3.4.1,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-network-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/org.jetbrains.kotlin/kotlin-reflect/1.7.10,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-websocket-serialization-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.github.oshai/kotlin-logging-jvm/8.0.01,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-server-cio-jvm/3.4.3,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-client-core-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-sse-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-client-cio-jvm/3.2.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/io.ktor/ktor-network-tls-jvm/3.4.1,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/com.github.ajalt.clikt/clikt-core-jvm/5.1.0,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/ch.qos.logback/logback-classic/1.5.29,/Users/amichne/.gradle/native-build-tools/repositories/ef90b957c8f9fa0ae0ce37a65fdbaf283b81c15f/exploded/ch.qos.logback/logback-core/1.5.33
-H:FallbackThreshold@user+api=0
-H:ThrowMissingRegistrationErrors@user+api=
-H:Emit@user+api=build-report
-H:+UnlockExperimentalVMOptions@user
-H:+GenerateEmbeddedResourcesFile@user
-H:-UnlockExperimentalVMOptions@user
-H:+UnlockExperimentalVMOptions@user
-H:NativeLinkerOption@user=-mmacosx-version-min=15.0
-H:-UnlockExperimentalVMOptions@user
-H:Class@explicit main-class=io.github.amichne.kast.cli.publicshell.KastPublicCliMain
-H:ImageBuildID@driver=5fa0ddcc-7c0d-1067-0246-b2b269b9e61f
-H:Features@jar:file:///Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/library-support.jar!/META-INF/native-image/com.oracle.svm/thirdparty/native-image.properties+api=com.oracle.svm.thirdparty.gson.GsonFeature
-H:Features@jar:file:///Users/amichne/.local/share/mise/installs/java/oracle-graalvm-25.0.2/lib/svm/library-support.jar!/META-INF/native-image/com.oracle.svm/polyglot/native-image.properties+api=com.oracle.svm.polyglot.groovy.GroovyIndyInterfaceFeature,com.oracle.svm.polyglot.scala.ScalaFeature
```

</details>

<details>
<summary>Builder properties</summary>

```
-Dcom.oracle.graalvm.isaot=true
-Dgraalvm.ForcePolyglotInvalid=true
-Dgraalvm.locatorDisabled=true
-Djava.awt.headless=true
-Djava.lang.invoke.InnerClassLambdaMetafactory.initializeLambdas=false
-Djava.lang.invoke.MethodHandle.DONT_INLINE_THRESHOLD=-1
-Djava.lang.invoke.MethodHandle.PROFILE_GWT=false
-Djava.system.class.loader=com.oracle.svm.hosted.NativeImageSystemClassLoader
-Djdk.internal.lambda.disableEagerInitialization=true
-Djdk.internal.lambda.eagerlyInitialize=false
-Djdk.module.main=org.graalvm.nativeimage.builder
-Dorg.graalvm.nativeimage.imagecode=buildtime
-Dorg.graalvm.vendor=Oracle Corporation
-Dorg.graalvm.vendorurl=https://www.graalvm.org/
-Dorg.graalvm.vendorversion=Oracle GraalVM 25.0.2+10.1
-Dorg.graalvm.version=25.0.2
-Dsvm.build.memoryUsageReasonText=using available memory
-Dsvm.modulesupport.addedModules=java.rmi,java.sql,org.graalvm.collections,jdk.jdi,java.logging,java.transaction.xa,java.xml.crypto,java.xml,jdk.jfr,jdk.internal.vm.ci,java.datatransfer,org.graalvm.truffle.compiler,jdk.internal.md,java.desktop,java.naming,jdk.internal.ed,java.prefs,java.net.http,jdk.compiler,java.security.sasl,jdk.internal.opt,org.graalvm.nativeimage,jdk.zipfs,jdk.attach,java.base,jdk.management.agent,org.graalvm.word,jdk.internal.le,java.management,java.sql.rowset,jdk.unsupported,jdk.jlink,jdk.jdwp.agent,jdk.internal.jvmstat,java.instrument,java.security.jgss,jdk.management,java.compiler,java.scripting,jdk.graal.compiler,jdk.jdeps,java.management.rmi
-Dtruffle.TruffleRuntime=com.oracle.truffle.api.impl.DefaultTruffleRuntime
-Dtruffle.TrustAllTruffleRuntimeProviders=true
```

</details>

<details>
<summary>Features enabled</summary>

```
com.oracle.svm.core.IsolateListenerFeature, [com.oracle.svm.core.IsolateListenerSupportFeature]
com.oracle.svm.core.IsolateListenerSupportFeature, []
com.oracle.svm.core.MultiLayeredStaticFieldsBaseFeature, []
com.oracle.svm.core.RuntimeAssertionsSupportFeature, []
com.oracle.svm.core.StaticFieldsFeature, []
com.oracle.svm.core.SubstrateDiagnosticsFeature, []
com.oracle.svm.core.SubstrateDiagnosticsOptionsFeature, []
com.oracle.svm.core.SubstrateExitHandlerFeature, []
com.oracle.svm.core.SubstrateSegfaultHandlerFeature, [com.oracle.svm.core.IsolateListenerSupportFeature]
com.oracle.svm.core.UniqueShortNameProviderDefaultImplFeature, []
com.oracle.svm.core.UnsafeMemoryUtilFeature, []
com.oracle.svm.core.aarch64.AArch64FrameAccessFeature, []
com.oracle.svm.core.allocationprofile.AllocationProfilingFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature]
com.oracle.svm.core.bootstrap.BootstrapMethodConfiguration, []
com.oracle.svm.core.c.CIsolateDataStorageFeature, []
com.oracle.svm.core.c.CTypeConversionSupportImplFeature, []
com.oracle.svm.core.c.ProjectHeaderFileHeaderResolversRegistryFeature, []
com.oracle.svm.core.c.function.IsolateSupportImplFeature, []
com.oracle.svm.core.c.locale.LocaleSupportFeature, []
com.oracle.svm.core.code.CodeInfoFeature, [com.oracle.svm.core.util.CounterFeature]
com.oracle.svm.core.code.ImageCodeInfoStorageFeature, []
com.oracle.svm.core.code.InstalledCodeObserverSupportFeature, []
com.oracle.svm.core.code.MethodTableFirstIDTrackerFeature, []
com.oracle.svm.core.code.RuntimeMetadataDecoderImplFeature, []
com.oracle.svm.core.code.RuntimeMetadataDecoderImplMetadataAccessorImplFeature, []
com.oracle.svm.core.code.RuntimeMetadataEncodingFeature, []
com.oracle.svm.core.container.ContainerFeature, []
com.oracle.svm.core.container.OperatingSystemFeature, []
com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckFeature, []
com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImplFeature, []
com.oracle.svm.core.genscavenge.JfrGCEventFeature, []
com.oracle.svm.core.genscavenge.graal.GenScavengeGCFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature com.oracle.svm.core.jvmstat.PerfDataFeature com.oracle.svm.core.heap.AllocationFeature]
com.oracle.svm.core.graal.aarch64.AArch64NativePatchConsumerFactoryFeature, []
com.oracle.svm.core.graal.aarch64.SubstrateAArch64Feature, []
com.oracle.svm.core.graal.jdk.JDKIntrinsicsFeature, []
com.oracle.svm.core.graal.snippets.CFunctionSnippetsFeature, []
com.oracle.svm.core.graal.snippets.DeoptSnippetsFeature, []
com.oracle.svm.core.graal.snippets.ExceptionFeature, []
com.oracle.svm.core.graal.snippets.SafepointFeature, []
com.oracle.svm.core.graal.snippets.StackOverflowCheckFeature, []
com.oracle.svm.core.graal.snippets.aarch64.AArch64ArithmeticForeignCallsFeature, []
com.oracle.svm.core.graal.snippets.aarch64.AArch64SnippetsFeature, []
com.oracle.svm.core.graal.stackvalue.StackValueFeature, []
com.oracle.svm.core.handles.ObjectHandlesSupportImplFeature, []
com.oracle.svm.core.handles.PinnedPrimitiveArrayViewFeature, []
com.oracle.svm.core.heap.AllocationFeature, []
com.oracle.svm.core.heap.GCCauseFeature, []
com.oracle.svm.core.heap.GCCauseSupportFeature, []
com.oracle.svm.core.heap.HostedHeapSizeVerifierFeature, []
com.oracle.svm.core.heap.ReferenceHandlerThreadFeature, []
com.oracle.svm.core.heap.VMOperationInfosFeature, []
com.oracle.svm.core.heap.VMOperationNamesFeatures, []
com.oracle.svm.core.hub.ClassForNameSupportFeature, []
com.oracle.svm.core.hub.DynamicHubSupportFeature, []
com.oracle.svm.core.hub.LayeredReflectionMetadataSingletonFeature, []
com.oracle.svm.core.hub.registry.ClassLoadingSupportImplFeature, []
com.oracle.svm.core.hub.registry.ClassRegistriesFeature, []
com.oracle.svm.core.identityhashcode.SubstrateIdentityHashCodeFeature, []
com.oracle.svm.core.jdk.ClassValueSupportFeature, []
com.oracle.svm.core.jdk.CompletableFutureFeature, []
com.oracle.svm.core.jdk.ImageInternedStringsFeature, []
com.oracle.svm.core.jdk.InnocuousForkJoinWorkerThreadFeature, []
com.oracle.svm.core.jdk.JRTDisableFeature, []
com.oracle.svm.core.jdk.JavaNetFeature, []
com.oracle.svm.core.jdk.JavaNetHttpFeature, []
com.oracle.svm.core.jdk.NativeLibrarySupportFeature, []
com.oracle.svm.core.jdk.PlatformNativeLibrarySupportFeature, []
com.oracle.svm.core.jdk.ResourcesFeature, []
com.oracle.svm.core.jdk.RuntimeClassLoaderValueSupportFeature, []
com.oracle.svm.core.jdk.RuntimeFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature]
com.oracle.svm.core.jdk.RuntimeInternedStringsFeature, []
com.oracle.svm.core.jdk.RuntimeModuleSupportFeature, []
com.oracle.svm.core.jdk.RuntimeSupportFeature, []
com.oracle.svm.core.jdk.ServiceCatalogSupportFeature, []
com.oracle.svm.core.jdk.SignalHandlerFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature com.oracle.svm.core.IsolateListenerSupportFeature]
com.oracle.svm.core.jdk.SimpleWebServerFeature, []
com.oracle.svm.core.jdk.StringInternSupportFeature, []
com.oracle.svm.core.jdk.TimeZoneFeature, []
com.oracle.svm.core.jdk.TrustStoreManagerFeature, []
com.oracle.svm.core.jdk.URLProtocolsSupportFeature, []
com.oracle.svm.core.jdk.VectorAPISupportFeature, []
com.oracle.svm.core.jdk.buildtimeinit.FileSystemProviderBuildTimeInitFeature, []
com.oracle.svm.core.jdk.management.ManagementFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature com.oracle.svm.core.thread.ThreadListenerSupportFeature]
com.oracle.svm.core.jfr.sampler.JfrNoExecutionSamplerFeature, [com.oracle.svm.core.jfr.JfrFeature]
com.oracle.svm.core.jfr.sampler.JfrRecurringCallbackExecutionSamplerFeature, [com.oracle.svm.core.jfr.JfrFeature]
com.oracle.svm.core.jvmstat.PerfDataFeature, [com.oracle.svm.core.thread.VMOperationListenerSupportFeature com.oracle.svm.core.jdk.RuntimeSupportFeature]
com.oracle.svm.core.layeredimagesingleton.NonLayeredImageSingletonFeature, []
com.oracle.svm.core.libgraal.LibGraalRuntimeSupportImplFeature, []
com.oracle.svm.core.locks.VMLockFeature, []
com.oracle.svm.core.memory.UnmanagedMemorySupportFeature, []
com.oracle.svm.core.meta.SubstrateObjectConstantEqualityFeature, []
com.oracle.svm.core.metadata.MetadataTracerFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature]
com.oracle.svm.core.option.RuntimeOptionValidationSupportFeature, []
com.oracle.svm.core.option.RuntimeOptionsSupportImplFeature, []
com.oracle.svm.core.os.BufferedFileOperationFeature, []
com.oracle.svm.core.os.ImageHeapProviderFeature, []
com.oracle.svm.core.posix.PosixLibMSupportFeature, []
com.oracle.svm.core.posix.PosixLoadAverageSupportFeature, []
com.oracle.svm.core.posix.PosixLogHandlerFeature, []
com.oracle.svm.core.posix.PosixNativeLibraryFeature, []
com.oracle.svm.core.posix.PosixPlatformTimeUtilsFeature, []
com.oracle.svm.core.posix.PosixRawFileOperationFeature, []
com.oracle.svm.core.posix.PosixSignalHandlerFeature, [com.oracle.svm.core.jdk.RuntimeSupportFeature]
com.oracle.svm.core.posix.PosixSignalHandlerSupportFeature, []
com.oracle.svm.core.posix.PosixSubstrateSegfaultHandlerFeature, []
com.oracle.svm.core.posix.PosixVirtualMemoryProviderFeature, []
com.oracle.svm.core.posix.aarch64.AArch64DarwinUContextRegisterDumperFeature, []
com.oracle.svm.core.posix.darwin.DarwinImageSingletonsFeature, []
com.oracle.svm.core.posix.darwin.DarwinLibCSupportFeature, []
com.oracle.svm.core.posix.darwin.DarwinPhysicalMemorySupportImplFeature, []
com.oracle.svm.core.posix.darwin.DarwinProcessPropertiesSupportFeature, []
com.oracle.svm.core.posix.darwin.DarwinStackOverflowSupportFeature, []
com.oracle.svm.core.posix.darwin.DarwinSystemPropertiesFeature, []
com.oracle.svm.core.posix.darwin.DarwinThreadCpuTimeSupportFeature, []
com.oracle.svm.core.posix.darwin.DarwinTimeUtilFeature, []
com.oracle.svm.core.posix.darwin.DarwinVMLockSupportFeature, []
com.oracle.svm.core.posix.thread.PosixParkerFactoryFeature, []
com.oracle.svm.core.posix.thread.PosixPlatformThreadsFeature, []
com.oracle.svm.core.posix.thread.PosixVMThreadsFeature, []
com.oracle.svm.core.posix.thread.PosixVMThreadsPosixThreadLookupFeature, []
com.oracle.svm.core.stack.JavaFrameAnchorsFeature, []
com.oracle.svm.core.thread.ContinuationsFeature, [com.oracle.svm.core.SubstrateControlFlowIntegrityFeature]
com.oracle.svm.core.thread.JavaThreadsJavaThreadNumberSingletonFeature, []
com.oracle.svm.core.thread.SafepointFeature, []
com.oracle.svm.core.thread.ThreadListenerSupportFeature, []
com.oracle.svm.core.thread.ThreadLookupFeature, []
com.oracle.svm.core.thread.ThreadingSupportImplFeature, []
com.oracle.svm.core.thread.VMOperationControlFeature, []
com.oracle.svm.core.thread.VMOperationListenerSupportFeature, []
com.oracle.svm.core.threadlocal.VMThreadLocalInfosFeature, []
com.oracle.svm.core.util.CounterFeature, []
com.oracle.svm.core.util.HostedStringDeduplicationFeature, []
com.oracle.svm.enterprise.core.aarch64.c, []
com.oracle.svm.enterprise.core.ai, []
com.oracle.svm.enterprise.core.auximage.AuxiliaryImageHeapFeature, []
com.oracle.svm.enterprise.core.auximage.al, []
com.oracle.svm.enterprise.core.ax, []
com.oracle.svm.enterprise.core.b, []
com.oracle.svm.enterprise.core.copying.a, []
com.oracle.svm.enterprise.core.copying.e, []
com.oracle.svm.enterprise.core.copying.p, []
com.oracle.svm.enterprise.core.graal.jdk.a, []
com.oracle.svm.enterprise.core.graal.snippets.c, []
com.oracle.svm.enterprise.core.graalos.c, []
com.oracle.svm.enterprise.core.h, []
com.oracle.svm.enterprise.core.heap.a, []
com.oracle.svm.enterprise.core.heap.d, []
com.oracle.svm.enterprise.core.l, []
com.oracle.svm.enterprise.core.monitor.b, []
com.oracle.svm.enterprise.core.o, []
com.oracle.svm.enterprise.core.posix.a, [com.oracle.svm.enterprise.core.auximage.AuxiliaryImageHeapFeature]
com.oracle.svm.enterprise.core.posix.d, [com.oracle.svm.core.thread.ThreadListenerSupportFeature com.oracle.svm.core.IsolateListenerSupportFeature com.oracle.svm.core.jfr.JfrFeature]
com.oracle.svm.enterprise.core.sboutlining.g, []
com.oracle.svm.enterprise.core.sboutlining.i, [com.oracle.svm.core.util.CounterFeature]
com.oracle.svm.enterprise.core.sboutlining.l, []
com.oracle.svm.enterprise.core.stringformat.b, []
com.oracle.svm.enterprise.hosted.b, []
com.oracle.svm.enterprise.hosted.buildreport.a, []
com.oracle.svm.enterprise.hosted.code.layout.e, []
com.oracle.svm.enterprise.hosted.foreign.a, []
com.oracle.svm.enterprise.hosted.g, []
com.oracle.svm.enterprise.hosted.j, []
com.oracle.svm.enterprise.hosted.jni.a, [com.oracle.svm.hosted.jni.JNIFunctionTablesFeature com.oracle.svm.hosted.jni.JNICallWrapperFeature com.oracle.svm.hosted.jni.JNILibraryLoadFeature]
com.oracle.svm.enterprise.hosted.m, []
com.oracle.svm.enterprise.hosted.ml.features.provider.ProfileInferenceFeature, []
com.oracle.svm.enterprise.hosted.o, []
com.oracle.svm.enterprise.hosted.obfuscation.b, []
com.oracle.svm.enterprise.hosted.obfuscation.i, []
com.oracle.svm.enterprise.hosted.phases.a, []
com.oracle.svm.enterprise.hosted.profiling.features.jfr.b, [com.oracle.svm.core.thread.ThreadListenerSupportFeature]
com.oracle.svm.enterprise.hosted.sbom.q, []
com.oracle.svm.enterprise.hosted.t, []
com.oracle.svm.enterprise.profiling.b, []
com.oracle.svm.graal.RuntimeCPUFeatureRegionFeature, []
com.oracle.svm.graal.isolated.DisableSnippetCountersFeature, []
com.oracle.svm.graal.isolated.IsolateAwareObjectConstantEqualityFeature, []
com.oracle.svm.graal.meta.aarch64.AArch64RuntimeCodeInstallerPlatformHelperFeature, []
com.oracle.svm.graal.stubs.AArch64StubForeignCallsFeature, []
com.oracle.svm.hosted.AArch64CPUFeatureAccessFeature, []
com.oracle.svm.hosted.AnalyzeJavaHomeAccessFeature, []
com.oracle.svm.hosted.BuildDirectoryProviderImplFeature, []
com.oracle.svm.hosted.ClassLoaderFeature, []
com.oracle.svm.hosted.ClassNewInstanceFeature, []
com.oracle.svm.hosted.ClassPredefinitionFeature, [com.oracle.svm.hosted.reflect.ReflectionFeature]
com.oracle.svm.hosted.ClassValueFeature, []
com.oracle.svm.hosted.DumpIsolateCreationOnlyOptionsFeature, []
com.oracle.svm.hosted.FallbackFeature, []
com.oracle.svm.hosted.GlobalDataSupportImplFeature, []
com.oracle.svm.hosted.HKDFSupportFeature, []
com.oracle.svm.hosted.HostedLayeredModuleSingletonFeature, []
com.oracle.svm.hosted.HostedStaticFieldSupportImplFeature, []
com.oracle.svm.hosted.Log4ShellFeature, []
com.oracle.svm.hosted.LoggingFeature, []
com.oracle.svm.hosted.NativeSecureRandomFilesCloser, []
com.oracle.svm.hosted.ProtectionDomainFeature, []
com.oracle.svm.hosted.SecurityServicesFeature, []
com.oracle.svm.hosted.ServiceLoaderFeature, []
com.oracle.svm.hosted.SharedLayerBootLayerModulesSingletonFeature, []
com.oracle.svm.hosted.SubstrateDiagnosticFeature, []
com.oracle.svm.hosted.SystemInOutErrFeature, []
com.oracle.svm.hosted.ValidateGCOptionFeature, []
com.oracle.svm.hosted.ameta.HostedDynamicHubFeature, []
com.oracle.svm.hosted.annotation.AnnotationFeature, []
com.oracle.svm.hosted.c.CGlobalDataFeature, []
com.oracle.svm.hosted.c.CIsolateDataFeature, []
com.oracle.svm.hosted.c.function.CEntryPointSupport, []
com.oracle.svm.hosted.classinitialization.ClassInitializationFeature, []
com.oracle.svm.hosted.code.CEntryPointCallStubFeature, []
com.oracle.svm.hosted.code.CEntryPointLiteralFeature, []
com.oracle.svm.hosted.code.CFunctionLinkagesFeature, []
com.oracle.svm.hosted.code.CFunctionPointerCallStubSupportFeature, []
com.oracle.svm.hosted.code.FactoryMethodSupportFeature, []
com.oracle.svm.hosted.code.RestrictHeapAccessCalleesFeature, []
com.oracle.svm.hosted.code.RuntimeMetadataEncoderImplFactoryFeature, []
com.oracle.svm.hosted.code.SubstrateCompilationDirectivesFeature, []
com.oracle.svm.hosted.code.SubstrateLIRBackendFeature, []
com.oracle.svm.hosted.code.UninterruptibleAnnotationCheckerFeature, []
com.oracle.svm.hosted.code.aarch64.AArch64HostedPatcherFeature, []
com.oracle.svm.hosted.code.aarch64.AArch64HostedTrampolineSupportFeature, []
com.oracle.svm.hosted.fieldfolding.StaticFinalFieldFoldingFeature, []
com.oracle.svm.hosted.foreign.ForeignFunctionsFeature, []
com.oracle.svm.hosted.heap.HeapDumpFeature, []
com.oracle.svm.hosted.heap.ImageHeapCollectionFeature, []
com.oracle.svm.hosted.heap.ObservableHeapMapFeature, []
com.oracle.svm.hosted.heap.PodFeature, []
com.oracle.svm.hosted.image.DisallowedImageHeapObjectFeature, []
com.oracle.svm.hosted.image.ImageHeapFillerObjectsFeature, []
com.oracle.svm.hosted.image.MethodPointerInvalidHandlerFeature, []
com.oracle.svm.hosted.image.MethodPointerRelocationProviderFeature, []
com.oracle.svm.hosted.image.sources.SourceCacheFeature, []
com.oracle.svm.hosted.imagelayer.DynamicHubMetadataTrackingFeature, []
com.oracle.svm.hosted.imagelayer.HostedDynamicLayerInfoFeature, []
com.oracle.svm.hosted.imagelayer.LayeredImageHeapObjectAdderFeature, []
com.oracle.svm.hosted.imagelayer.LayeredStaticFieldSupportFeature, []
com.oracle.svm.hosted.jdk.AtomicFieldUpdaterFeature, []
com.oracle.svm.hosted.jdk.ForkJoinPoolFeature, []
com.oracle.svm.hosted.jdk.HostedClassLoaderPackageManagementFeature, []
com.oracle.svm.hosted.jdk.JDKInitializationFeature, []
com.oracle.svm.hosted.jdk.JDKRegistrations, []
com.oracle.svm.hosted.jdk.JNIRegistrationAttach, []
com.oracle.svm.hosted.jdk.JNIRegistrationJava, []
com.oracle.svm.hosted.jdk.JNIRegistrationJavaNet, []
com.oracle.svm.hosted.jdk.JNIRegistrationJavaNio, []
com.oracle.svm.hosted.jdk.JNIRegistrationManagementExt, []
com.oracle.svm.hosted.jdk.JNIRegistrationPrefs, []
com.oracle.svm.hosted.jdk.JNIRegistrationSupport, []
com.oracle.svm.hosted.jdk.JNIRegistrationsJavaZip, []
com.oracle.svm.hosted.jdk.VarHandleFeature, []
com.oracle.svm.hosted.jdk.localization.CharsetSubstitutionsFeature, []
com.oracle.svm.hosted.jdk.localization.LocalizationFeature, []
com.oracle.svm.hosted.jni.JNIAccessFeature, [com.oracle.svm.hosted.meta.KnownOffsetsFeature com.oracle.svm.hosted.reflect.proxy.DynamicProxyFeature com.oracle.svm.hosted.reflect.ReflectionFeature]
com.oracle.svm.hosted.jni.JNICallWrapperFeature, [com.oracle.svm.hosted.jni.JNIAccessFeature]
com.oracle.svm.hosted.jni.JNIFunctionTablesFeature, [com.oracle.svm.hosted.jni.JNIAccessFeature]
com.oracle.svm.hosted.jni.JNILibraryLoadFeature, []
com.oracle.svm.hosted.lambda.StableLambdaProxyNameFeature, []
com.oracle.svm.hosted.meta.DynamicHubOffsetsFeature, []
com.oracle.svm.hosted.meta.HostedMethodNameFactory, []
com.oracle.svm.hosted.meta.InvalidVTableEntryFeature, []
com.oracle.svm.hosted.meta.KnownOffsetsFeature, [com.oracle.svm.hosted.thread.VMThreadFeature]
com.oracle.svm.hosted.meta.MaterializedConstantFieldsFeature, []
com.oracle.svm.hosted.methodhandles.MethodHandleFeature, []
com.oracle.svm.hosted.methodhandles.StableInjectedInvokerNameFeature, []
com.oracle.svm.hosted.option.BuildTimeOptionValidationFeature, []
com.oracle.svm.hosted.option.RuntimeOptionFeature, []
com.oracle.svm.hosted.phases.CInterfaceEnumToolFeature, []
com.oracle.svm.hosted.phases.EnumSwitchFeature, []
com.oracle.svm.hosted.phases.ReduceImplicitExceptionStackTraceInformationFeature, []
com.oracle.svm.hosted.reflect.ReflectionFeature, [com.oracle.svm.core.hub.ClassForNameSupportFeature com.oracle.svm.hosted.reflect.proxy.DynamicProxyFeature]
com.oracle.svm.hosted.reflect.StaticFieldValidatorImplFeature, []
com.oracle.svm.hosted.reflect.proxy.DynamicProxyFeature, []
com.oracle.svm.hosted.reflect.proxy.StableProxyNameFeature, []
com.oracle.svm.hosted.reflect.serialize.SerializationFeature, [com.oracle.svm.hosted.reflect.ReflectionFeature com.oracle.svm.hosted.reflect.proxy.DynamicProxyFeature]
com.oracle.svm.hosted.snippets.ExceptionUnwindFeature, []
com.oracle.svm.hosted.snippets.ImplicitExceptionsFeature, []
com.oracle.svm.hosted.thread.CEntryPointFeature, []
com.oracle.svm.hosted.thread.ContinuationsHostedFeature, [com.oracle.svm.core.thread.ContinuationsFeature]
com.oracle.svm.hosted.thread.HostedJavaThreadsFeature, []
com.oracle.svm.hosted.thread.HostedJavaThreadsMetadataFeature, []
com.oracle.svm.hosted.thread.VMThreadFeature, []
com.oracle.svm.hosted.util.HostedSubstrateUtilDefaultImplFeature, []
com.oracle.svm.hosted.xml.JavaxXmlClassAndResourcesLoaderFeature, []
com.oracle.svm.thirdparty.gson.GsonFeature, []
```

</details>
