"""Ask for an output continuation without explicit retained-result selection."""
import json
from acceptance import OUT, FIELDS, command, invoke

for route in ['baseline', 'native']:
    full = json.loads((OUT / (route + '-three-symbols.stdout')).read_text())['document']
    args = command(['query'], *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152')
    for item in full['items']:
        args += ['--ref', item['ref']]
    invoke('output-continuation-' + route, route, args, policy=route == 'native')
