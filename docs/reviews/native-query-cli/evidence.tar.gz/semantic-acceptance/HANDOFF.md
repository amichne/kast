# Installed native semantic acceptance

AC08's real semantic parity cases passed. AC09's retained reads, source reads,
and independent row/evidence pagination passed; successful issued-token RESUME
remains unproved. The installed product is not size-qualified. No latency or
execution-event-count claim is made.

## Evidence

- `verified-assertions.json`: final assertions, 30 retained-read receipts, 10 source
  checks, endpoint identity, executable/manifest digests and policy digest.
- `verification-final.log`: successful final verification over 62 captured calls.
- `stage1-assertions.json`: frozen declaration/caller oracles and six rejected
  comparator mutations. Final verification adds a changed completion-model control.
- Per-call `.json`: exact argv, explicit environment, PID, process wait completion,
  host-log byte offsets, complete semantic receipts and transport records.
- Per-call `.stdout`, `.stderr`, `.stdin`, `.host.log`: untouched raw evidence.
- `OrderService.fixture.txt`, `query.json`: unchanged source and question oracles.
- `installed-native-exec.sb`: copy of the owner's policy used in 22 calls.

Run saved evidence verification, without issuing more queries:

```sh
python3 .amp/in/artifacts/native-query/semantic-acceptance/verify.py
```

Collection scripts are preserved in execution order: `acceptance.py`, `pages.py`,
`successors.py`, `policy.py`, `resume.py`, `bounded-output.py`,
`resume-control.py`, `policy-controls.py`. Each refuses to overwrite an existing
call record. They are collection records, not a reusable test framework. Issued
tokens expire; do not rerun follow-ups later and relabel stale-token rejections.

## Exact scope

Independent declarations: OrderService [17,94), submitOrder [42,92), placeOrder
[96,174). The only caller edge is placeOrder to submitOrder, occurrence [152,163),
with compiler-confirmed provenance and preserved graph/row/selector links.
Absent-name and wrong-target controls return no rows. Coverage, completion model,
selected fields, source ranges, host, epoch and saved-content basis are retained.
Fresh comparisons replace only allocated result references and row IDs, including
their linked occurrences; retained reads compare original token bytes unchanged.

All accepted live results bind host a37aac46-4b61-4426-830a-8e9186f8d464, PID 88083,
epoch 2, SAVED_PSI_COMMITTED, version 1. Endpoint and saved-source bytes stayed
unchanged. IDEA was not stopped. No Gradle, production/test edits, or personal
installation changes were performed by this verification task.

Policy-covered successful routes: query declarations/callers/negative controls,
result read for native-issued and baseline-issued results, three row pages,
two evidence pages, source read via exact reference and issued source selector,
and bounded output delivery. `result resume` ran under policy only as the
unissued-token negative control. The parent owner qualifies the policy with JVM
positive/negative descendant controls; this report does not infer launch counts.

## Failure and limits

Both clients returned identical `BUDGET_EXCEEDED`, `CALLER_TIMEOUT`,
`REQUEST_ADMISSION` rejections for an explicit 1 ms grant, but exited 6 instead
of the elapsed category. Raw files: `resume-elapsed-{baseline,native}.*`.
The native run used the execution policy. This is shared behavior, not a
native-only regression. Source inspection points to
`cli/src/main/kotlin/io/github/amichne/kast/cli/publicshell/PublicShellExit.kt:67-97`:
the envelope has neither type/boundary nor operation; operation decoding throws
and the catch classifies it as PROTOCOL. No source was changed.

Three-symbol producers with max-results 1, with and without explicit retention,
issued retained references and next_cursor, not output continuations. Minimum
4096-byte verbose caller reads returned DEFERRED_DETAIL, not a continuation.
The explicit-timeout probe failed before admission. No valid output continuation
was fabricated. `resume-unissued-*` proves identical continuation-unavailable
rejection and exit 10 only; successful RESUME remains NOT RUN.

Host records lack an inner READ_RESULT label and a transport-connection/readId
join. Each serialized captured interval contains exactly one semantic receipt.
All 30 result reads have RETENTION phase, zero entered native calls/searches,
zero declaration visits and discovery/relation pages. K2 zeroes have EXACT
qualification. Producer controls enter K2 and publish discovery pages. This
supports no producer replay at the instrumented owner, not a missing cross-ID join.

Verification attempts 1-3 are preserved. They exposed harness assumptions, not
native failures: COMPILER_REFINEMENTS is sparse (the final oracle uses explicit
EXACT K2 native-call records), pre-admission timeout has unbound correlation, and
verbose rows expand compact graph IDs. The final comparator checks expanded
identity relationships and exact cross-client verbose documents, rather than
discarding those fields. Attempt 4 and final verification passed.

There were 62 captured calls: 58 exit 0, two expected unissued-token exits 10,
and two shared timeout-classification exits 6. An earlier readiness smoke has
its own exclusion record; it is not counted as acceptance evidence.
