# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Prepare an unready SHA2 evidence configuration without any host or product call."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c


def main() -> None:
    output = HERE / "pending.json"
    c.require(not output.exists(), "preserve existing pending configuration")
    old = HERE.parents[1] / "size-waived/semantic"
    config = c.load(old / "ready-epoch2-rejection-join-fixed.json")
    final = c.load(a.FINAL)
    installed = c.load(HERE.parent / "lifecycle/installed-verification.json")
    c.require(final["members"]["bin/kast-query"] == a.PAYLOAD_SHA, "SHA2 query identity")
    c.require(
        final["members"]["share/kast/libexec/kast-management"] == a.MANAGEMENT_SHA,
        "SHA2 management identity",
    )
    c.require(final["archiveSha256"] == a.ARCHIVE_SHA, "SHA2 archive identity")
    c.require(c.digest(Path(final["archive"])) == a.ARCHIVE_SHA, "actual SHA2 archive digest")
    c.require(installed["querySha256"] == a.PAYLOAD_SHA, "installation receipt query")
    c.require(installed["commandSha256"] == a.MANAGEMENT_SHA, "installation receipt management")
    installation = Path(installed["installation"])
    home = installation.parents[3]
    c.require(str(home) == "/private/tmp/knq-lifecycle-5VGhDa/m", "expected new disposable HOME")
    native = config["routes"]["native"]
    native["command"] = str(home / ".local/bin/kast")
    native["manifest"] = str(installation / "installation.json")
    native["payload"] = str(installation / "bin/kast-query")
    native["environment"] = {"HOME": str(home), "PATH": "/usr/bin:/bin:/opt/homebrew/bin"}
    config["routes"]["baseline"]["environment"]["JAVA_TOOL_OPTIONS"] = "-Duser.home=" + str(home)
    for key in ("live", "source", "endpoint", "endpointExpected", "hostLog", "readyHostReceipt"):
        config[key] = None
    config["status"] = "PENDING_MAIN_READY_RECEIPT"
    config["authorizationScope"] = (
        "PREPARATION ONLY. No host calls, correctness run, pilot, or cohort."
    )
    config["externalLoadNotes"] = (
        "PENDING: main must confirm load and authorization at ready handoff."
    )
    config.pop("harnessAmendment", None)
    config["qualificationReceipt"] = str(a.FINAL)
    config["toolchains"] = {
        "status": "PENDING_NEW_READY_RECEIPT",
        "sourceIdentityReceipt": str(HERE.parent / "source-identity.json"),
        "candidateDiffReceipt": str(HERE.parent / "candidate.diff"),
    }
    config["artifactCosts"] = {
        key: final[key] for key in ("archiveBytes", "regularFileBytes", "regularFiles", "entries")
    }
    config["executionEvidence"] = {
        "status": "NOT RUN",
        "mechanism": "fresh exact JVM controls required",
    }
    paths = [
        a.FINAL,
        Path(final["archive"]),
        HERE.parent / "source-identity.json",
        HERE.parent / "candidate.diff",
        HERE.parent / "product-gate.log",
        HERE.parent / "lifecycle/installed-verification.json",
        HERE / "acceptance.py",
        HERE / "acceptance.py.lock",
        HERE / "mcp_check.py",
        HERE / "mcp_check.py.lock",
        Path(config["mcpPython"]),
        Path(c.__file__),
    ]
    config["identities"] = {str(path): c.digest(path) for path in paths}
    config["pendingRequirements"] = [
        "Main-authorized ready receipt with exact PID/start/UUID, endpoint and complete stable live basis",
        "New fixture source path and unchanged independent source digest",
        "Complete fresh baseline/native installed identities, configurations and absolute copied JBR identity",
        "Pin readiness probes and receipt; reconcile all proposed paths against that receipt",
        "Correctness and MCP only; later measurement requires a separate IDEA lifetime and fresh token",
    ]
    c.save(output, config)
    try:
        a.preflight(config)
    except ValueError as error:
        c.require(str(error) == "main ready identity not supplied", "pending rejection boundary")
    else:
        raise ValueError("pending configuration admitted")
    print(
        "PASS pending SHA2 configuration saved; authorization rejected before host preflight; product calls: 0"
    )


if __name__ == "__main__":
    main()
