# SHA2 native metadata qualification

Use this bundle to repeat the local metadata, admission, and resource checks against an explicitly authorized native executable. It does not qualify installed semantic operations or performance.

## Recorded result

- Executable: `cli/build/native/nativeCompile/kast-query`, 63,354,520 bytes.
- SHA-256: `c33d63944d9335109693dee494533ef60f2f8e91165aaf34941043573ba5a04a`; checked before and after execution.
- Native cases: **158/158 PASS**, zero timeouts, zero unexpected stderr streams.
- Each catalog's `query.plan` output schema: 35 definitions and 316 resolved local references. Recursive definitions are checked without expanding cycles.
- NetworkNT 3.0.8, Draft 2020-12: **99/99 PASS**, comprising 95 accepted documents and four rejected controls. Controls change the plan basis or nested request name in each catalog. Accepted documents include valid rejection envelopes, not only planned outcomes.
- Owned resources: **37/37 PASS** within 263 embedded-report entries. Each has one present entry, the expected origin JAR name, query metadata registration origin, size, and origin-resource SHA-256.
- Processed properties match the preserved bytes: `ideBuild=262.10315.125` and `kotlinPluginBuild=262.10315.125-IJ`.
- All 158 native children ran with `-XX:MissingRegistrationReportingMode=Exit`, network and file-write denial, an empty disposable HOME, and `PATH=/nonexistent`. All 158 filesystem snapshots were unchanged. The metadata case with open stdin exited without EOF.

`run-001/summary.json` owns the aggregate result. Per-case command JSON records contain argv, cwd, environment, expected/actual exit, timeout, open-stdin, and unchanged-files observations. Separate files preserve raw stdin, stdout, and stderr. File-request bytes are in `cases.json`; their corresponding stdin-request cases preserve the same bytes. `run-001/identity.json` records executable, driver, lock, fixture, report, and validator digests.

The validator log retains NetworkNT's existing warning about the unknown `discriminator` keyword. Validation still enforces the generated `anyOf` branches; all four negative controls failed validation as required. No validator rules were changed.

The resource report contains names, origins, and sizes, not embedded-byte hashes. Resource hashes are read from origin JARs and linked to the embedding report; this is not an independent dump of executable resource bytes.

## Reproduction

The exact successful command is in `commands.txt`. Run it from the repository root with the same artifact, reports, Java 25 executable, and installed JVM library directory. Select a fresh `--output` directory for another run; the driver refuses to overwrite evidence. A different artifact requires its independently authorized SHA-256. No Gradle task is invoked.

`matrix-driver.tar.gz` contains the driver, its uv lock, Java validator source, immutable case inputs, expected resource inventory, processed properties, 99-control inventory, checker configuration, and these instructions. It does not contain the product executable or JVM dependencies. Origin JAR paths are read from the selected build report; the JVM classpath must contain `json-schema-validator-3.0.8.jar` and its normal dependencies. The reproduction host must provide macOS `sandbox-exec` and uv 0.12.9 or newer.

## Recovery limits and preparation checks

The original temporary Python driver, Java helper, and any original uv lock were unavailable. This is a **reconstruction**, not a byte-for-byte recovery. All 158 argv vectors and request bytes were recovered from immutable `size-waived/metadata-native` evidence. File-request paths are relocated into a disposable directory. `reconstruction.json` records the source log and case-manifest digests.

Expected exits are independently classified: valid RUN plans succeed; retained, source-read, and resume inputs are not RUN plans; malformed inputs and unsupported common-catalog flags reject. The reconstruction cross-checks these expectations against historical `EXPECTED` fields, never new `ACTUAL` fields. Rejection assertions preserve `RUN_REQUIRED`, `INVALID_COMMAND`, and `INVALID_ARGUMENTS` separately. Source owners are `QueryCostPlan.kt` and public-shell argument/lowering code. The new locked script preserves these explicit checks rather than deriving an oracle from candidate output.

Preparation passed Ruff formatting/lint, strict Pyright, three harness self-tests, and output assertions over all 158 historical cases. Those historical assertions were not a new executable run. Initial preparation failures are retained: test assertions inherited an unrelated parent lint rule, and the first reconstruction incorrectly conflated three rejection variants. The final checker permits assertions only for this test harness, refuses optimized Python, and distinguishes all three variants. The successful native execution occurred only after final digest authorization.

No production source, build configuration, native artifact, installation, or shared host was changed. Older evidence was only read. No performance or installed acceptance claim follows from these checks. Automated prose assessment was not run for this local evidence note.
