"""Independent saved-source, token, page, host-work and cross-client assertions."""
import copy
import hashlib
import json
from acceptance import OUT, SOURCE, HOST, ENDPOINT, ROOT, declaration, caller, normalized, save

def load(name):
    return json.loads((OUT / (name + '.stdout')).read_text())

source = SOURCE.read_text()
assert hashlib.sha256(source.encode()).hexdigest() == 'c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859'
live = {'root': str(SOURCE.parents[4]), 'host': HOST, 'epoch': 2, 'contentView': 'SAVED_PSI_COMMITTED', 'version': 1}
source_cases = []
read_cases = []
all_records = []
for path in sorted(OUT.glob('*.json')):
    record = json.loads(path.read_text())
    if 'argv' not in record:
        continue
    all_records.append(record)
    name = path.stem
    result = load(name)
    d = result.get('document', {})
    assert record['reapedBeforeNextInvocation']
    assert len(record['semantic']) == 1, (name, 'ambiguous host interval')
    semantic = record['semantic'][0]
    assert semantic['pid'] == 88083
    if d.get('stage') == 'REQUEST_ADMISSION' and d.get('failure') == 'BUDGET_EXCEEDED':
        # The separately reported timeout classification failure occurs before live-basis admission.
        assert d['detail'] == {'cause': 'CALLER_TIMEOUT'}
        assert semantic['correlation'] == {'type': 'unbound'}
        assert record['exitCode'] == 6
    else:
        assert semantic['correlation']['host'] == HOST
        assert semantic['correlation']['epoch'] == 2
    if d.get('operation') == 'source.read':
        assert record['exitCode'] == 0 and result['type'] == 'complete'
        assert d['live'] == live and d['snapshot']['live'] == live
        assert d['snapshot']['file'] == str(SOURCE)
        assert d['snapshot']['canonicalRoot'] == live['root']
        assert d['snapshot']['length'] == 175
        assert d['snapshot']['coordinateUnit'] == 'utf16-code-unit'
        assert d['snapshot']['textIdentity'] == 'intellij-document-utf16be-sha256-v1|' + hashlib.sha256(source.encode('utf-16-be')).hexdigest()
        assert d['region']['selection']['range'] == {'startInclusive': 17, 'endExclusive': 94}
        assert d['text']['selection'] == d['region']['selection']
        assert d['text']['text'] == source[17:94]
        assert d['text']['lines'] == {'startInclusive': 3, 'endInclusive': 5}
        if name.endswith('source-selector'):
            assert record['argv'][record['argv'].index('--ref') + 1] == d['region']['selection']['selector']
        source_cases.append(name)
    if 'result' in record['argv'] and 'read' in record['argv']:
        assert record['exitCode'] == 0
        assert d['retention']['reference'] == record['argv'][record['argv'].index('--ref') + 1]
        assert d['live'] == live
        assert d['coverage'] == {'exhaustive': True}
        assert d['question']['completion'] == {'type': 'COMPLETE_ONLY', 'model': 'COMPILER_RESOLVED_STATIC_V1'}
        assert semantic['nativePhase'] == {'type': 'entered', 'phase': 'RETENTION'}
        assert all(call['entered'] == 0 for call in semantic['nativeCalls']), name
        assert all(search['entered'] == 0 for search in semantic['nativeSearches']), name
        k2_calls = [call for call in semantic['nativeCalls'] if call['call'] == 'K2_ANALYSIS']
        assert k2_calls and all(call['qualification'] == 'EXACT' and call['entered'] == 0 for call in k2_calls)
        counters = {c['counter']: c['count'] for c in semantic['counters']}
        # COMPILER_REFINEMENTS is sparsely emitted; its absence is not counted as zero.
        # The complete K2 native-call observations above provide the compiler-entry evidence instead.
        for counter in ['DECLARATION_PSI_NODES_VISITED', 'NATIVE_DISCOVERY_PAGES', 'NATIVE_RELATION_PAGES']:
            assert counters[counter] == 0, (name, counter)
        assert semantic['discoveryPages']['published'] == 0
        read_cases.append({'name': name, 'readId': semantic['readId'], 'producerNativeCalls': 0, 'discoveryPages': 0, 'reference': d['retention']['reference']})

for route in ['baseline', 'native']:
    full = load(route + '-three-symbols')['document']
    oracle = {'OrderService': ('example.OrderService', 17, 94), 'submitOrder': ('example.OrderService.submitOrder', 42, 92), 'placeOrder': ('example.placeOrder', 96, 174)}
    assert len(full['items']) == 3
    for item in full['items']:
        identity, start, end = oracle[item['name']]
        assert item['signature']['qualifiedIdentity'] == identity
        assert item['location'] == {'file': str(SOURCE), 'range': {'startInclusive': start, 'endExclusive': end}}
    for prefix in ([route + '-issued-baseline', route + '-issued-native', 'policy-' + route + '-issued'] if route == 'baseline' else [route + '-issued-native', 'policy-' + route + '-issued']):
        pages = [load(prefix + '-row-page' + str(i))['document'] for i in range(3)]
        assert [item for page in pages for item in page['items']] == full['items']
        for index, page in enumerate(pages):
            assert page['retention'] == full['retention']
            assert page['row_window'] == {'type': 'MORE' if index < 2 else 'FINAL', 'start': index, 'end': index + 1, 'total': 3}
            assert page['evidence_window'] == {'type': 'FINAL', 'start': 0, 'end': 0, 'total': 0}
            assert page['page_progress']['rows'] == 1
            assert page.get('next_cursor') == (index + 1 if index < 2 else None)

for prefix, producer in [('baseline-issued-baseline', 'baseline-callers'), ('baseline-issued-native', 'baseline-callers'), ('native-issued-native', 'native-callers'), ('policy-native-issued', 'policy-callers')]:
    original = load(producer)['document']
    first, last = [load(prefix + '-evidence-page' + str(i))['document'] for i in [0, 1]]
    # --verbose expands compact graph IDs into their complete connection records.
    assert len(first['items']) == 1 and last['items'] == []
    row, compact = first['items'][0], original['items'][0]
    for field in ['row_id', 'name', 'kind', 'signature', 'location']:
        assert row[field] == compact[field]
    nodes = {node['id']: node['symbol'] for node in original['relation_graph']['nodes']}
    assert row['ref'] == nodes[compact['node']]['selector']
    assert len(row['connections']) == 1
    edge = row['connections'][0]
    witness = original['relation_graph']['connection_witnesses'][0]
    assert edge['source']['selector'] == nodes[witness['source']]['selector']
    assert edge['target']['selector'] == nodes[witness['target']]['selector']
    assert edge['source']['qualifiedIdentity'] == 'example.placeOrder'
    assert edge['target']['qualifiedIdentity'] == 'example.OrderService.submitOrder'
    assert edge['occurrence'] == witness['occurrence']
    assert edge['meaning'] == 'callers' and edge['coverage'] == 'exact-compiler-confirmed'
    assert edge['provenance'] == 'k2-authored-source'
    assert first['evidence_window'] == {'type': 'MORE', 'start': 0, 'end': 1, 'total': 2}
    assert last['evidence_window'] == {'type': 'FINAL', 'start': 1, 'end': 2, 'total': 2}
    assert last['row_window'] == {'type': 'FINAL', 'start': 1, 'end': 1, 'total': 1}
    assert first['page_progress']['relation_evidence'] == 0
    assert last['page_progress']['relation_evidence'] == 1
    assert last['relation_observations'] == original['relation_observations']
    assert first['relation_observations'] == [] and len(first['discovery_observations']) == 1
    assert first['discovery_observations'][0]['universe'] == original['discovery_observations'][0]['universe']
    assert first['discovery_observations'][0]['progress'] == {'kind': 'exhausted'}
    assert last['discovery_observations'] == []
    for page in [first, last]:
        assert page['retention'] == original['retention']
        assert page['original_evidence_summary'] == original['original_evidence_summary']

for suffix in ['read', 'source', 'source-selector', 'row-page0', 'row-page1', 'row-page2', 'evidence-page0', 'evidence-page1']:
    assert load('baseline-issued-baseline-' + suffix) == load('baseline-issued-native-' + suffix), suffix
assert load('baseline-issued-baseline-source') == load('native-issued-native-source')
assert normalized(load('baseline-three-symbols')) == normalized(load('native-three-symbols'))
for case in ['declaration', 'callers', 'absent-name', 'wrong-target']:
    assert normalized(load('policy-' + case)) == normalized(load('baseline-' + case))
for name in ['baseline-declaration', 'native-declaration', 'policy-declaration']:
    receipt = json.loads((OUT / (name + '.json')).read_text())['semantic'][0]
    assert any(call['call'] == 'K2_ANALYSIS' and call['entered'] > 0 for call in receipt['nativeCalls'])
    assert receipt['discoveryPages']['published'] > 0
bad = copy.deepcopy(load('native-declaration'))
bad['document']['question']['completion']['model'] = 'NOT_COMPILER_RESOLVED'
try:
    declaration(bad)
except AssertionError:
    completion_control = 'REJECTED'
else:
    raise AssertionError('Independent comparator accepted changed completion model')

assert json.loads(ENDPOINT.read_text()) == json.loads((OUT / 'endpoint-before.json').read_text())
digests = {}
for relative in ['n/.local/share/kast/installation/bin/kast-query', 'n/.local/bin/kast', 'b/.local/bin/kast', 'n/.local/share/kast/installation/installation.json', 'b/.local/share/kast/installation/installation.json']:
    file = ROOT / relative
    digests[str(file)] = {'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'bytes': file.stat().st_size}
assert digests[str(ROOT / 'n/.local/share/kast/installation/bin/kast-query')]['sha256'] == '70d3cbbe07bc3955fbd23414e02c2d40c6cd3de3a57ca2b6afda43d44e8d23f8'
save('verified-assertions.json', {
    'sourceChecks': source_cases, 'retainedNoProducerReplay': read_cases,
    'rowPagination': 'PASS: three exact rows across three processes per reader, unchanged row IDs',
    'evidencePagination': 'PASS: independent evidence [0,1), [1,2), second page zero rows',
    'baselineIssuedExactCrossClientDocuments': 'PASS: eight read/source/page forms',
    'completionMutationControl': completion_control,
    'host': json.loads(ENDPOINT.read_text()), 'digests': digests,
    'policySha256': hashlib.sha256((OUT.parent / 'installed-native-exec.sb').read_bytes()).hexdigest(),
    'producerMeasurementPositiveControls': 'PASS: baseline/native/policy declarations enter K2 and publish discovery pages',
    'runs': len(all_records), 'policyRuns': sum(r['argv'][0] == '/usr/bin/sandbox-exec' for r in all_records),
    'logLimit': 'Host records do not expose inner READ_RESULT tag or transport-connection to readId link. Sequential captured invocation intervals each contain exactly one semantic read, whose complete native-call/search/counter arrays distinguish RETENTION from producers.',
    'resumeLimit': 'Only unissued-token RESUME rejection exercised; no successful issued output continuation was obtained.',
    'sharedFailure': 'Both clients exit 6 for explicit 1ms CALLER_TIMEOUT at REQUEST_ADMISSION; not a native-only regression.',
    'sizeQualification': 'NOT QUALIFIED; no latency or execution-event-count claim',
})
print('PASS', len(source_cases), 'source cases;', len(read_cases), 'READ_RESULT cases;', len(all_records), 'recorded runs')
