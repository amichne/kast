"""Same installed semantic routes under the owner's exact execution allowlist."""
import json
from acceptance import OUT, REPO, FIELDS, GRANTS, command, invoke, declaration, caller, normalized, save

def load(name):
    return json.loads((OUT / (name + '.stdout')).read_text())

def native(name, args, request=b''):
    return invoke('policy-' + name, 'native', args, request, policy=True)

request = (REPO / 'docs/reviews/public-cli-v1/query.json').read_bytes()
original, record = native('declaration', command(['query'], '--request', '-'), request)
assert record['exitCode'] == 0
declaration(original)
assert normalized(original) == normalized(load('baseline-declaration'))
c, record = native('callers', command(['query'], '--name', 'submitOrder', '--relation', 'callers', *FIELDS, *GRANTS, '--retain'))
assert record['exitCode'] == 0
caller(c)
assert normalized(c) == normalized(load('baseline-callers'))
for issuer, producer in [('native', original), ('baseline', load('baseline-declaration'))]:
    d = producer['document']
    read, r = native(issuer + '-issued-read', command(['result', 'read'], '--ref', d['retention']['reference'], *FIELDS, *GRANTS))
    assert r['exitCode'] == 0
    assert read['document']['items'] == d['items'] and read['document']['live'] == d['live']
    assert read['document']['retention'] == d['retention']
    source, r = native(issuer + '-issued-source', command(['source', 'read'], '--ref', d['items'][0]['ref']))
    assert r['exitCode'] == 0
    selector = source['document']['region']['selection']['selector']
    native(issuer + '-issued-source-selector', command(['source', 'read'], '--ref', selector))
    full = load(issuer + '-three-symbols')['document']
    for index in [0, 1, 2]:
        page, r = native(issuer + '-issued-row-page' + str(index), command(['result', 'read'], '--ref', full['retention']['reference'], '--cursor', str(index), '--evidence-cursor', '0', *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152'))
        assert r['exitCode'] == 0 and page['document']['items'] == full['items'][index:index+1]
for index in [0, 1]:
    native('native-issued-evidence-page' + str(index), command(['result', 'read'], '--ref', c['document']['retention']['reference'], '--cursor', str(index), '--evidence-cursor', str(index), *FIELDS, '--max-results', '1', '--max-returned-bytes', '49152', '--verbose'))
for route in ['baseline', 'native']:
    invoke('resume-elapsed-' + route, route, command(['query'], '--name', 'OrderService', *FIELDS, *GRANTS, '--max-elapsed-ms', '1', '--retain'), policy=route == 'native')
save('policy-stage-assertions.json', {'declarationAndCallerParity': 'PASS', 'exactNativeAndBaselineIssuedReads': 'PASS', 'rowReads': 'PASS', 'sourceAndEvidenceDetailedAssertions': 'PENDING', 'resume': 'AWAITING_ISSUED_CONTINUATION', 'mechanism': 'enforced process-exec allowlist; not event counting'})
