#!/usr/bin/env -S uv run --locked --script
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = ["pytest==8.4.2"]
# [tool.uv]
# no-build = true
# [[tool.uv.index]]
# name = "pypi"
# url = "https://pypi.org/simple"
# default = true
# ///
"""Own/reap one disposable real worker; never run before collection release."""

from __future__ import annotations

import argparse
import hashlib
import json
import signal
import stat
import subprocess
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import cast

type Json = bool | int | float | str | list[Json] | dict[str, Json] | None
ROOT = Path("/private/tmp/knq-lifecycle-5VGhDa")
HERE = Path(__file__).resolve().parent
NATIVE = "7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0"
JAVA_QUERY = "d900861b69aa77c80dce1c2bfba3d40340ca40f370fb8a297729cb43244708c2"
JBR = ROOT / "Owned IDEA.app/Contents/jbr/Contents/Home"


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def object_value(value: Json) -> dict[str, Json]:
    require(isinstance(value, dict), "JSON object required")
    return cast(dict[str, Json], value)


def read_object(path: Path) -> dict[str, Json]:
    return object_value(cast(Json, json.loads(path.read_text())))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: object) -> None:
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def manifest_check(home: Path, query_sha: str) -> dict[str, Json]:
    installation = home / ".local/share/kast/installation"
    manifest = installation / "installation.json"
    document = read_object(manifest)
    require(document["installationRoot"] == str(installation), "manifest root mismatch")
    entries = document["payloadFiles"]
    require(isinstance(entries, list) and bool(entries), "payload inventory required")
    for raw in cast(list[Json], entries):
        entry = object_value(raw)
        relative = entry["path"]
        require(isinstance(relative, str), "payload path required")
        path = installation / cast(str, relative)
        require(path.is_relative_to(installation), "payload outside installation")
        require(path.resolve() == path, "payload alias rejected")
        attributes = path.lstat()
        require(stat.S_ISREG(attributes.st_mode), "payload not regular")
        require(stat.S_IMODE(attributes.st_mode) == entry["mode"], "payload mode mismatch")
        require("sha256:" + digest(path) == entry["sha256"], "payload digest mismatch")
    require(digest(installation / "bin/kast-query") == query_sha, "query artifact mismatch")
    receipt = home / ".local/share/kast/management.json"
    management = read_object(receipt)
    command = home / ".local/bin/kast"
    require(management["executable"] == str(command), "public command path mismatch")
    require(management["executableSha256"] == digest(command), "public receipt mismatch")
    return {
        "installation": str(installation),
        "manifestSha256": digest(manifest),
        "receiptSha256": digest(receipt),
        "commandSha256": digest(command),
        "querySha256": query_sha,
        "checkedFiles": len(cast(list[Json], entries)),
        "payloadIdentity": document["payloadIdentity"],
    }


@dataclass(frozen=True)
class Launch:
    command: list[str]
    environment: dict[str, str]
    directory: str
    home: str


def launch_for(mode: str) -> Launch:
    require(mode in {"native", "jvm", "reset"}, "unknown worker mode")
    home = ROOT / ("r" if mode == "reset" else "h")
    installation = home / ".local/share/kast/installation"
    environment = {"HOME": str(home), "PATH": "/usr/bin:/bin:/opt/homebrew/bin"}
    if mode == "jvm":
        command = [str(installation / "bin/kast-tool-rpc"), "--catalog=COMPLETE", "query-session"]
        environment |= {"JAVA_HOME": str(JBR), "JAVA_TOOL_OPTIONS": "-Duser.home=" + str(home)}
    elif mode == "native":
        command = [
            str(installation / "bin/kast-query"),
            "query",
            "--catalog",
            "complete",
            "--workspace",
            str(ROOT / "workspace"),
            "--name",
            "OrderService",
        ]
    else:
        # Input parsing precedes installation composition. No record or host call is claimed.
        command = [str(installation / "bin/kast-query"), "query", "--request", "-"]
    return Launch(command, environment, str(ROOT / "workspace"), str(home))


def ps(pid: int, field: str) -> str:
    return subprocess.check_output(
        ["/bin/ps", "-p", str(pid), "-o", field + "="], text=True
    ).strip()


def check_record(record: dict[str, Json], pid: int, started: str) -> None:
    require(
        record.get("schemaVersion") == 1 and record.get("pid") == pid, "record identity mismatch"
    )
    milliseconds = record.get("startEpochMillis")
    require(isinstance(milliseconds, int) and milliseconds > 0, "record start unavailable")
    expected = datetime.fromtimestamp(cast(int, milliseconds) / 1000).strftime(
        "%a %b %d %H:%M:%S %Y"
    )
    require(expected.split() == started.split(), "record and OS start second disagree")


def invocation_record(child: subprocess.Popen[bytes], home: Path) -> tuple[Path, dict[str, Json]]:
    directory = home / ".local/share/kast/installation/state/run/one-shot"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        require(
            child.poll() is None, "worker exited before its real invocation record was captured"
        )
        for path in directory.glob("*.json"):
            try:
                record = read_object(path)
            except (FileNotFoundError, json.JSONDecodeError):
                continue
            if record.get("pid") == child.pid:
                check_record(record, child.pid, ps(child.pid, "lstart"))
                return path, record
        time.sleep(0.001)
    raise ValueError("real invocation record not observed within capture budget")


def hold(mode: str, output: Path) -> None:
    require(
        output.parent.resolve() == HERE and not output.exists(),
        "use a new direct child of the evidence directory",
    )
    launch = launch_for(mode)
    checked = manifest_check(Path(launch.home), JAVA_QUERY if mode == "jvm" else NATIVE)
    output.mkdir()
    save(output / "manifest-before.json", checked)
    save(output / "command.json", asdict(launch))
    with (output / "stdout").open("xb") as stdout, (output / "stderr").open("xb") as stderr:
        child = subprocess.Popen(
            launch.command,
            env=launch.environment,
            cwd=launch.directory,
            stdin=subprocess.PIPE,
            stdout=stdout,
            stderr=stderr,
        )
        cleanup = False
        try:
            if mode == "reset":
                record_path, record = None, None
            else:
                record_path, record = invocation_record(child, Path(launch.home))
                if mode == "native":
                    child.send_signal(signal.SIGSTOP)
                    deadline = time.monotonic() + 2
                    while "T" not in ps(child.pid, "state") and time.monotonic() < deadline:
                        time.sleep(0.001)
                    require("T" in ps(child.pid, "state"), "worker was not suspended")
                save(output / "product-record.json", record)
            expected_executable = str(JBR / "bin/java") if mode == "jvm" else launch.command[0]
            require(ps(child.pid, "comm") == expected_executable, "live executable mismatch")
            save(
                output / "held.json",
                {
                    "pid": child.pid,
                    "processStart": ps(child.pid, "lstart"),
                    "command": ps(child.pid, "comm"),
                    "arguments": ps(child.pid, "args"),
                    "recordPath": None if record_path is None else str(record_path),
                    "record": record,
                    "mode": mode,
                    "claim": "REAL_INVOCATION_HELD"
                    if record is not None
                    else "REAL_NATIVE_PRE_ADMISSION_STDIN_WAIT",
                },
            )
            print(
                f"state: HELD\npid: {child.pid}\nreceipt: {json.dumps(str(output / 'held.json'))}",
                flush=True,
            )
            released = False
            while child.poll() is None:
                if not released and (output / "release-worker").exists():
                    if mode == "native":
                        child.send_signal(signal.SIGCONT)
                    else:
                        require(child.stdin is not None, "stdin owner missing")
                        if child.stdin is not None:
                            child.stdin.close()
                    released = True
                time.sleep(0.05)
        except Exception as failure:
            save(output / "failure.json", {"state": "FAILED_PILOT", "reason": str(failure)})
            raise
        finally:
            if child.poll() is None:
                cleanup = True
                child.kill()
            code = child.wait()
            if child.stdin is not None and not child.stdin.closed:
                child.stdin.close()
            save(
                output / "reaped.json",
                {
                    "pid": child.pid,
                    "exitCode": code,
                    "harnessCleanup": cleanup,
                    "claim": "CLEANUP_NOT_PRODUCT_RETIREMENT"
                    if cleanup
                    else "CHILD_EXIT_OBSERVED_AND_REAPED",
                },
            )


def test_worker_commands_keep_spaces_and_explicit_home() -> None:
    launch = launch_for("jvm")
    require(launch.environment["JAVA_TOOL_OPTIONS"] == "-Duser.home=" + str(ROOT / "h"), "JVM home")
    require(launch.command[-2:] == ["--catalog=COMPLETE", "query-session"], "JVM argument array")
    require("Owned IDEA.app" in launch.environment["JAVA_HOME"], "copied JBR path with spaces")
    require("JAVA_TOOL_OPTIONS" not in launch_for("native").environment, "native has no JVM flags")
    require(launch_for("reset").command[-2:] == ["--request", "-"], "reset waits on real stdin")


def test_record_requires_matching_pid_and_real_start() -> None:
    import pytest

    with pytest.raises(ValueError, match="identity"):
        check_record({"schemaVersion": 1, "pid": 12, "startEpochMillis": 1000}, 13, "unused")
    with pytest.raises(ValueError, match="start"):
        check_record({"schemaVersion": 1, "pid": 12, "startEpochMillis": 0}, 12, "unused")


def test_rollback_plan_requests_frozen_baseline_before_retirement() -> None:
    document = read_object(HERE / "validation-plan.json")
    sequence = document["sequence"]
    require(isinstance(sequence, list), "case sequence required")
    cases = [object_value(value) for value in cast(list[Json], sequence)]
    names = [case["case"] for case in cases]
    first = names.index("mixed-version-rollback-attempt-1-live-native")
    second = names.index("mixed-version-rollback-attempt-2-after-settlement")
    require(
        names.index("native-status")
        < first
        < names.index("ordinary-stop-does-not-kill-unsettled-native-worker")
        < names.index("current-owner-retires-native-before-rollback")
        < names.index("host-settlement-separate-from-request-retirement")
        < second,
        "rollback must first reach live-native fencing, then retry after separate settlements",
    )
    for field in ("command", "directory", "environment"):
        require(cases[first][field] == cases[second][field], "rollback inputs must be identical")
    require(
        cases[first]["command"]
        == [
            "/bin/bash",
            "/Users/amichne/code/kast.feature-native-query-baseline/install.sh",
            "--idea-home",
            str(ROOT / "Owned IDEA.app/Contents"),
            "--skip-codex-plugin",
            "--verbose",
        ],
        "rollback must use the actual frozen-baseline installer without force",
    )
    environment = object_value(cases[first]["environment"])
    require(
        environment["KAST_INSTALL_ASSETS_DIRECTORY"] == str(ROOT / "assets-baseline")
        and environment["HOME"] == str(ROOT / "h"),
        "rollback must target the live candidate home with frozen baseline assets",
    )
    require(
        cases[first]["evidenceSubdirectory"] != cases[second]["evidenceSubdirectory"],
        "preserve both rollback attempts independently",
    )
    require(
        cases[first]["expectedCurrentOwner"]
        == {
            "type": "REJECTED",
            "operation": "STOP",
            "stage": "REQUESTS",
            "failure": "REQUESTS_DID_NOT_RETIRE",
        },
        "an unrelated installer failure cannot prove current-owner request fencing",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["native", "jvm", "reset"])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--authorize-after-collection", action="store_true")
    parser.add_argument("--check", choices=["candidate", "baseline", "restored", "reset"])
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        import pytest

        return int(pytest.main([str(Path(__file__)), "-q", "-p", "no:cacheprovider"]))
    if args.check:
        home = (
            ROOT
            / {"candidate": "h", "baseline": "baseline-home", "restored": "h", "reset": "r"}[
                args.check
            ]
        )
        checked = manifest_check(
            home, JAVA_QUERY if args.check in {"baseline", "restored"} else NATIVE
        )
        print("state: VERIFIED\ncheckedFiles: " + str(checked["checkedFiles"]))
        return 0
    if args.mode is None:
        print("state: PREPARED_NOT_RUN\nreleaseRequired: true")
        return 0
    if not args.authorize_after_collection or args.output is None:
        parser.error(
            "worker launch requires --authorize-after-collection and a fresh --output directory"
        )
    hold(args.mode, args.output)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, subprocess.SubprocessError) as failure:
        print("state: FAILED\nreason: " + json.dumps(str(failure)))
        raise SystemExit(1) from failure
