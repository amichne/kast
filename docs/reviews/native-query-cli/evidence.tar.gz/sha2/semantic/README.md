# SHA2 correctness preparation

Status: PREPARED, NOT AUTHORIZED TO RUN.
No product or host calls, builds, installations, or IDEA setup ran during preparation.
All new files are under this semantic evidence directory.
Old acceptance results and the shared corrected collector remain unchanged.

## Bound artifacts

- Query: `c33d63944d9335109693dee494533ef60f2f8e91165aaf34941043573ba5a04a`.
- Management: `021549d488ce6c344350997f3b90a7248fcd159e7ae0baa2894e69b89e50ae1e`.
- Archive: `4f70df81f0a1bded029201329400ba02118f957b2e7fea40a4a7d90a142c9597`.
- Acceptance script: `2c0b78da09c64b1b2e054d4f542ee561e0f3ba5b3680967e8dfcbde4d8c8c1e3`.
- Shared collector: `e65318dec10295f4b5a240d410598e4899ba97aaab29f833bad7d53db51edc02`.

`pending.json` pins the SHA2 artifact, source, diff, product-gate, helper, and Python runtime identities.
The archive bytes match the expected digest.
The installation receipt names the new candidate home `/private/tmp/knq-lifecycle-5VGhDa/m`.
Native HOME and baseline `JAVA_TOOL_OPTIONS=-Duser.home=/private/tmp/knq-lifecycle-5VGhDa/m` use that home.
Baseline HOME and the absolute copied JBR path remain proposed paths until the ready receipt confirms them.
Host UUID, PID, live basis, endpoint, source path, and log path remain unbound.
No old epoch or endpoint was copied into a ready configuration.

## Checks preserved

The plan keeps all 65 outer captured starts, including the packaged MCP session and final baseline producer.
It does not count MCP/RPC descendants as outer starts.
It keeps declarations, known caller edges, ranges, coverage, absent-name and wrong-target controls.
It keeps exact native-issued and baseline-issued retained reads, source selectors, row pages, and evidence pages.
It keeps the unissued RESUME rejection with exit 10, identical documents, and no observed producer replay.
Successful issued-token RESUME remains NOT RUN.
The explicit 1 ms check still requires native exit 124, baseline exit 6, and identical timeout documents.
Direct and shell-descendant absolute-JBR allowed/denied controls remain unchanged.
The policy proves enforced execution restrictions, not launch-event counts.

The MCP script and dependency lock are byte-identical to the corrected prior run.
Semantic comparators and rejection joins are unchanged; `reuse-integrity.json` records the comparison.
The acceptance changes only select SHA2 artifacts, import the shared collector, and prevent publishing a measurement-ready configuration from this lifetime.
The final producer still runs in its original slot.
Its context is saved as `correctness-producer-context.json`, explicitly NOT measurement-ready.
Measurement needs a separate fresh IDEA lifetime and new token; do not skip correctness to conserve its capacity.

## Pending handoff

Main must supply the authoritative ready receipt and explicit correctness/MCP authorization.
Bind the exact PID/start time, UUID, complete stable live basis, endpoint, source digest, and log path from that receipt.
Pin both installations, manifests, wrappers, configurations, absolute JBR, readiness probes, and receipt identities.
Reconcile proposed paths and all pending artifact identities; stop on drift.
Save a new `ready.json`; do not overwrite `pending.json` or historical results.
No measurement pilot or cohort is authorized by this preparation.

After that handoff only, from the repository root:

```sh
S=.amp/in/artifacts/native-query/sha2/semantic
uv run --no-project --offline --locked --script "$S/acceptance.py" --check "$S/ready.json"
uv run --no-project --offline --locked --script "$S/acceptance.py" \
  --run "$S/ready.json" --authorize-ready-host --output "$S/run-001"
```

The acceptance command includes MCP and saves its evidence under `mcp/run-001`.
Do not launch an extra standalone MCP session.

## Offline validation

- PASS: acceptance historical oracle replay and mutation controls.
- PASS: MCP oracle replay and changed-range rejection using the pinned existing Python environment.
- PASS: pending authorization rejected before host preflight.
- PASS: Ruff check and format check for all three scripts.
- PASS: strict Pyright with the MCP Python environment, zero errors or warnings.

The first Pyright attempt used the default interpreter and could not resolve MCP dependencies.
Its output remains in `pyright.log`; no checks were suppressed.
The corrected invocation is:

```sh
uv tool run --offline pyright --project "$S/pyrightconfig.json" \
  --pythonpath /Users/amichne/.cache/uv/environments-v2/mcp-check-e7d60f50675c94de/bin/python3
```

Actual SHA2 semantic behavior, JVM controls, MCP/RPC, and live host identity remain NOT RUN.
