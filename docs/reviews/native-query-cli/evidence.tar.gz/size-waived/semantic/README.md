# Final installed semantic acceptance — prepared, not executed

Waiting for main's ready identity. Do not start IDEA or run this against a guessed endpoint. No live commands were used during preparation.

`acceptance.py` uses the existing measurements collector for raw commands, complete environments, input/output bytes, monotonic duration, wait4 CPU/RSS, process reaping and host log receipts. These correctness invocations are **not** the performance cohort. It is dependency-free and has its own uv lock.

## Final artifact binding

Main's `../final-artifact.json` names native query SHA-256:

`7998c949066841104fb393d76ea3edab39eae8825b47dfd8e5931ade33adb7f0`

The script requires the installed payload to match this digest. `../measurements/final-pending.json` preserves the earlier pending fixture configuration. Its candidate `home` paths and installation/configuration hashes are now stale: main supplied the replacement shared HOME `/private/tmp/knq-lifecycle-5VGhDa/h`. Do not use those old paths or carry installation hashes forward. The pending file remains non-authorizing and lacks ready host facts.

After main supplies readiness, copy that pending config to `ready.json` here; set `status` to `READY_MAIN_AUTHORIZED`, exact endpoint path/full document, complete live host/epoch/version, and readiness receipt. Fill and pin both actual installed manifests, public commands, query payloads, wrappers/configuration, copied JBR java and qualification/readiness receipts in `identities`. The baseline JVM environment must select shared host HOME explicitly; the native environment must contain no JVM options. Keep the supplied workspace path exact in both clients' results.

Rebind candidate command/manifest/payload/HOME and baseline `JAVA_TOOL_OPTIONS=-Duser.home=/private/tmp/knq-lifecycle-5VGhDa/h` only after the final readiness receipt confirms that home. Re-hash both installation manifests and selected configurations. Do not infer host identity from an earlier endpoint or startup log.

Add `mcpPython` to the ready configuration: use the exact uv environment interpreter printed by the offline MCP self-test. Pin that interpreter, `mcp_check.py`, and `mcp_check.py.lock` in `identities`. The prepared interpreter is `/Users/amichne/.cache/uv/environments-v2/mcp-check-e7d60f50675c94de/bin/python` (SHA-256 `2d96eb826dc74db4fcd5da6dde045a6fa145e292e07e69d1bdd1a19fa90ffc22`). Run the self-test again if the uv cache changes; do not substitute a system Python without the locked SDK environment.

## Exact planned coverage

The complete run records 65 outer child starts: the original 64 acceptance/control/producer invocations plus one MCP helper. This is not a count of all descendant executions. The helper starts the installed stdio service, which uses its packaged JVM RPC child; those descendants are outside the query execution-policy claim and all performance samples. The order is:

1. Four enforced-policy controls: exact copied JBR java directly and beneath `/bin/sh`, each allowed by the positive profile and denied EPERM by the candidate profile. JVM `-version` includes explicit disposable `-Duser.home`; no Kast JVM management command is run. The two profiles differ only by the exact Java allowlist entry.
2. Baseline original route: declaration, known caller edge, three exact referenced declarations, absent-name and wrong-target controls, then retained read, source/issued-selector reads, three row pages and two independent evidence pages.
3. Native original route: the same cases, plus eight exact baseline-issued cross-client follow-ups.
4. Native under the exact installed exec allowlist: the same cases, plus those baseline-issued follow-ups. This preserves original runs before policy runs. The policy denies all other process execution, including absolute Java paths. No launch counts are inferred.
5. Invalid/unissued-token RESUME negative control on baseline and policy-native: the existing explicit `query-output:v1:00000000-0000-0000-0000-000000000099` control must return identical documents and exit10. Host receipts must show rejected evaluation, exact zero producer/search entries, and zero discovery/relation work. This does not prove successful issuance or RESUME.
6. Real explicit 1ms caller timeout: **baseline exit6, candidate exit124**, identical pre-admission rejection document. Candidate runs under policy. Both must match the saved independent failure document exactly; neither result is manufactured.
7. One installed stdio task-service session using the final package's `server.py --rpc .../bin/kast-tool-rpc-complete --workspace ...`. Initialize, list tools, and call `find` with `{"name":"OrderService"}`. Assert the independent class identity/range17–94, exact file/live basis, coverage/completion, ordered default fields, structured/text equivalence, and host transport/read join. The helper verifies every manifest-owned payload digest before launching. Explicit disposable HOME, copied JBR, `JAVA_TOOL_OPTIONS`, and selected installation configuration prevent personal-home fallback. It runs without the query exec-denial policy because this route intentionally uses the JVM.
8. One fresh, untimed baseline declaration producer after correctness assertions and successful MCP closure. Its real issued result and exited/reaped receipt seed `measurement-ready.json`; no automatic pilot/cohort launch follows.

Every successful host operation requires `kast_transport_read` joining its connection ID to exactly one semantic read and exact host/basis receipts. Retained reads additionally require the prior exact zero-producer/search and discovery/relation assertions. Semantic declarations, caller signatures/edge/ranges, source UTF16 identity/text/lines, coverage/completion, field selection, row IDs, cursors and evidence pages retain the prior independent oracles. Cross-client retained documents receive no normalization. Fresh document comparison replaces only allocated result references and row IDs consistently through links.

Successful issued-token RESUME stays NOT RUN. Only the explicitly unissued negative-control token is supplied without a producer; no successful authority is invented and no private publication owner bypass is used.

## Commands

Offline preparation checks:

```sh
S=.amp/in/artifacts/native-query/size-waived/semantic
uv run --no-project --locked --script "$S/acceptance.py" --self-test
uv run --no-project --offline --locked --script "$S/mcp_check.py" --self-test
uv run --no-project --locked --script "$S/acceptance.py" --check "$S/ready.json"
```

Only after main supplies the ready identity and authorizes correctness execution:

```sh
uv run --no-project --locked --script "$S/acceptance.py" \
  --run "$S/ready.json" --authorize-ready-host --output "$S/run-001"
```

Inspect `run-001/summary.json`, every started case's raw record, failures and policy controls. Failure stops further cases without overwriting earlier evidence. A PASS emits `run-001/measurement-ready.json` for the separately authorized measurement pilot. Do **not** start the 30-pair cohort while the main-owned product Gradle build is running. The earlier collector's successful-pilot requirement still applies.

The MCP outer process receipt is `run-001/mcp-session/record.json`; protocol models, exact result text, server stderr, effective environment, package verification, host log slices, and session summary are under `mcp/run-001/`. SDK session closure is recorded separately from the outer process reaping receipt; neither establishes a complete descendant launch count. The SDK helper has its own pinned dependencies/lock; the collector and acceptance orchestrator remain dependency-free. No RPC or task-service code is replaced or mocked.

Offline replay is not fresh product evidence. Process capture, policy qualification, final timeout exit, semantic parity, and final installed MCP/RPC compatibility all remain NOT RUN until the ready fixture is supplied. Neither a pilot nor a cohort is authorized by these preparation checks.
