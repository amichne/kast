package io.github.amichne.kast.cli.direct

import io.github.amichne.kast.appserver.DaemonOperationFailure
import io.github.amichne.kast.appserver.ide.CanonicalRoot
import io.github.amichne.kast.appserver.ide.CanonicalRootDiscovery
import io.github.amichne.kast.appserver.ide.FilesystemCanonicalRootDiscovery
import io.github.amichne.kast.appserver.mcpWorkspaceOperationClient
import io.github.amichne.kast.appserver.query.AdmittedPublicTool
import io.github.amichne.kast.appserver.query.PublicToolContract
import io.github.amichne.kast.cli.CliBoundaryExitStatus
import io.github.amichne.kast.cli.CliExit
import io.github.amichne.kast.cli.boundaryExit
import io.github.amichne.kast.cli.ide.ExistingIdeCliCapabilities
import io.github.amichne.kast.cli.ide.configuredExistingIdeClient
import io.github.amichne.kast.cli.ide.executeAdmittedPublicTool
import io.github.amichne.kast.cli.installedHostedBootstrap
import io.github.amichne.kast.cli.mcp.McpInvestigationTools
import io.github.amichne.kast.cli.mcp.McpSingleChangeTool
import io.github.amichne.kast.cli.rpc.InvocationRecordKind
import io.github.amichne.kast.cli.rpc.OneShotInvocationRecord
import io.github.amichne.kast.kernel.Refinement
import io.github.amichne.kast.protocol.registry.CanonicalAgentToolDefinitions
import io.github.amichne.kast.protocol.registry.PublicToolCatalog
import io.github.amichne.kast.protocol.registry.PublicToolIdentity
import io.github.amichne.kast.protocol.registry.SupportToolIdentity
import java.nio.file.Path
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonObject

/** Shared native tool composition. The client protocol is chosen by the caller. */
internal class KastDirectToolSession(
    private val registration: DirectToolRegistration,
    val root: () -> CanonicalRootDiscovery,
    start: (CanonicalRoot) -> Refinement<Unit, DaemonOperationFailure>,
    val invokePublic: (AdmittedPublicTool) -> CliExit,
    val invokeSupport: (SupportToolIdentity, JsonObject) -> CliExit = { _, _ ->
        error("No support tool binding")
    },
    val admission: () -> InstalledToolAdmission = { InstalledToolAdmission.AVAILABLE },
    val queryCatalog: PublicToolCatalog = PublicToolCatalog.COMPLETE,
    val beginInvocation: (InvocationRecordKind) -> OneShotInvocationRecord? = { null },
) {
    /** Invocation admission uses compiled registrations; schema projection is only a discovery effect. */
    val catalog: List<DirectToolDocument>
        get() = registration.catalog

    fun supports(name: String): Boolean = registration.supports(name)

    constructor(
        catalog: List<DirectToolDocument>,
        root: () -> CanonicalRootDiscovery,
        start: (CanonicalRoot) -> Refinement<Unit, DaemonOperationFailure>,
        invokePublic: (AdmittedPublicTool) -> CliExit,
        invokeSupport: (SupportToolIdentity, JsonObject) -> CliExit = { _, _ -> error("No support tool binding") },
        admission: () -> InstalledToolAdmission = { InstalledToolAdmission.AVAILABLE },
        queryCatalog: PublicToolCatalog = PublicToolCatalog.COMPLETE,
    ) : this(
        DirectToolRegistration.fromDocuments(catalog),
        root,
        start,
        invokePublic,
        invokeSupport,
        admission,
        queryCatalog,
    )

    val start: (CanonicalRoot) -> Refinement<Unit, DaemonOperationFailure> = { selected ->
        when (admission()) {
            InstalledToolAdmission.AVAILABLE -> start(selected)
            InstalledToolAdmission.STOPPED,
            InstalledToolAdmission.UNPROVEN ->
                Refinement.Rejected(
                    DaemonOperationFailure.Protocol(
                        io.github.amichne.kast.appserver.DaemonOperationProtocolFailure.LIFECYCLE_TRANSITION
                    )
                )
        }
    }

    fun invoke(name: String, arguments: JsonObject): CliExit =
        if (admission() != InstalledToolAdmission.AVAILABLE)
            boundaryExit(CliBoundaryExitStatus.RUNTIME, "installation-shutdown")
        else
            SupportToolIdentity.entries.singleOrNull { it.toolName == name }?.let { invokeSupport(it, arguments) }
                ?: admitAndInvokePublic(name, arguments, queryCatalog, invokePublic)

    fun invokeAdmitted(request: AdmittedPublicTool): CliExit =
        if (request.catalog != queryCatalog)
            CliExit.PublicInputRejected(io.github.amichne.kast.appserver.query.PublicToolInputFailure.SchemaMismatch)
        else if (admission() == InstalledToolAdmission.AVAILABLE) invokePublic(request)
        else boundaryExit(CliBoundaryExitStatus.RUNTIME, "installation-shutdown")

    companion object {
        @Suppress("CognitiveComplexMethod", "CyclomaticComplexMethod", "LongMethod")
        fun installed(
            directory: Path,
            home: Path,
            environment: Map<String, String>,
            queryCatalog: PublicToolCatalog = PublicToolCatalog.COMMON,
        ): KastDirectToolSession? {
            val context =
                when (val admitted = InstalledClientContext.current(environment)) {
                    is Refinement.Refined -> admitted.value
                    is Refinement.Rejected -> return null
                }
            val selected =
                CanonicalAgentToolDefinitions.all.filter { definition ->
                    PublicToolIdentity.entries.any { it.toolName == definition.name.value }
                }
            if (selected.size != PublicToolIdentity.entries.size) return null
            val root = { FilesystemCanonicalRootDiscovery.discover(directory) }
            val boundRoot =
                observeDirectToolStage(DirectToolStage.ROOT_BINDING) {
                    (root() as? CanonicalRootDiscovery.Discovered)?.root?.path ?: directory
                }
            val read =
                observeDirectToolStage(DirectToolStage.WORKSPACE_CLIENT_COMPOSITION) {
                    mcpWorkspaceOperationClient(home, context.environment)
                }
            val capabilities =
                observeDirectToolStage(DirectToolStage.CAPABILITIES_COMPOSITION) {
                    ExistingIdeCliCapabilities(
                        FilesystemCanonicalRootDiscovery,
                        configuredExistingIdeClient(home, context.environment),
                        read,
                    )
                }
            val change =
                observeDirectToolStage(DirectToolStage.CHANGE_TOOL_COMPOSITION) {
                    McpSingleChangeTool.installed(root = boundRoot, capabilities = capabilities)
                }
            val invokePublic: (AdmittedPublicTool) -> CliExit = { request ->
                if (request.identity in setOf(PublicToolIdentity.ADD_DECLARATION, PublicToolIdentity.REPLACE_BODY))
                    change.invoke(request)
                else executeAdmittedPublicTool(request, directory, capabilities)
            }
            val investigation =
                McpInvestigationTools(
                    directory,
                    capabilities,
                    selected
                        .filter {
                            it.name.value !in
                                setOf(
                                    PublicToolIdentity.ADD_DECLARATION.toolName,
                                    PublicToolIdentity.REPLACE_BODY.toolName,
                                )
                        }
                        .map { it.operation.operation.id.value.uppercase().replace('.', '_') }
                        .toSet(),
                    prepare = { root -> runBlocking { read.awaitPreparation(root) } },
                )
            return KastDirectToolSession(
                registration =
                    DirectToolRegistration(
                        selected.map { it.name }.toSet() + directToolName(SupportToolIdentity.HEALTH_CHECK.toolName)
                    ) {
                        val catalog =
                            observeDirectToolStage(DirectToolStage.HOSTED_CATALOG_COMPOSITION) {
                                installedHostedBootstrap().tools.associateBy { it.name }
                            }
                        observeDirectToolStage(DirectToolStage.DIRECT_CATALOG_PROJECTION) {
                            selected.map {
                                val identity =
                                    PublicToolIdentity.entries.single { identity -> identity.toolName == it.name.value }
                                catalog
                                    .getValue(it.name.value)
                                    .directToolDocument()
                                    .copy(
                                        inputSchema = PublicToolContract.parameters(identity, queryCatalog),
                                        description = identity.descriptionFor(queryCatalog),
                                    )
                            } + directSupportTools()
                        }
                    },
                root = root,
                admission = context::observe,
                start = read::start,
                invokePublic = invokePublic,
                invokeSupport = investigation::invoke,
                queryCatalog = queryCatalog,
                beginInvocation = { kind -> OneShotInvocationRecord.begin(context, kind) },
            )
        }
    }
}

private fun admitAndInvokePublic(
    name: String,
    arguments: JsonObject,
    catalog: PublicToolCatalog,
    invoke: (AdmittedPublicTool) -> CliExit,
): CliExit {
    val identity =
        PublicToolIdentity.entries.singleOrNull { it.toolName == name }
            ?: return boundaryExit(CliBoundaryExitStatus.USAGE, "direct-tool-unsupported")
    return when (val admitted = PublicToolContract.admit(identity, arguments, catalog)) {
        is Refinement.Refined -> invoke(admitted.value)
        is Refinement.Rejected -> CliExit.PublicInputRejected(admitted.failure)
    }
}
