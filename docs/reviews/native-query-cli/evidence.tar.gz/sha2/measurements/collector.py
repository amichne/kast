#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# [tool.uv]
# no-build = true
# ///
"""Frozen paired collection. No product invocation without --run --authorize-ready-host.

JSON documents are deliberately opaque at this observation boundary. Independent
assertions below preserve semantic facts; only fresh allocation IDs are renamed.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import signal
import statistics
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, BinaryIO, cast

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[5]
PRIOR = HERE.parents[1] / "semantic-acceptance"
DECISION = HERE.parents[1] / "collection-decision.md"
SOURCE_SHA = "c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859"
QUERY_SHA = "adb62a50289767e84fda49041b20ed142c96350d2cdbdebad7b028c473acb338"
COHORTS = ("retained", "metadata", "plan", "discovery", "callers")
ROUTES = ("baseline", "native")
FIELDS = ["--fields", "name,signature,location"]
GRANTS = ["--max-results", "128", "--max-returned-bytes", "49152"]


def require(condition: bool, detail: str) -> None:
    if not condition:
        raise ValueError(detail)


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path: Path) -> Any:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            require(key not in result, f"duplicate JSON key: {key}")
            result[key] = value
        return result

    return json.loads(path.read_bytes(), object_pairs_hook=unique)


def save(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".pending")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def common(result: Any, config: Any, name: str, relation: bool = False) -> Any:
    require(result["type"] == "complete", "complete envelope")
    d = result["document"]
    require(d["status"] == "complete", "complete status")
    require(d["coverage"] == {"exhaustive": True}, "exhaustive coverage")
    require(d["live"] == config["live"], "exact host/workspace/basis/version")
    expected = {
        "from": {
            "type": "symbols",
            "match": {"type": "name", "text": name, "matching": "exact-name"},
            "scope": {
                "sourceSets": ["main", "test"],
                "directory": {"path": ".", "containment": "descendants"},
                "packageName": None,
            },
            "declarationKinds": ["class", "function", "property", "type-alias"],
        },
        "steps": [{"type": "related", "relation": "callers"}] if relation else [],
        "output": {"type": "symbols", "fields": ["name", "signature", "location"]},
        "completion": {"type": "COMPLETE_ONLY", "model": "COMPILER_RESOLVED_STATIC_V1"},
    }
    require(d["question"] == expected, "independent question, fields, scope and completion")
    return d


def declaration(result: Any, config: Any) -> None:
    d = common(result, config, "OrderService")
    require(len(d["items"]) == 1, "one OrderService declaration")
    row = d["items"][0]
    require(row["name"] == "OrderService" and row["kind"] == "classlike", "declaration name/kind")
    require(
        row["signature"] == {"type": "class-like", "qualifiedIdentity": "example.OrderService"},
        "declaration signature",
    )
    require(
        row["location"]
        == {"file": config["source"], "range": {"startInclusive": 17, "endExclusive": 94}},
        "declaration range",
    )
    require(row["connections"] == [], "declaration connections")
    require(
        d["original_evidence_summary"]
        == {"failure_count": 0, "omission_count": 0, "evidence_count": 1},
        "declaration evidence",
    )


def caller(result: Any, config: Any) -> None:
    d = common(result, config, "submitOrder", True)
    require(len(d["items"]) == 1, "one known caller")
    row = d["items"][0]
    require(row["name"] == "placeOrder" and row["kind"] == "function", "caller name/kind")
    require(
        row["signature"]
        == {
            "type": "function",
            "qualifiedIdentity": "example.placeOrder",
            "receiver": {"type": "absent"},
            "contextReceivers": [],
            "valueParameters": ["example/OrderService"],
            "typeParameterCount": 0,
        },
        "caller signature",
    )
    require(
        row["location"]
        == {"file": config["source"], "range": {"startInclusive": 96, "endExclusive": 174}},
        "caller range",
    )
    graph = d["relation_graph"]
    require(
        graph["basis"] == d["retention"]["reference"] == graph["detail"]["request"]["result"],
        "graph-token linkage",
    )
    nodes = {node["symbol"]["qualifiedIdentity"]: node for node in graph["nodes"]}
    require(
        len(graph["nodes"]) == 2
        and set(nodes) == {"example.placeOrder", "example.OrderService.submitOrder"},
        "graph nodes",
    )
    require(
        nodes["example.OrderService.submitOrder"]["symbol"]["range"]
        == {"startInclusive": 42, "endExclusive": 92},
        "target range",
    )
    require(len(graph["connection_witnesses"]) == 1, "one known edge")
    edge = graph["connection_witnesses"][0]
    require(edge["source"] == nodes["example.placeOrder"]["id"] == row["node"], "edge source")
    require(edge["target"] == nodes["example.OrderService.submitOrder"]["id"], "edge target")
    require(row["connections"] == [edge["id"]], "edge row linkage")
    require(
        edge["meaning"] == "callers" and edge["direction"] == "SOURCE_TO_TARGET", "edge direction"
    )
    require(
        edge["provenance"] == "k2-authored-source"
        and edge["coverage"] == "exact-compiler-confirmed",
        "edge qualification",
    )
    require(edge["occurrence"]["file"] == config["source"], "edge file")
    require(
        edge["occurrence"]["range"] == {"startInclusive": 152, "endExclusive": 163},
        "edge occurrence",
    )
    require(
        d["original_evidence_summary"]
        == {"failure_count": 0, "omission_count": 0, "evidence_count": 2},
        "caller evidence",
    )


def normalized(result: Any) -> Any:
    """The prior frozen comparator: allocation references/row IDs only, everywhere linked."""
    d = result["document"]
    tokens = {d["retention"]["reference"]: "<fresh-result>"}
    for index, row in enumerate(d["items"]):
        tokens[row["row_id"]] = f"<fresh-row-{index}>"

    def visit(value: Any) -> Any:
        if isinstance(value, str):
            return tokens.get(value, value)
        if isinstance(value, list):
            return [visit(item) for item in cast(list[Any], value)]
        if isinstance(value, dict):
            return {key: visit(item) for key, item in cast(dict[str, Any], value).items()}
        return value

    return visit(result)


def receipts(raw: bytes) -> dict[str, list[Any]]:
    result: dict[str, list[Any]] = {}
    for kind in ("semantic_read", "transport_read", "transport", "preparation", "lifecycle"):
        marker = f" - kast_{kind} "
        result[kind] = [
            json.loads(line.split(marker, 1)[1])
            for line in raw.decode("utf-8").splitlines()
            if marker in line
        ]
    return result


def check_receipts(observed: Any, config: Any, cohort: str) -> None:
    if cohort in ("metadata", "plan"):
        require(
            all(not values for values in observed.values()),
            "local route caused host work or interval contaminated",
        )
        return
    reads = observed["semantic_read"]
    require(len(reads) == 1, "exactly one semantic receipt required")
    read = reads[0]
    require(read["pid"] == config["endpointExpected"]["hostPid"], "host receipt PID")
    require(
        read["correlation"]
        == {"type": "bound", "host": config["live"]["host"], "epoch": config["live"]["epoch"]},
        "host receipt identity/basis",
    )
    links = [link for link in observed["transport_read"] if link["readId"] == read["readId"]]
    require(len(links) == 1, "exact connection-to-read join unavailable/ambiguous")
    events = [
        event
        for event in observed["transport"]
        if event["connectionId"] == links[0]["connectionId"]
    ]
    require(
        sum(event["stage"] == "EXECUTION" and event["outcome"] == "COMPLETED" for event in events)
        == 1,
        "joined execution completion",
    )
    k2 = [call for call in read["nativeCalls"] if call["call"] == "K2_ANALYSIS"]
    require(
        bool(k2) and all(call["qualification"] == "EXACT" for call in k2),
        "exact K2 observation required",
    )
    if cohort == "retained":
        require(
            read["nativePhase"] == {"type": "entered", "phase": "RETENTION"},
            "READ_RESULT retention phase",
        )
        require(
            all(
                call["entered"] == 0 and call["qualification"] == "EXACT"
                for call in read["nativeCalls"]
            ),
            "READ_RESULT producer replay",
        )
        require(
            all(
                search["entered"] == 0 and search["qualification"] == "EXACT"
                for search in read["nativeSearches"]
            ),
            "READ_RESULT search replay",
        )
        counters = {counter["counter"]: counter["count"] for counter in read["counters"]}
        for name in (
            "DECLARATION_PSI_NODES_VISITED",
            "NATIVE_DISCOVERY_PAGES",
            "NATIVE_RELATION_PAGES",
        ):
            require(counters[name] == 0, f"READ_RESULT {name}")
        require(read["discoveryPages"]["published"] == 0, "READ_RESULT discovery publication")
    else:
        require(any(call["entered"] > 0 for call in k2), "producer positive K2 control")


def arguments(cohort: str, config: Any) -> tuple[list[str], bytes]:
    scope = ["--catalog", "complete", "--workspace", config["live"]["root"]]
    if cohort == "retained":
        return ["result", "read", *scope, "--ref", config["retainedToken"], *FIELDS, *GRANTS], b""
    if cohort == "metadata":
        return ["describe", "query", "--section", "input", "--catalog", "complete"], b""
    if cohort == "plan":
        return ["query", "plan", *scope, "--name", "OrderService"], b""
    if cohort == "discovery":
        return ["query", *scope, "--request", "-"], (
            REPO / "docs/reviews/public-cli-v1/query.json"
        ).read_bytes()
    require(cohort == "callers", "unknown cohort")
    return [
        "query",
        *scope,
        "--name",
        "submitOrder",
        "--relation",
        "callers",
        *FIELDS,
        *GRANTS,
        "--retain",
    ], b""


def schedule() -> list[tuple[str, str, int, str]]:
    samples: list[tuple[str, str, int, str]] = []
    for cohort in COHORTS:
        samples.extend((cohort, "warmup", 0, route) for route in ROUTES)
        for pair in range(30):
            samples.extend(
                (cohort, "measured", pair, route)
                for route in (ROUTES if pair % 2 == 0 else ROUTES[::-1])
            )
    return samples


def preflight(config: Any, *, artifacts: bool) -> None:
    require(config["protocolSha256"] == digest(DECISION), "frozen protocol changed")
    require(
        digest(REPO / "docs/reviews/public-cli-v1/query.json") == QUERY_SHA,
        "frozen request changed",
    )
    require(config["sizeWaiver"] == "temporary-size-only", "explicit size-only amendment required")
    require(digest(Path(config["source"])) == SOURCE_SHA, "fixture source changed")
    require(
        config["source"]
        == str(Path(config["live"]["root"]) / "src/main/kotlin/example/OrderService.kt"),
        "fixture path",
    )
    require(
        load(Path(config["endpoint"])) == config["endpointExpected"], "endpoint identity changed"
    )
    require(
        config["endpointExpected"]["host"] == config["live"]["host"]
        and config["endpointExpected"]["root"] == config["live"]["root"],
        "endpoint/live mismatch",
    )
    os.kill(config["endpointExpected"]["hostPid"], 0)
    require(Path(config["hostLog"]).is_file(), "host log required")
    require(config["watchdogSeconds"] >= 120, "watchdog is a harness bound, not a product timeout")
    require(bool(config["externalLoadNotes"]), "external workload declaration required")
    if artifacts:
        require(bool(config["identities"]), "artifact identities required")
        for path, expected in config["identities"].items():
            require(digest(Path(path)) == expected, f"identity changed: {path}")
        for key in (
            "readyHostReceipt",
            "qualificationReceipt",
            "retainedProducerStdout",
            "retainedProducerReceipt",
        ):
            require(config[key] in config["identities"], f"pin {key} digest")
        require(
            bool(config["toolchains"]) and bool(config["artifactCosts"]),
            "toolchain/build/archive/installed evidence required (unavailable must be explicit)",
        )
        for route in ROUTES:
            selected = config["routes"][route]
            require(selected["command"] in config["identities"], f"pin {route} dispatcher")
            require(
                selected["manifest"] in config["identities"]
                and selected["payload"] in config["identities"],
                f"pin {route} manifest/payload",
            )
            require(len(selected["sourceSha"]) == 40, f"{route} full source SHA")
            require(Path(selected["environment"]["HOME"]).is_absolute(), "explicit HOME")
            require(
                selected["command"]
                == str(Path(selected["environment"]["HOME"]) / ".local/bin/kast"),
                "installed public route only",
            )
            require(bool(selected["environment"].get("PATH")), "explicit PATH")
            if route == "native":
                require(
                    not (
                        {"JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "JAVA_OPTS", "KAST_OPTS"}
                        & set(selected["environment"])
                    ),
                    "native JVM option contamination",
                )
        producer = load(Path(config["retainedProducerStdout"]))
        declaration(producer, config)
        require(
            producer["document"]["retention"]["reference"] == config["retainedToken"],
            "must use exact issued token",
        )
        receipt = load(Path(config["retainedProducerReceipt"]))
        require(
            receipt["exitCode"] == 0 and receipt["reapedBeforeNextInvocation"] is True,
            "producer must already have exited",
        )


def log_identity(observed: os.stat_result) -> tuple[int, int]:
    return observed.st_dev, observed.st_ino


def log_archives(path: Path) -> dict[int, tuple[int, int]]:
    result: dict[int, tuple[int, int]] = {}
    for archive in path.parent.glob(path.stem + ".*" + path.suffix):
        number = archive.name[len(path.stem) + 1 : -len(path.suffix)]
        if not number.isdecimal():
            continue
        require(number == str(int(number)) and int(number) > 0, "ambiguous archive name")
        require(not archive.is_symlink() and archive.is_file(), "nonregular log archive")
        result[int(number)] = log_identity(archive.stat())
        require(len(result) <= 64, "log archive enumeration bound exceeded")
    return result


def log_prefix_digest(stream: BinaryIO, size: int) -> str:
    stream.seek(0)
    result = hashlib.sha256()
    remaining = size
    while remaining:
        chunk = stream.read(min(remaining, 65536))
        require(bool(chunk), "initial log truncated")
        result.update(chunk)
        remaining -= len(chunk)
    return result.hexdigest()


@dataclass(frozen=True)
class LogSpan:
    path: str
    identity: tuple[int, int]
    start: int
    end: int
    sha256: str


@dataclass
class LogCapture:
    stream: BinaryIO
    initial: os.stat_result
    prefix_sha256: str
    archives: dict[int, tuple[int, int]]

    @classmethod
    def begin(cls, path: Path) -> LogCapture:
        stream = path.open("rb", buffering=0)
        try:
            initial = os.fstat(stream.fileno())
            prefix = log_prefix_digest(stream, initial.st_size)
            archives = log_archives(path)
            require(
                log_identity(path.stat()) == log_identity(initial), "log changed during admission"
            )
            return cls(stream, initial, prefix, archives)
        except BaseException:
            stream.close()
            raise

    def finish(self, path: Path) -> tuple[bytes, list[LogSpan], int]:
        """One append/rename interval only; missing, ambiguous, or extra generations reject."""
        original = log_identity(self.initial)
        old_end = os.fstat(self.stream.fileno()).st_size
        require(old_end >= self.initial.st_size, "initial log truncated")
        require(
            log_prefix_digest(self.stream, self.initial.st_size) == self.prefix_sha256,
            "initial log prefix changed",
        )
        archives = log_archives(path)
        with path.open("rb", buffering=0) as current:
            end = os.fstat(current.fileno())
            rotated = log_identity(end) != original
            if rotated:
                aliases = [number for number, identity in archives.items() if identity == original]
                require(bool(aliases), "missing initial log generation")
                require(len(aliases) == 1, "ambiguous initial log generation")
                require(aliases == [1], "unsupported or missing log generation")
                for number, identity in archives.items():
                    if number > 1:
                        require(
                            self.archives.get(number - 1) == identity,
                            "unexplained archive generation",
                        )
            else:
                require(archives == self.archives, "archive namespace changed without rename")
            self.stream.seek(self.initial.st_size)
            tail = self.stream.read(old_end - self.initial.st_size)
            require(
                len(tail) == old_end - self.initial.st_size, "initial log truncated during capture"
            )
            old_path = path.with_name(path.stem + ".1" + path.suffix) if rotated else path
            spans = [
                LogSpan(
                    str(old_path),
                    original,
                    self.initial.st_size,
                    old_end,
                    hashlib.sha256(tail).hexdigest(),
                )
            ]
            raw = tail
            if rotated:
                prefix = current.read(end.st_size)
                require(len(prefix) == end.st_size, "successor log truncated during capture")
                spans.append(
                    LogSpan(
                        str(path),
                        log_identity(end),
                        0,
                        end.st_size,
                        hashlib.sha256(prefix).hexdigest(),
                    )
                )
                raw += prefix
            require(
                log_identity(path.stat()) == log_identity(end), "successor changed during capture"
            )
            require(log_archives(path) == archives, "archive namespace changed during capture")
            require(
                os.fstat(self.stream.fileno()).st_size == old_end,
                "initial log changed during capture",
            )
            require(
                log_prefix_digest(self.stream, self.initial.st_size) == self.prefix_sha256,
                "initial log prefix changed during capture",
            )
            require(
                os.fstat(current.fileno()).st_size == end.st_size,
                "successor changed during capture",
            )
            return raw, spans, end.st_size


def capture(
    directory: Path,
    argv: list[str],
    environment: dict[str, str],
    cwd: str,
    request: bytes,
    host_log: Path,
    watchdog: int,
    label: Any,
) -> Any:
    """wait4 plus pipe EOF, not a process snapshot or cumulative RSS delta."""
    directory.mkdir()
    (directory / "stdin").write_bytes(request)
    log_capture = LogCapture.begin(host_log)
    log_stat = log_capture.initial
    record: dict[str, Any] = {
        **label,
        "state": "STARTING",
        "argv": argv,
        "environment": environment,
        "cwd": cwd,
        "wallStartNs": time.time_ns(),
        "hostLogStart": log_stat.st_size,
        "hostLogIdentity": [log_stat.st_dev, log_stat.st_ino],
        "hostLogPrefixSha256": log_capture.prefix_sha256,
        "hostLogMechanism": "append-or-one-verified-rename",
        "loadAverage": os.getloadavg(),
        "clientJvmLaunches": None,
        "nativeLaunches": None,
        "executionCountsReason": "No execution-event collector; process/resource observations are not launch counts.",
    }
    process: subprocess.Popen[bytes] | None = None
    old_handlers: dict[int, Any] = {}
    drain_errors: list[str] = []
    drains: list[threading.Thread] = []

    def interrupted(number: int, _frame: Any) -> None:
        record["interruption"] = signal.Signals(number).name
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    def drain(stream: BinaryIO, destination: Path) -> None:
        try:
            with stream, destination.open("wb") as output:
                while chunk := stream.read(65536):
                    output.write(chunk)
        except OSError as error:
            drain_errors.append(repr(error))

    try:
        save(directory / "record.json", record)
        for number in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM):
            old_handlers[number] = signal.signal(number, interrupted)
        with (directory / "stdin").open("rb") as stdin:
            record["startMonotonicNs"] = time.monotonic_ns()
            process = subprocess.Popen(
                argv,
                cwd=cwd,
                env=environment,
                stdin=stdin,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                start_new_session=True,
            )
        record["pid"] = process.pid
        record["state"] = "STARTED"
        save(directory / "record.json", record)
        signal.setitimer(signal.ITIMER_REAL, watchdog)
        for stream, name in ((process.stdout, "stdout"), (process.stderr, "stderr")):
            require(stream is not None, "captured pipe")
            thread = threading.Thread(target=drain, args=(stream, directory / name), daemon=True)
            drains.append(thread)
            thread.start()
        _, status, usage = os.wait4(process.pid, 0)
        process.returncode = os.waitstatus_to_exitcode(status)
        for thread in drains:
            thread.join()
        record["endMonotonicNs"] = time.monotonic_ns()
        record["elapsedMs"] = (record["endMonotonicNs"] - record["startMonotonicNs"]) / 1_000_000
        record["exitCode"] = process.returncode
        record["reapedBeforeNextInvocation"] = True
        record["outputEof"] = not drain_errors
        record["resourceUsage"] = {
            "method": "os.wait4(public PID)",
            "userSeconds": usage.ru_utime,
            "systemSeconds": usage.ru_stime,
            "maxRssRaw": usage.ru_maxrss,
            "maxRssUnit": "bytes" if sys.platform == "darwin" else "KiB",
            "scope": "OS child accounting, including waited descendants where OS propagates it; not summed simultaneous process-tree RSS",
            "completeDescendantAccounting": "UNAVAILABLE",
        }
        record["state"] = "RECORDED"
    except (OSError, ValueError) as error:
        record["collectorFailure"] = repr(error)
        record["state"] = "COLLECTOR_FAILED"
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if process is not None and process.returncode is None:
            interrupted(signal.SIGTERM, None)
            process.wait()
            for thread in drains:
                thread.join(timeout=5)
            record["exitCode"] = process.returncode
            record["reapedBeforeNextInvocation"] = True
        for number, handler in old_handlers.items():
            signal.signal(number, handler)
        record["drainErrors"] = drain_errors
        try:
            raw, spans, end = log_capture.finish(host_log)
            (directory / "host.log").write_bytes(raw)
            record["hostLogEnd"] = end
            record["hostLogSpans"] = [asdict(span) for span in spans]
            record["receipts"] = receipts(raw)
        except (OSError, ValueError) as error:
            record["logFailure"] = repr(error)
        finally:
            log_capture.stream.close()
        for name in ("stdout", "stderr", "stdin", "host.log"):
            path = directory / name
            if path.exists():
                record[name + "Identity"] = {"sha256": digest(path), "bytes": path.stat().st_size}
        save(directory / "record.json", record)
    return record


def validate_sample(directory: Path, record: Any, config: Any) -> Any:
    require(
        not record.get("logFailure"), "host log capture failed: " + str(record.get("logFailure"))
    )
    require(
        record["state"] == "RECORDED" and not record.get("interruption"),
        "sample not normally completed",
    )
    require(record["exitCode"] == 0 and record["outputEof"], "exit/output completion")
    raw = (directory / "stdout").read_bytes()
    require(raw.endswith(b"\n") and raw.count(b"\n") == 1, "one JSON document and newline")
    result = load(directory / "stdout")
    cohort = record["cohort"]
    check_receipts(record["receipts"], config, cohort)
    if cohort in ("discovery", "retained"):
        declaration(result, config)
    elif cohort == "callers":
        caller(result, config)
    else:
        require(isinstance(result, dict), "local document object")
        result = cast(dict[str, Any], result)
        require(bool(result), "nonempty local document")
    if cohort == "retained":
        producer = load(Path(config["retainedProducerStdout"]))["document"]
        for key in (
            "items",
            "retention",
            "live",
            "coverage",
            "question",
            "original_evidence_summary",
        ):
            require(result["document"][key] == producer[key], f"retained producer {key}")
    return result


def describe(values: list[float]) -> Any:
    if not values:
        return {"n": 0, "unavailable": True}
    ordered = sorted(values)
    return {
        "n": len(values),
        "median": statistics.median(values),
        "empiricalP95": ordered[math.ceil(len(values) * 0.95) - 1],
        "minimum": ordered[0],
        "maximum": ordered[-1],
    }


def pilot_identity(config: Any) -> Any:
    selected = {key: config[key] for key in ("live", "source", "endpointExpected", "routes")}
    selected["artifacts"] = {
        config["routes"][route][key]: config["identities"][config["routes"][route][key]]
        for route in ROUTES
        for key in ("command", "manifest", "payload")
    }
    selected["collectorSha256"] = digest(Path(__file__))
    return selected


def collect(config: Any, output: Path, *, pilot: bool = False) -> int:
    preflight(config, artifacts=True)
    if not pilot:
        receipt = Path(config["pilotReceipt"])
        require(str(receipt) in config["identities"], "pin successful pilot receipt")
        observed = load(receipt)
        require(
            observed["state"] == "PASS" and observed["kind"] == "PILOT",
            "successful pilot required before cohort",
        )
        require(
            observed["pilotIdentity"] == pilot_identity(config),
            "pilot artifact/host/collector identity differs",
        )
    require(
        output.is_relative_to(HERE) and not output.exists(),
        "new output directory beneath measurements required",
    )
    output.mkdir()
    save(output / "config.json", config)
    (output / "collection-decision.md").write_bytes(DECISION.read_bytes())
    planned = (
        [(cohort, "pilot", 0, route) for cohort in COHORTS for route in ROUTES]
        if pilot
        else schedule()
    )
    save(output / "schedule.json", planned)
    records: list[Any] = []
    documents: dict[tuple[str, str, int, str], Any] = {}
    pairs: list[Any] = []
    summary: dict[str, Any] = {
        "state": "INCOMPLETE",
        "kind": "PILOT" if pilot else "COHORT",
        "pilotIdentity": pilot_identity(config),
        "sizeQualification": "WAIVED_TEMPORARILY_NOT_PASSED",
        "warmupsExcludedFromStatistics": True,
        "pairDifference": "native minus baseline milliseconds",
        "executionCounts": "UNAVAILABLE; qualify AC02 separately",
        "protocolSha256": digest(DECISION),
    }
    try:
        for cohort, phase, pair, route in planned:
            preflight(config, artifacts=False)
            label = {"cohort": cohort, "phase": phase, "pair": pair, "route": route}
            directory = output / f"{len(records):03d}-{cohort}-{phase}-{pair:02d}-{route}"
            args, request = arguments(cohort, config)
            selected = config["routes"][route]
            record = capture(
                directory,
                [selected["command"], *args],
                selected["environment"],
                config["live"]["root"],
                request,
                Path(config["hostLog"]),
                config["watchdogSeconds"],
                label,
            )
            records.append(record)
            try:
                document = validate_sample(directory, record, config)
                documents[cohort, phase, pair, route] = document
                record["assertions"] = {"status": "PASS"}
            except (KeyError, TypeError, ValueError) as error:
                record["assertions"] = {"status": "FAIL", "detail": repr(error)}
            save(directory / "record.json", record)
            order = ROUTES if phase == "warmup" or pair % 2 == 0 else ROUTES[::-1]
            if route == order[-1]:
                keys = [(cohort, phase, pair, r) for r in ROUTES]
                equivalent = False
                if all(key in documents for key in keys):
                    left, right = [documents[key] for key in keys]
                    equivalent = (
                        normalized(left) == normalized(right)
                        if cohort in ("discovery", "callers")
                        else left == right
                    )
                pairs.append(
                    {"cohort": cohort, "phase": phase, "pair": pair, "equivalent": equivalent}
                )
                save(output / "pair-assertions.json", pairs)
            print(
                directory.name, record.get("exitCode"), record["assertions"]["status"], flush=True
            )
            if record.get("interruption"):
                raise ValueError("interrupted cohort; no automatic repeat")
        preflight(config, artifacts=True)
        summary["state"] = (
            "PASS"
            if all(r["assertions"]["status"] == "PASS" for r in records)
            and all(p["equivalent"] for p in pairs)
            else "FAIL"
        )
    except (OSError, ValueError, KeyboardInterrupt) as error:
        summary["abort"] = repr(error)
    finally:
        summary["startedSamples"] = len(records)
        summary["recordedFailures"] = sum(
            r.get("assertions", {}).get("status") != "PASS" for r in records
        )
        summary["cohorts"] = {}
        for cohort in COHORTS:
            rows = [r for r in records if r["cohort"] == cohort and r["phase"] == "measured"]
            durations = {
                route: {
                    r["pair"]: r["elapsedMs"]
                    for r in rows
                    if r["route"] == route and "elapsedMs" in r
                }
                for route in ROUTES
            }
            baseline, native = (durations[route] for route in ROUTES)
            summary["cohorts"][cohort] = {
                "allCompletedIncludingFailuresMs": {
                    route: describe(list(values.values())) for route, values in durations.items()
                },
                "pairedDifferencesIncludingFailuresMs": describe(
                    [native[p] - baseline[p] for p in baseline.keys() & native.keys()]
                ),
                "latencyClaimEligible": not pilot and summary["state"] == "PASS",
                "failuresNeverSilentlyExcluded": True,
            }
        save(output / "summary.json", summary)
    return 0 if summary["state"] == "PASS" else 1


def self_test() -> None:
    """Offline historical replay and mutation controls; never launches a product."""
    native = load(PRIOR / "native-declaration.stdout")
    baseline = load(PRIOR / "baseline-declaration.stdout")
    related = load(PRIOR / "native-callers.stdout")
    config = {
        "live": native["document"]["live"],
        "source": native["document"]["items"][0]["location"]["file"],
        "endpointExpected": load(PRIOR / "endpoint-before.json"),
    }
    declaration(native, config)
    caller(related, config)
    require(normalized(native) == normalized(baseline), "historical fresh allocation parity")
    mutations: tuple[tuple[Any, Callable[[Any, Any], None], Callable[[Any], None]], ...] = (
        (
            native,
            declaration,
            lambda d: d["items"][0]["location"]["range"].update(startInclusive=18),
        ),
        (native, declaration, lambda d: d.update(coverage={"exhaustive": False})),
        (native, declaration, lambda d: d["live"].update(host="wrong-host")),
        (native, declaration, lambda d: d["question"]["output"].update(fields=["name"])),
        (
            related,
            caller,
            lambda d: d["relation_graph"]["connection_witnesses"][0].update(
                target=d["relation_graph"]["connection_witnesses"][0]["source"]
            ),
        ),
        (related, caller, lambda d: d["relation_graph"].update(basis="not-issued")),
        (native, declaration, lambda d: d["question"]["completion"].update(model="wrong-model")),
    )
    for original, check, mutate in mutations:
        changed = copy.deepcopy(original)
        mutate(changed["document"])
        try:
            check(changed, config)
        except ValueError:
            pass
        else:
            raise ValueError("mutation comparator failed")
    observations = receipts((PRIOR / "native-issued-native-read.host.log").read_bytes())
    check_receipts(observations, config, "retained")
    bad = copy.deepcopy(observations)
    bad["transport_read"] = []
    try:
        check_receipts(bad, config, "retained")
    except ValueError:
        pass
    else:
        raise ValueError("missing join admitted")
    samples = schedule()
    require(
        len(samples) == 310 and all(s[0] == "retained" for s in samples[:62]),
        "schedule cardinality/order",
    )
    for cohort in COHORTS:
        for route in ROUTES:
            require(sum(s == (cohort, "warmup", 0, route) for s in samples) == 1, "one warmup")
            require(
                sum(s[0] == cohort and s[1] == "measured" and s[3] == route for s in samples) == 30,
                "30 per route",
            )
        for pair in range(30):
            require(
                tuple(s[3] for s in samples if s[:3] == (cohort, "measured", pair))
                == (ROUTES if pair % 2 == 0 else ROUTES[::-1]),
                "alternating pair order",
            )
    require(describe(list(range(1, 31)))["empiricalP95"] == 29, "nearest-rank empirical p95")
    print(
        "PASS offline historical comparator replay; 7 mutations; missing-join rejection; 310-slot schedule; p95. Product runs: 0."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--self-test", action="store_true")
    group.add_argument("--check", type=Path, metavar="CONFIG")
    group.add_argument("--pilot", type=Path, metavar="CONFIG")
    group.add_argument("--run", type=Path, metavar="CONFIG")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--authorize-ready-host", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.check:
        preflight(load(args.check), artifacts=True)
        print("PASS read-only preflight; no product process started")
        return 0
    require(
        args.authorize_ready_host and args.output is not None,
        "live collection requires --authorize-ready-host and --output",
    )
    return collect(
        load(args.pilot or args.run), args.output.resolve(), pilot=args.pilot is not None
    )


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, KeyError, TypeError, ValueError) as error:
        print(f"COLLECTOR_REJECTED: {error}", file=sys.stderr)
        sys.exit(2)
