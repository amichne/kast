# /// script
# requires-python = ">=3.12,<3.14"
# dependencies = []
# ///
"""Authorized, bounded epoch2 requalification; never starts a measurement cohort."""
from __future__ import annotations

import copy
import importlib
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
a = importlib.import_module("acceptance")
c = a.c


def main() -> int:
    c.require(sys.argv[1:] == ["--authorize-ready-requalification"], "explicit requalification authorization required")
    old = c.load(HERE / "ready.json")
    a.preflight(old)
    authority = c.load(Path(old["readyHostReceipt"]))
    expected = copy.deepcopy(old)
    expected["live"]["epoch"] = 2
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S.%fZ")
    directory = HERE / ("ready-epoch2-" + timestamp)
    directory.mkdir()
    summary: dict[str, Any] = {"state": "INCOMPLETE", "observedAt": timestamp, "priorReadyReceipt": old["readyHostReceipt"], "expectedLive": expected["live"], "scope": "two sequential declaration probes; correctness/MCP authorized; no pilot/cohort", "epochAdvanceCause": "NOT ESTABLISHED"}

    def check_host(label: str) -> None:
        a.preflight(old)
        argv = ["/bin/ps", "-o", "lstart=", "-o", "command=", "-p", str(old["endpointExpected"]["hostPid"])]
        env = {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}
        process = subprocess.run(argv, env=env, capture_output=True, check=False)
        c.save(directory / (label + "-host-process.json"), {"argv": argv, "environment": env, "exit": process.returncode, "stdout": process.stdout.decode(), "stderr": process.stderr.decode()})
        expected_line = authority["hostLaunch"]["process_start"] + " " + " ".join(authority["hostLaunch"]["command"])
        c.require(process.returncode == 0 and " ".join(process.stdout.decode().split()) == " ".join(expected_line.split()), "host PID/start/command identity changed")

    try:
        check_host("before")
        log = Path(old["hostLog"])
        before = log.stat()
        raw = log.read_bytes()
        (directory / "host-before.log").write_bytes(raw)
        observed = c.receipts(raw)
        c.save(directory / "prior-semantic-bases.json", [{key: read.get(key) for key in ("pid", "readId", "correlation", "outcome")} for read in observed["semantic_read"]])
        c.save(directory / "host-before-boundary.json", {"device": before.st_dev, "inode": before.st_ino, "bytes": len(raw), "sha256": c.digest(directory / "host-before.log"), "qualification": "available preceding log; correlations document observed bases, not the cause of an advance"})
        bases: list[Any] = []
        for index, route in enumerate(("baseline", "native"), 1):
            check_host("before-probe-" + str(index))
            selected = old["routes"][route]
            output = directory / ("probe-" + str(index) + "-" + route)
            record = c.capture(output, [selected["command"], *a.command(old, ["query"], "--request", "-")], selected["environment"], old["live"]["root"], (c.REPO / "docs/reviews/public-cli-v1/query.json").read_bytes(), log, old["watchdogSeconds"], {"name": "readiness-" + route, "notLatencySample": True})
            c.require(record["state"] == "RECORDED" and record["exitCode"] == 0 and record["outputEof"] and record["reapedBeforeNextInvocation"] and not record.get("interruption"), "readiness probe capture/exit/reaping")
            result = c.load(output / "stdout")
            c.declaration(result, expected)
            a.host_identity(record, expected)
            c.check_receipts(record["receipts"], expected, "discovery")
            bases.append(result["document"]["live"])
            check_host("after-probe-" + str(index))
        c.require(bases == [expected["live"], expected["live"]], "two identical exact epoch2 bases required")
        summary.update({"state": "PASS", "live": bases[0], "endpoint": old["endpoint"], "endpointExpected": old["endpointExpected"], "identities": old["identities"], "hostLaunch": authority["hostLaunch"], "probes": [str(directory / "probe-1-baseline/record.json"), str(directory / "probe-2-native/record.json")]})
        receipt = directory / "ready-host-receipt.json"
        c.save(receipt, summary)
        expected["readyHostReceipt"] = str(receipt)
        expected["identities"][str(receipt)] = c.digest(receipt)
        for path in (HERE / "ready.json", Path(__file__).resolve(), *[directory / "probe-1-baseline/record.json", directory / "probe-2-native/record.json"]):
            expected["identities"][str(path)] = c.digest(path)
        expected["authorizationScope"] = "Main explicitly authorized two-probe epoch2 requalification, then run-002 correctness/MCP. No pilot or cohort."
        a.preflight(expected)
        c.save(directory / "ready.json", expected)
        print(json.dumps({"state": "PASS", "readyConfig": str(directory / "ready.json"), "receipt": str(receipt)}))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        summary.update({"state": "FAIL", "failure": repr(error)})
        print(json.dumps({"state": "FAIL", "directory": str(directory), "failure": repr(error)}))
        return 1
    finally:
        c.save(directory / "summary.json", summary)


if __name__ == "__main__":
    sys.exit(main())
