# Frozen native-query acceptance protocol

Recorded before candidate semantic results or paired timing collection.

- Baseline source: `1e3a654d3ea4f160d603a37e5c574d5470c9a543`.
- Baseline product: the numeric `0.0.0` Control and Host artifacts built in the pristine baseline checkout.
- Candidate: final native producer, assembled and admitted by the unchanged product limits and installer. A failing candidate gate does not qualify an adjacent executable for this cohort.
- Saved workspace: `/private/tmp/kast-public-cli-v1-a3b5uat_/workspace`.
- Source SHA-256: `c0cb08aacfb8b7097ab074e253b710eae649c22e4443d0b5a747f72ee39e4859`.
- Independent declarations: `example.OrderService` [17,94), `example.OrderService.submitOrder` [42,92), `example.placeOrder` [96,174).
- Independent relation: exactly `placeOrder → submitOrder`, occurrence [152,163), `SOURCE_TO_TARGET`, `k2-authored-source`, `exact-compiler-confirmed`.
- Controls: absent name and callers of `placeOrder` return no matches. Mutating target, source range, coverage, host, field selection, or graph-token linkage must fail comparison.
- Cohorts: metadata (`describe query --section input`), plan (`query plan --name OrderService`), discovery (committed `public-cli-v1/query.json`), callers (same fields and grants), and retained read.
- Exactly 30 paired fresh-process samples per cohort, one untimed warm-up per route per cohort; alternate JVM-first and native-first. Run retained reads first to avoid eviction.
- Catalog COMPLETE; fields NAME,SIGNATURE,LOCATION; 128 results; 49152 bytes. Retained reads reuse one exact pre-existing result, never a timed producer.
- One already-ready isolated IDEA host, unchanged saved workspace, host/workspace/basis/version across pairs. Host startup is excluded.
- Every started sample is recorded before assertions with argv, environment selection, monotonic elapsed time through output completion, exit, exact stdout/stderr, and host log slice.
- Compare full admitted documents. Normalize only fresh result references and row IDs, consistently through linked relation fields. Do not normalize retained producer tokens, host, workspace, basis, coverage, completion, source ranges, or selected fields.
- Join transport connection IDs to exact semantic read IDs. RETENTION receipts are allowed, but READ_RESULT must not rediscover declarations, expand relations, or call K2 producers.
- Collect complete descendant execution events or a qualified enforced policy with an absolute-JBR positive control. Missing collection is unavailable, not zero.
- Report median, empirical p95, range, paired differences, failures, external load, resource availability, build time, and artifact bytes. Do not label process-minus-host time JVM startup.
- Every AC01–AC17 remains NOT RUN until all assertions at its stated scope pass. Native peer fixtures do not prove IDEA semantics; native client exit does not prove host settlement.
