"""Exercise actual RESUME admission with an intentionally unissued valid output token."""
from acceptance import command, invoke, save

outputs = []
for route in ['baseline', 'native']:
    result, record = invoke('resume-unissued-' + route, route, command(['result', 'resume'], '--continuation', 'query-output:v1:00000000-0000-0000-0000-000000000099'), policy=route == 'native')
    outputs.append((result, record['exitCode']))
assert outputs[0] == outputs[1]
save('resume-control-assertions.json', {'parity': 'PASS', 'result': outputs[0][0], 'exitCode': outputs[0][1], 'issuedContinuationSuccess': 'NOT_RUN: producers issued retained result references and cursors, not output continuation tokens'})
