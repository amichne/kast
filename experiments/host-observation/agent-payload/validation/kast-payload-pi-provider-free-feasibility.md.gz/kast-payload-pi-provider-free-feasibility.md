# Pi 1.4.0 provider-free pipeline feasibility

This report uses installed declarations and source only. No session, tool, sandbox, model, native query, installation, or IDE action ran.
The installed package root is `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent`.

## Supported APIs and source

| API or rule | Exact installed source |
| --- | --- |
| Public tool metadata and raw definition lookup | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/core/agent-session.d.ts:415-428` |
| Public session runner getter | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/core/agent-session.d.ts:932` |
| Context factory and nested execution | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/core/extensions/runner.js:696-722` |
| Required assistant context and actual nested pipeline | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/core/agent-session.js:387-408` |
| Registered-tool wrapper supplies the real context | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/core/extensions/wrapper.js:13-22` |
| Public outer pipeline API and required parameters | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-agent-core/dist/agent-loop.d.ts:32-52` |
| Argument validation, configured hooks, and blocked calls | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-agent-core/dist/agent-loop.js:482-534` |
| No context means no callable sandbox tools | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/extensions/codemode/execute.js:448-479` |
| MCP startup and readiness hooks | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/extensions/mcp/index.js:971-1000` and `1035-1059` |
| Public SDK composition example | `/Users/amichne/.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/examples/sdk/14-codemode-mcp.ts:15-59` |

## Result and prerequisites

`getAllTools()` returns configured metadata. It does not prove MCP readiness or show actual provider requests.
`getToolDefinition()` returns a raw definition with an `execute` member. It is not a pipeline executor.
`session.extensionRunner.createToolContext()` supplies the real callable tools and nested execution function.
The nested session path refuses tool work unless the session contains an assistant message.
A fresh session returns `isError: true` with `No assistant message issued this call`.
A direct `codemode` executor without context exposes no tools.

A genuine recorded assistant context can in principle support a provider-free replay through public session-restoration APIs.
No such replay ran here. No assistant context was fabricated.
The public outer pipeline API is `runToolCall()` with a registered-tool wrapper and real session hooks.
It needs the actual assistant message, agent context, tools, and configured before/after hooks.
It emits no outer events and adds no transcript messages by itself.
Raw `definition.execute()` bypasses outer argument validation, permission hooks, and the MCP-readiness hook.

SDK users add `createCodemodeExtension()` and `createMcpExtension()` through the resource loader, then call `session.bindExtensions()`.
That call emits `session_start` and starts real MCP connections asynchronously. It is an external effect without inference.
The `codemode` tool has `model-only` exposure and cannot call itself through `ctx.executeTool()`.
The documented `models:false` option removes model APIs from the sandbox. Its extension default is `true`.

Permission behavior comes from configured extension hooks. The pipeline does not supply a universal confirmation policy.
The actual trusted workspace, extension configuration, and permission hooks must remain intact.
The default context has no interactive UI, and its confirmation function returns false.
The installed permission-gate example rejects dangerous calls without a UI.

## Evidence limit

A deterministic provider-free replay can establish sandbox, discovery, transport, and result handling under its real context.
It cannot establish model selection, token consumption, task-input savings, or matched model-task success.
`Session.prompt()` invokes inference and was not called.
